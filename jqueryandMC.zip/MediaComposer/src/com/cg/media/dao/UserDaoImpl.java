package com.cg.media.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.media.exception.MediaException;
import com.cg.media.util.DBUtil;

public class UserDaoImpl implements IUserDao {

	Connection conn;

	@Override
	public boolean validateUser(int userId, String password)
			throws MediaException {
		try {
			conn = DBUtil.getConnection();
			PreparedStatement pstmt = conn.prepareStatement("SELECT USER_ID,USER_PASSWORD from user_master where USER_ID=?");
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next()){
				
				if(userId==rs.getInt(1) && password.equals(rs.getString(2))){
					
					return true;
				}
				else {
					return false;
					
				}
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;	
		

	}

}
