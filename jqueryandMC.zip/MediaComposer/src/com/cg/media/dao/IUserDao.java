package com.cg.media.dao;

import com.cg.media.exception.MediaException;

public interface IUserDao {
	public boolean validateUser(int userId, String password)
			throws MediaException;
}
