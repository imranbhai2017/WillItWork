package com.cg.media.dao;

import java.util.List;

import com.cg.media.dto.ComposerBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;

public interface IComposerDao {
	public int createComposer(ComposerBean composerBean) throws MediaException;

	public int editComposer(ComposerBean composerBean) throws MediaException;

	public int assignSongToComposer(int songId,int composerId) throws MediaException;
	
	public List<SongBean> searchSongByComposerId(int composerId) throws MediaException;
}
