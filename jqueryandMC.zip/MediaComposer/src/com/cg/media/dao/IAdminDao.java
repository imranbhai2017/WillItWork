package com.cg.media.dao;

import com.cg.media.exception.MediaException;

public interface IAdminDao {
	public boolean validateAdmin(int userId, String password)
			throws MediaException;
}
