package com.cg.media.ui;

import java.util.Scanner;

import com.cg.media.exception.MediaException;
import com.cg.media.service.IUser;
import com.cg.media.service.UserServiceImpl;

public class UserUI {

	Scanner sc = new Scanner(System.in);

	public boolean validateUser() throws MediaException {

		IUser userServ = new UserServiceImpl();

		

		System.out.print("UserId : ");
		int id = sc.nextInt();

		System.out.print("Password : ");
		String pwd = sc.next();

		boolean result = userServ.validateUser(id, pwd);

		if (result == true) {

			UserUI userUi = new UserUI();

			userUi.userOperations();

		} else {
			throw new MediaException("Problem in Login");
		}

		return result;

	}

	private void userOperations() {
		
		System.out.println("Welcome User!!!");
		
		
		int n;

		
		do
		{
			System.out.println("\n 1.Search Song Based on Composer"
					+ "\n 2.Search Song Based on Artist");
			
			System.out.println("Enter the Choice :");
			
			int choice = sc.nextInt();
		
		switch (choice) {
		case 1:System.out.println("here search composer");
						
			break;
			
			
		case 2:System.out.println("here Search Artist");

			break;
			
				default:System.out.println("Enter Correct Choice");
			break;
		}
		
		System.out.println("Do you want to Continue 1.yes 0.no");
		n = sc.nextInt();
		}while(n!=0);
		
		sc.close();

	}



}
