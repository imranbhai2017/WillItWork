package com.cg.media.ui;

import java.util.Scanner;

import com.cg.media.exception.MediaException;
import com.cg.media.service.AdminServiceImpl;
import com.cg.media.service.IAdmin;

public class AdminUI {

	Scanner sc = new Scanner(System.in);

	public boolean validateAdmin() throws MediaException {

		IAdmin adminServ = new AdminServiceImpl();
		
		System.out.print("UserId : ");
		int id = sc.nextInt();

		System.out.print("Password : ");
		String pwd = sc.next();

		boolean result = adminServ.validateAdmin(id, pwd);

		if (result == true) {

			AdminUI adminUi = new AdminUI();

			adminUi.adminOperations();

		} else {
			throw new MediaException("Problem in Login");
		}

		return result;

	}

	private void adminOperations() {
		
		System.out.println("Welcome Admin!!!");
		
		
		int n;

		
		do
		{
			System.out.println("\n 1.Search for Composer"
					+ "\n 2.Add new Composer"
					+ "\n 3.Edit An existing Composer"
					+ "\n 4.Search for An Artist"
					+ "\n 5.Add new Artist"
					+ "\n 6.Edit An existing Artist"
					+ "\n 7.Associate Songs with Artist/Composer");
			
			System.out.println("Enter the Choice :");
			
			int choice = sc.nextInt();
		
		switch (choice) {
		case 1:System.out.println("here search composer");
						
			break;
			
			
		case 2:System.out.println("here add composer");

			break;
			
		case 3:System.out.println("here edit composer");

			break;
		case 4:System.out.println("here search composer");

			break;
		case 5:System.out.println("here add artist");

			break;
		case 6:System.out.println("here sedit artist");

			break;
		case 7:System.out.println("here associate songs");

			break;


		default:System.out.println("Enter Correct Choice");
			break;
		}
		
		System.out.println("Do you want to Continue 1.yes 0.no");
		n = sc.nextInt();
		}while(n!=0);
		
		sc.close();

	}


}
