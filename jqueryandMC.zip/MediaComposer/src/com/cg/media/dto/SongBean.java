package com.cg.media.dto;

import java.time.LocalDate;

public class SongBean {
	private int songId;
	private String songName;
	private int songDuration;
	private int createdBy;
	private LocalDate createdOn;
	private int updatedBy;
	private LocalDate updatedOn;
	private char songDeletedFlag;

	private ArtistBean artistBean;
	private ComposerBean composerBean;
	
	public ArtistBean getArtistBean() {
		return artistBean;
	}

	public void setArtistBean(ArtistBean artistBean) {
		this.artistBean = artistBean;
	}

	public ComposerBean getComposerBean() {
		return composerBean;
	}

	public void setComposerBean(ComposerBean composerBean) {
		this.composerBean = composerBean;
	}

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public int getSongDuration() {
		return songDuration;
	}

	public void setSongDuration(int songDuration) {
		this.songDuration = songDuration;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDate getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDate updatedOn) {
		this.updatedOn = updatedOn;
	}

	public char getSongDeletedFlag() {
		return songDeletedFlag;
	}

	public void setSongDeletedFlag(char songDeletedFlag) {
		this.songDeletedFlag = songDeletedFlag;
	}

}
