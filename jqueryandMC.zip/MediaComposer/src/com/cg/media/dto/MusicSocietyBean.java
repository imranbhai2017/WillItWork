package com.cg.media.dto;

public class MusicSocietyBean {
	
	private int composerMusicSocietyID;
	private String composerMusicSocietyName;

	public int getComposerMusicSocietyID() {
		return composerMusicSocietyID;
	}

	public void setComposerMusicSocietyID(int composerMusicSocietyID) {
		this.composerMusicSocietyID = composerMusicSocietyID;
	}

	public String getComposerMusicSocietyName() {
		return composerMusicSocietyName;
	}

	public void setComposerMusicSocietyName(String composerMusicSocietyName) {
		this.composerMusicSocietyName = composerMusicSocietyName;
	}
}
