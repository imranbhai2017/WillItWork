package com.cg.media.dto;

import java.time.LocalDate;

public class ComposerBean {

	private int composerId;
	private String composerName;
	private LocalDate composerBornDate;
	private LocalDate composerDiedDate;
	private int composerCaeipiNum;
	private String composerMusicSocietyId;
	private int createdBy;
	private LocalDate createdOn;
	private int updateBy;
	private LocalDate updatedOn;
	private char composerDeletedFlag;

	public char getComposerDeletedFlag() {
		return composerDeletedFlag;
	}

	public void setComposerDeletedFlag(char composerDeletedFlag) {
		this.composerDeletedFlag = composerDeletedFlag;
	}

	

	public int getComposerId() {
		return composerId;
	}

	public void setComposerId(int composerId) {
		this.composerId = composerId;
	}

	public String getComposerName() {
		return composerName;
	}

	public void setComposerName(String composerName) {
		this.composerName = composerName;
	}

	public LocalDate getComposerBornDate() {
		return composerBornDate;
	}

	public void setComposerBornDate(LocalDate composerBornDate) {
		this.composerBornDate = composerBornDate;
	}

	public LocalDate getComposerDiedDate() {
		return composerDiedDate;
	}

	public void setComposerDiedDate(LocalDate composerDiedDate) {
		this.composerDiedDate = composerDiedDate;
	}

	public int getComposerCaeipiNum() {
		return composerCaeipiNum;
	}

	public void setComposerCaeipiNum(int composerCaeipiNum) {
		this.composerCaeipiNum = composerCaeipiNum;
	}

	public String getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}

	public void setComposerMusicSocietyId(String composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}

	public int getUpdateBy() {
		return updateBy;
	}

	public void setUpdateBy(int updateBy) {
		this.updateBy = updateBy;
	}

	public LocalDate getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDate updatedOn) {
		this.updatedOn = updatedOn;
	}
}
