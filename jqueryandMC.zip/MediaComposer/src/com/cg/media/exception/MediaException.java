package com.cg.media.exception;


	public class MediaException extends Exception {
		private static final long serialVersionUID = 2788853719994809977L;

		// private int detail;

		public MediaException(String args) {
			super(args);
			System.err.println(args);
		}

	}


