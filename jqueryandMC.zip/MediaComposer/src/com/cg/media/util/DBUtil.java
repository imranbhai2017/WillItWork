package com.cg.media.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DBUtil {

	static Logger log = Logger.getLogger("DB Utility");

	private static FileInputStream fis;
	private static Properties p;
	public static Connection c;
	
	/**
	 * 
	 * Author Name    : Devarajan Nachimuthu
	 * Class Name     : DBUtil
	 * Method Name    : getConnection
	 * Parameters     : @throws SQLException
	 * Return Type    : Connection
	 * Creation Date  : Sep 27, 2017
	 * Description    : Getting the connection and pass it to the DAO class
	 */
	
	public static Connection getConnection() throws SQLException {
		try {
			fis = new FileInputStream("resources/jdbcdeepak.properties");
			log.info(" Configuration File opened");

			p = new Properties();

			p.load(fis);

			String url = p.getProperty("url");
			String uname = p.getProperty("uname");
			String pass = p.getProperty("pass");
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			c = DriverManager.getConnection(url, uname, pass);
			log.info(" Database Connection Established");

		} catch (IOException e) {
			log.error(" IO exception" + e);

		} catch (SQLException e) {
			log.error(" SQL exception" + e);
			System.err.println(e);
			//e.printStackTrace();
		} finally {
			try {
				fis.close();
				log.info(" File Closed");
			} catch (IOException e) {
				log.error(" Unable to close file");
				e.printStackTrace();
			}
		}
		return c;
	}
}