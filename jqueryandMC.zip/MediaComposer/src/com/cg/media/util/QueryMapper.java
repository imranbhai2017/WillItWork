package com.cg.media.util;

public class QueryMapper {
	//
}
