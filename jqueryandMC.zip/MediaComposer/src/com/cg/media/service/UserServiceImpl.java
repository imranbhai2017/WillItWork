package com.cg.media.service;

import com.cg.media.dao.IUserDao;
import com.cg.media.dao.UserDaoImpl;
import com.cg.media.exception.MediaException;


public class UserServiceImpl implements IUser {
	
	IUserDao userDao = new UserDaoImpl();

	@Override
	public boolean validateUser(int userId, String password)
			throws MediaException {
		
		return userDao.validateUser(userId, password);
	}

}