package com.cg.media.service;

import com.cg.media.exception.MediaException;

public interface IUser {

	public boolean validateUser(int userId, String password)
			throws MediaException;

}
