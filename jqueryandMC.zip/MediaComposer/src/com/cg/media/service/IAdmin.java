package com.cg.media.service;

import com.cg.media.exception.MediaException;

public interface IAdmin {
	
	public boolean validateAdmin(int userId, String password)
			throws MediaException;

}
