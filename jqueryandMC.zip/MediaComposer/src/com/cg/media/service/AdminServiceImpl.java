package com.cg.media.service;

import com.cg.media.dao.AdminDaoImpl;
import com.cg.media.dao.IAdminDao;
import com.cg.media.exception.MediaException;

public class AdminServiceImpl implements IAdmin {
	
	IAdminDao adminDao = new AdminDaoImpl();

	@Override
	public boolean validateAdmin(int userId, String password)
			throws MediaException {
		
		return adminDao.validateAdmin(userId, password);
	}

}
