package com.cg.media.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;

import com.cg.media.dao.ArtistDaoImpl;
import com.cg.media.dto.ArtistBean;
import com.cg.media.dto.ComposerBean;
import com.cg.media.exception.MediaException;
import com.cg.media.service.AdminServiceImpl;
import com.cg.media.service.IArtist;
import com.cg.media.service.IComposer;
import com.cg.media.service.ISong;
import com.cg.media.service.MediaComposerServiceImpl;
import com.cg.media.service.IAdmin;

public class AdminUI {

	static Scanner sc = new Scanner(System.in);

	private static int id;

	static IArtist ias;
	static IAdmin iadminservice;
	static IComposer ics;
	static ISong iss;

	public static boolean validateAdmin() throws MediaException {

		IAdmin adminServ = new AdminServiceImpl();

		System.out.print("UserId : ");
		id = sc.nextInt();

		System.out.print("Password : ");
		String pwd = sc.next();

		boolean result = adminServ.validateAdmin(id, pwd);

		if (result == true) {

			new AdminUI();

			adminOperations();

		} else {
			throw new MediaException(
					"Problem in Login\n Check Username or Password");
		}

		return result;

	}

	static void adminOperations() throws MediaException {

		System.out.println("Welcome Admin!!!");

		int n;

		do {
			System.out.println("\n " + "1.Search for Composer by ID"
					+ "\n 2.Add new Composer" + "\n 3.View All Composers"
					+ "\n 4.Edit An existing Composer"
					+ "\n 5.Search for An Artist" + "\n 6.View All Artists"
					+ "\n 7.Add new Artist" + "\n 8.Edit An existing Artist"
					+ "\n 9.Associate Songs with Artist/Composer"
					+ "\n 10.Exit\n");

			System.out.println("Enter the Choice :");

			int choice = sc.nextInt();

			switch (choice) {

			case 1:

				ics = new MediaComposerServiceImpl();
				int composerId;
				System.out.println("Enter composer ID:");
				composerId = sc.nextInt();
				List<ComposerBean> mlist = ics.searchComposerById(composerId);
				System.out.println("ID   " + "Composer Name  "
						+ "Composer CAEIPI" + "  Music ID");
				for (ComposerBean composerBean : mlist) {
					System.out
							.println("*************************************************************************************");
					System.out.println(composerBean.getComposerId() + " "
							+ composerBean.getComposerName() + " "
							+composerBean.getComposerBornDate()+" "
							+composerBean.getComposerDiedDate()+" "
							+ composerBean.getComposerCaeipiNum() + " "
							+ composerBean.getComposerMusicSocietyId()+" "
							+composerBean.getCreatedBy()+" "
							+composerBean.getCreatedOn()+" "
							+composerBean.getUpdatedBy()+" "
							+composerBean.getUpdatedOn());
					System.out.println();
					System.out
							.println("*************************************************************************************");
				}

				break;

			case 2:
				composerCreation();
				break;
			case 3:
				composerAssignSong();
				break;
			case 4:
				composerUpdate();
				break;

			case 5:
				ias = new MediaComposerServiceImpl();
				int artistId;
				System.out.println("Enter Artist ID:");
				artistId = sc.nextInt();
				ArtistBean artist = ias.searchArtistById(artistId);

				System.out.println("ID   " + "Artist Name  "
						+ "Artist Type" + "  Artist Deleted Flag");
				
					System.out
							.println("*************************************************************************************");
					System.out.println(artist.getArtistId() + " "
							+ artist.getArtistName() +" "+artist.getArtistType()+" "+artist.getArtistDeletedFlag());
					System.out.println();
					System.out
							.println("*************************************************************************************");
				break;
			case 6:
				artistAssignSong();
				break;
			case 7:
				artistCreation();

				break;

			case 8:
				artistUpdate();

				break;
			case 9:
				System.out.println("here associate songs to artist");

				break;
			case 10:
				System.exit(0);
				break;
			default:
				System.out.println("Enter Correct Choice");
				adminOperations();
				break;
			}

			System.out.println("Do you want to Continue 1.yes 0.no");
			n = sc.nextInt();
		} while (n != 0);

		sc.close();
	}

	private static void artistAssignSong() throws MediaException {
		do {
			System.out.println("Choose your option!");
			System.out.println("1.View All Songs");
			System.out.println("2.View All Artists");
			System.out.println("3.Assign Song");
			System.out.println("4.Exit -> Goto Admin Panel");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				iss = new MediaComposerServiceImpl();
				iss.viewAllSongs();

				artistAssignSong();
				break;
			case 2:
				ias = new MediaComposerServiceImpl();
				List<ArtistBean> artistList = ias.viewAllArtists();
				
				for (ArtistBean artistBean : artistList) {
					System.out.println(artistBean.getArtistId() + "  "
							+ artistBean.getArtistName() + " "
							+ artistBean.getArtistType() + " "
							+ artistBean.getArtistBornDate()+" "
							+artistBean.getArtistDiedDate()+" "
							+artistBean.getCreatedBy()+" "
							+artistBean.getCreatedOn()+" "
							+artistBean.getUpdatedBy()+" "
							+artistBean.getUpdatedOn()+" "
							+artistBean.getArtistDeletedFlag());
				}
				
				break;
			case 3:
				ias = new MediaComposerServiceImpl();
				System.out.println("Enter Artist Id");
				int artistId = sc.nextInt();
				System.out.println("Enter Song Id");
				int songId = sc.nextInt();
				System.out.println("The ID is: " + id);
				ias.assignSongToArtist(songId, artistId, id);
				break;
			case 4:
				adminOperations();
				break;
			default:
				break;
			}

		} while (true);

	}

	private static void composerAssignSong() throws MediaException {

		do {
			System.out.println("Choose your option!");
			System.out.println("1.View All Songs");
			System.out.println("2.View All Composers");
			System.out.println("3.Assign Song");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				iss = new MediaComposerServiceImpl();
				iss.viewAllSongs();
				composerAssignSong();
				break;
			case 2:
				ics = new MediaComposerServiceImpl();
				List<ComposerBean> composerList = ics.viewAllComposers();
				for (ComposerBean composerBean : composerList) {
					System.out.println(composerBean.getComposerId() + "  "
							+ composerBean.getComposerName() + " "
							+composerBean.getComposerBornDate()+" "
							+((composerBean.getComposerDiedDate()!=null)?composerBean.getComposerDiedDate():"-")+" "
							+composerBean.getComposerCaeipiNum() + " "
							+composerBean.getComposerMusicSocietyId()+" "
							+composerBean.getCreatedBy()+" "
							+composerBean.getCreatedOn()+" "
							+composerBean.getUpdatedBy()+" "
							+composerBean.getUpdatedOn());
				}
				break;
			case 3:
				ics = new MediaComposerServiceImpl();
				ComposerBean cbAssign = new ComposerBean();
				cbAssign = new ComposerBean();
				cbAssign.setCreatedBy(id);
				cbAssign.setCreatedOn(LocalDate.now());

				System.out.println("Enter Composer Id");
				int composerId = sc.nextInt();
				System.out.println("Enter Song Id");
				int songId = sc.nextInt();
				ics.assignSongToComposer(songId, composerId, id);
				break;

			default:
				break;
			}

		} while (true);

	}

	private static void artistUpdate() throws MediaException {

		ias = new MediaComposerServiceImpl();
		DateTimeFormatter format111 = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		ArtistBean artistBeanUpdate = new ArtistBean();
		System.out.println("here edit artist");

		System.out.println("Enter Artist ID to update ");
		artistBeanUpdate.setArtistId(sc.nextInt());

		System.out.println("Enter edited artist name:");
		artistBeanUpdate.setArtistName(sc.next());
		System.out.println("Enter edited Artist Type:");
		artistBeanUpdate.setArtistType(sc.next());
		System.out
				.println("Enter edited artist Born date:\n (in format:dd-MM-yyyy)");
		String Birthdate1 = sc.next();

		LocalDate bdartist = LocalDate.parse(Birthdate1, format111);
		artistBeanUpdate.setArtistBornDate(bdartist);
		System.out
				.println("Enter edited Artist Died date:\n(in format:dd-MM-yyyy)\n If he is alive put no");
		String diedDate = sc.next();
		if (diedDate.equalsIgnoreCase("no")) {
			artistBeanUpdate.setArtistDiedDate(null);
		} else {
			DateTimeFormatter formatdd = DateTimeFormatter
					.ofPattern("dd-MM-yyyy");
			LocalDate dd1 = LocalDate.parse(diedDate, formatdd);
			artistBeanUpdate.setArtistDiedDate(dd1);

		}
		// System.out.println("Admin ID is Set to be Updater ID");
		artistBeanUpdate.setUpdatedBy(id);
		// System.out.println("Today's Date is the Updated Date");
		LocalDate ud = LocalDate.now();
		artistBeanUpdate.setUpdatedOn(ud);

		ias.editArtist(artistBeanUpdate);

	}

	private static void artistCreation() throws MediaException {

		ias = new MediaComposerServiceImpl();
		DateTimeFormatter format11 = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		ArtistBean artistBean = new ArtistBean();
		System.out.println("here add artist");

		System.out.println("Enter artist name:");
		artistBean.setArtistName(sc.next());
		System.out.println("Enter Artist Type:");
		artistBean.setArtistType(sc.next());
		System.out.println("Enter Artist Born date:\n (in format:dd-MM-yyyy)");
		String Birthdate = sc.next();

		LocalDate bd = LocalDate.parse(Birthdate, format11);
		artistBean.setArtistBornDate(bd);

		System.out
				.println("Enter Artist Died date:\n(in format:dd-MM-yyyy)\n If he is alive Enter No");
		String diedDate = sc.next();
		if (diedDate.equalsIgnoreCase("no")) {
			artistBean.setArtistDiedDate(null);
		} else {
			DateTimeFormatter formatdd = DateTimeFormatter
					.ofPattern("dd-MM-yyyy");
			LocalDate dd1 = LocalDate.parse(diedDate, formatdd);
			artistBean.setArtistDiedDate(dd1);

		}

		/*
		 * System.out.println("Enter Artist Died date:\n(in format:dd-MM-yyyy)");
		 * String diedDate = sc.next();
		 * 
		 * LocalDate dd = LocalDate.parse(diedDate, format11);
		 */

		// System.out.println("Admin ID is Set to be Creator ID");
		artistBean.setCreatedBy(id);
		// System.out.println("Today's Date is the Created Date");
		LocalDate cd = LocalDate.now();

		// LocalDate crd = LocalDate.parse(cd, format);
		artistBean.setCreatedOn(cd);
		// System.out.println("Admin ID is Set to be Updater ID");
		artistBean.setUpdatedBy(id);
		// System.out.println("Today's Date is the Updated Date");
		LocalDate ud = LocalDate.now();

		// LocalDate upd = LocalDate.parse(ud, format);
		artistBean.setUpdatedOn(ud);

		ias.createArtist(artistBean);

	}

	private static void composerUpdate() throws MediaException {
		ics = new MediaComposerServiceImpl();
		DateTimeFormatter format1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		ComposerBean composerBeanUpdate = new ComposerBean();
		System.out.println("here edit composer");

		System.out.println("Enter Compooser ID to update ");
		composerBeanUpdate.setComposerId(sc.nextInt());
		System.out.println("Enter edited composer name:");
		composerBeanUpdate.setComposerName(sc.next());
		System.out.println("Enter edited Composer Type:");

		composerBeanUpdate.setComposerType(sc.next());
		System.out.println("Enter ComposerCaeipiNum");
		composerBeanUpdate.setComposerCaeipiNum(sc.next());
		System.out.println("Enter ComposerMusicSocietyId");
		composerBeanUpdate.setComposerMusicSocietyId(sc.next());
		System.out
				.println("Enter edited Composer Born date:\n (in format:dd-MM-yyyy)");
		String BirthdateComposer = sc.next();

		LocalDate bdcomposer = LocalDate.parse(BirthdateComposer, format1);
		composerBeanUpdate.setComposerBornDate(bdcomposer);
		System.out
				.println("Enter edited Composer Died date:\n(in format:dd-MM-yyyy)\n If he is alive put no");
		String diedDatecomposer = sc.next();

		if (diedDatecomposer.equalsIgnoreCase("no")) {
			composerBeanUpdate.setComposerDiedDate(null);
		} else {
			LocalDate ddcomposer = LocalDate.parse(diedDatecomposer, format1);
			composerBeanUpdate.setComposerDiedDate(ddcomposer);

		}

		// System.out.println("Admin ID is Set to be Updater ID");
		composerBeanUpdate.setUpdatedBy(id);
		// System.out.println("Today's Date is the Updated Date");
		LocalDate ud1 = LocalDate.now();
		composerBeanUpdate.setUpdatedOn(ud1);
		System.out.println("Enter ComposerDeletedFlag");
		composerBeanUpdate.setComposerDeletedFlag(sc.next());

		ics.editComposer(composerBeanUpdate);

	}

	private static void composerCreation() throws MediaException {
		ics = new MediaComposerServiceImpl();
		ComposerBean composerBean = new ComposerBean();

		System.out.println("here add composer");

		System.out.println("Enter composer name:");
		composerBean.setComposerName(sc.next());
		System.out.println("Enter Composer Type:");
		composerBean.setComposerType(sc.next());
		System.out
				.println("Enter Composer Born date:\n (in format:dd-MM-yyyy)");
		String BirthdateArtist = sc.next();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate bd1 = LocalDate.parse(BirthdateArtist, format);
		composerBean.setComposerBornDate(bd1);
		/*
		 * System.out.println("Enter Composer Died date:\n(in format:dd-MM-yyyy)"
		 * ); String diedDate1 = sc.next();
		 */

		System.out
				.println("Enter edited Composer Died date:\n(in format:dd-MM-yyyy)\n If he is alive put no");
		String diedDate1 = sc.next();

		if (diedDate1.equalsIgnoreCase("no")) {
			composerBean.setComposerDiedDate(null);
		} else {
			DateTimeFormatter formatdd = DateTimeFormatter
					.ofPattern("dd-MM-yyyy");
			LocalDate dd1 = LocalDate.parse(diedDate1, formatdd);
			composerBean.setComposerDiedDate(dd1);

		}

		// System.out.println("Enter Creator Id:");
		composerBean.setCreatedBy(id);
		// System.out.println("Today's Date is the creation Date");
		LocalDate cd1 = LocalDate.now();
		// DateTimeFormatter formatcb = DateTimeFormatter
		// .ofPattern("dd-MM-yyyy");
		// LocalDate crd1 = LocalDate.parse(cd1, formatcb);
		composerBean.setCreatedOn(cd1);
		// System.out.println("Admin ID is Set to be Updater ID");
		composerBean.setUpdatedBy(id);
		// System.out.println("Today's Date is the Updated Date");
		LocalDate ud1 = LocalDate.now();
		// DateTimeFormatter formatud = DateTimeFormatter
		// .ofPattern("dd-MM-yyyy");
		// LocalDate upd1 = "";

		composerBean.setUpdatedOn(ud1);
		System.out.println("Enter ComposerCaeipi Number:");
		composerBean.setComposerCaeipiNum(sc.next());
		System.out.println("Enter composerMusicSocietyId: ");
		composerBean.setComposerMusicSocietyId(sc.next());
		/*
		 * System.out.println("Enter composerDeletedFlag details");
		 * composerBean.setComposerDeletedFlag(sc.next());
		 */

		ics.createComposer(composerBean);

	}

}
