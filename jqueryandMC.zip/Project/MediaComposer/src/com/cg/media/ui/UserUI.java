package com.cg.media.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.media.dao.ComposerDaoImpl;
import com.cg.media.dto.ComposerBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;
import com.cg.media.service.IUser;
import com.cg.media.service.UserServiceImpl;

public class UserUI {
	IUser userServ = new UserServiceImpl();
	Scanner sc = new Scanner(System.in);
UserServiceImpl usi = new UserServiceImpl();
	public boolean validateUser() throws MediaException {

		
		System.out.print("UserId : ");
		int id = sc.nextInt();

		System.out.print("Password : ");
		String pwd = sc.next();

		boolean result = userServ.validateUser(id, pwd);

		if (result == true) {

			UserUI userUi = new UserUI();

			userUi.userOperations();

		} else {
			throw new MediaException("Problem in Login");
		}

		return result;

	}

	private void userOperations() throws MediaException {

		System.out.println("Welcome User!!!");

		int n;

		do {
			System.out.println("\n 1.Search Song Based on Composer ID"
					+ "\n 2.Search Song Based on Artist ID");

			System.out.println("Enter the Choice :");

			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				System.out.println("here search song by composer");
				ComposerDaoImpl cdao =new ComposerDaoImpl();
				
				List<SongBean> mlist = cdao.searchSongByComposerId(100001);
				for (SongBean songBean : mlist) {
					
					int b = songBean.getSongId();
					int a = songBean.getSongDuration();
					ComposerBean cb = songBean.getComposerBean();
					
					cb.getComposerName();
					
				}
				
				
				break;

			case 2:
				System.out.println("here Search song by Artist");
				

				break;

			default:
				System.out.println("Enter Correct Choice");
				break;
			}

			System.out.println("Do you want to Continue 1.yes 0.no");
			n = sc.nextInt();
		} while (n != 0);

		sc.close();

	}

}
                                                           