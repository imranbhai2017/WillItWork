package com.cg.media.ui;

import java.util.Scanner;

import com.cg.media.exception.MediaException;

public class Client {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out
				.println("*******************************************************");
		System.out
				.println("Welcomme to Media Composer & Artist Management System");
		System.out
				.println("*******************************************************");

		System.out.println("\n");

		System.out.println("Select Login Type");

		System.out.println("\n 1.Admin \n 2.User");

		System.out
				.println("*******************************************************");

		int log = sc.nextInt();

		switch (log) {
		case 1:

			try {
				AdminUI.adminOperations();

			} catch (MediaException e) {
				e.printStackTrace();
			}
			break;

		case 2:

			UserUI userUi = new UserUI();

			try {
				userUi.validateUser();

			} catch (MediaException e) {
				e.printStackTrace();
			}

			break;

		default:
			System.out.println("Enter Correct Choice");
			break;
		}

		sc.close();

	}
}
