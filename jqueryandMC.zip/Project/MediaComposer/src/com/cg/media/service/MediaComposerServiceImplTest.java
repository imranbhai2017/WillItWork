package com.cg.media.service;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.junit.Test;

import com.cg.media.dto.ComposerBean;
import com.cg.media.exception.MediaException;

public class MediaComposerServiceImplTest {
	
	static IArtist ias;
	static IAdmin iadminservice;
	static IComposer ics;
	static ISong iss;

	@Test
	public void testCreateComposer() throws MediaException {
		ComposerBean composerBean = new ComposerBean();
		
		composerBean.setComposerName("Viki");
		composerBean.setComposerType("M");
		
		
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate bd1 = LocalDate.parse("12-02-1978", format);
		composerBean.setComposerBornDate(bd1);
		
		DateTimeFormatter formatdd = DateTimeFormatter
				.ofPattern("dd-MM-yyyy");
		LocalDate dd1 = LocalDate.parse("25-06-2017", formatdd);
		composerBean.setComposerDiedDate(dd1);
		
		composerBean.setCreatedBy(300002);
		
		composerBean.setCreatedOn( LocalDate.now());
		
		composerBean.setUpdatedBy(300002);
		
		composerBean.setUpdatedOn(LocalDate.now());
		
		composerBean.setComposerCaeipiNum("EFI265");
		
		composerBean.setComposerMusicSocietyId("101");
		
		ics.createComposer(composerBean);
	}

	/*@Test
	public void testEditComposer() {
		fail("Not yet implemented");
	}

	@Test
	public void testAssignSongToComposer() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchSongByComposerId() {
		fail("Not yet implemented");
	}

	@Test
	public void testCreateArtist() {
		fail("Not yet implemented");
	}

	@Test
	public void testEditArtist() {
		fail("Not yet implemented");
	}

	@Test
	public void testAssignSongToArtist() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchSongByArtistId() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewAllSongs() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewAllArtists() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewAllComposers() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchComposerById() {
		fail("Not yet implemented");
	}

	@Test
	public void testSearchArtistById() {
		fail("Not yet implemented");
	}
*/
}
