package com.cg.media.service;

import java.util.List;

import com.cg.media.dao.ArtistDaoImpl;
import com.cg.media.dao.ComposerDaoImpl;
import com.cg.media.dao.IArtistDao;
import com.cg.media.dao.IComposerDao;
import com.cg.media.dao.ISongDao;
import com.cg.media.dao.SongDaoImpl;
import com.cg.media.dto.ArtistBean;
import com.cg.media.dto.ComposerBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;

public class MediaComposerServiceImpl implements IComposer, IArtist, ISong {
	IComposerDao icd = new ComposerDaoImpl();
	IArtistDao iad = new ArtistDaoImpl();
	ISongDao isd = new SongDaoImpl();

	@Override
	public int createComposer(ComposerBean composerBean) throws MediaException {
		return icd.createComposer(composerBean);
	}

	@Override
	public int editComposer(ComposerBean composerBean) throws MediaException {
		return icd.editComposer(composerBean);
	}

	@Override
	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaException {
		return icd.assignSongToComposer(songId, composerId, id);
	}

	@Override
	public List<SongBean> searchSongByComposerId(int composerId)
			throws MediaException {
		return icd.searchSongByComposerId(composerId);
	}

	@Override
	public int createArtist(ArtistBean artistBean) throws MediaException {
		return iad.createArtist(artistBean);
	}

	@Override
	public int editArtist(ArtistBean artistBean) throws MediaException {
		return iad.editArtist(artistBean);
	}

	@Override
	public int assignSongToArtist(int songId, int artistId, int id)
			throws MediaException {
		return iad.assignSongToArtist(songId, artistId, id);
	}

	@Override
	public List<SongBean> searchSongByArtistId(int artistId)
			throws MediaException {
		return iad.searchSongByArtistId(artistId);
	}

	@Override
	public List<SongBean> viewAllSongs() throws MediaException {
		return isd.viewAllSongs();
	}

	@Override
	public List<ArtistBean> viewAllArtists() throws MediaException {
		
		return iad.viewAllArtists();
	}

	@Override
	public List<ComposerBean> viewAllComposers() throws MediaException {
		
		return icd.viewAllComposers();
	}

	@Override
	public List<ComposerBean> searchComposerById(int composerId)
			throws MediaException {
		
		return icd.searchComposerById(composerId);
	}

	@Override
	public ArtistBean searchArtistById(int artistId) throws MediaException {
		
		return iad.searchArtistById(artistId);
	}

	

}
