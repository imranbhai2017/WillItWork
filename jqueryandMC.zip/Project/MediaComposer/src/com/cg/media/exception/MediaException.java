package com.cg.media.exception;

public class MediaException extends Exception {

	private static final long serialVersionUID = 726264577455921591L;

	public MediaException(String message) 
	{
		System.out.println(message);
	}

}


