package com.cg.media.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.Ignore;
import org.junit.Test;

import com.cg.media.dto.ComposerBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;

public class ComposerDaoImplTest {

	IComposerDao dao = new ComposerDaoImpl();
	@Ignore
	@Test
	public void testCreateComposer() throws MediaException {
		ComposerBean composerBean = new ComposerBean();

		composerBean.setComposerName("Viki");
		composerBean.setComposerType("M");

		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate bd1 = LocalDate.parse("12-02-1978", format);
		composerBean.setComposerBornDate(bd1);

		DateTimeFormatter formatdd = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate dd1 = LocalDate.parse("25-06-2017", formatdd);
		composerBean.setComposerDiedDate(dd1);

		composerBean.setCreatedBy(100002);

		composerBean.setCreatedOn(LocalDate.now());

		composerBean.setUpdatedBy(100002);

		composerBean.setUpdatedOn(LocalDate.now());

		composerBean.setComposerCaeipiNum("EFI265");

		composerBean.setComposerMusicSocietyId("101");

		int n = dao.createComposer(composerBean);

		assertEquals(1, n);
	}
/*
	@Test
	public void testEditComposer() throws MediaException {
		ComposerBean composerBean = new ComposerBean();
		
		composerBean.setComposerId(300011);
		composerBean.setComposerName("Saaaaa");
		
		int i = dao.editComposer(composerBean);
		assertEquals(1, i);
	}
	*/

/*	@Test
	public void testAssignSongToComposer() {
		fail("Not yet implemented");
	}*/

	@Test
	public void testSearchSongByComposerId() throws MediaException {
		
		List<SongBean> list = dao.searchSongByComposerId(300003);
		assertNotNull(list);
		
	}

/*	@Test
	public void testSearchComposerById() {
		fail("Not yet implemented");
	}

	@Test
	public void testViewAllComposers() {
		fail("Not yet implemented");
	}*/

}