package com.cg.media.dao;

import java.util.List;

import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;

public interface ISongDao {
	public List<SongBean> viewAllSongs() throws MediaException;
}
