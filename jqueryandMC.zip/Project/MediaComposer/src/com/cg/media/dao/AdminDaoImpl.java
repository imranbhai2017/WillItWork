package com.cg.media.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.media.exception.MediaException;
import com.cg.media.util.DBUtil;

public class AdminDaoImpl implements IAdminDao {

	Connection conn;
	Logger log = Logger.getLogger("AdminDaoImpl");

	@Override
	public boolean validateAdmin(int userId, String password)
			throws MediaException {

		try {
			conn = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = conn
					.prepareStatement("SELECT USER_ID,USER_PASSWORD from ADMIN_MASTER where USER_ID=?");
			pstmt.setInt(1, userId);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {

				if (userId == rs.getInt(1) && password.equals(rs.getString(2))) {

					return true;
				} else {
					return false;

				}

			}

		} catch (SQLException e) {
			log.error("Erroe in Sql Connection");
			e.printStackTrace();
		}finally{
			try {
				conn.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("Erroe in Sql Connection");
				e.printStackTrace();
			}
		}
		return false;

	}

}
