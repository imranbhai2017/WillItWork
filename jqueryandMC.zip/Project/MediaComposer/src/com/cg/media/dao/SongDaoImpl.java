package com.cg.media.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



import org.apache.log4j.Logger;

import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;
import com.cg.media.util.DBUtil;
import com.cg.media.util.QueryMapper;

public class SongDaoImpl implements ISongDao {
	Connection c;
	ResultSet rs;
	List<SongBean> songList= new ArrayList<SongBean>();
	Logger log = Logger.getLogger("SongDaoImpl");
	
	@Override
	public List<SongBean> viewAllSongs() throws MediaException {
		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.SONG_SELECT_ALL);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				/*ComposerBean cb =new ComposerBean();
				cb.setComposerId(rs.getInt("cid"));
				cb.setComposerName(rs.getString("cname"));*/
				SongBean sbean = new SongBean();
				sbean.setSongId(rs.getInt("song_id"));
				sbean.setSongName(rs.getString("song_name"));
				sbean.setSongDuration(rs.getInt("song_duration"));
				
				/*sbean.setComposerBean(cb);

				System.out.println(cb.getComposerId() + " "
						+ cb.getComposerName() + " " + sbean.getSongId() + " "
						+ sbean.getSongName() + " " + (sbean.getSongDuration())
						/ 60 + " Minutes");*/
				System.out.println(sbean.getSongId() + " "
						+ sbean.getSongName() + " " + (sbean.getSongDuration())
						/ 60 + " Minutes");
				System.out.println();	

				songList.add(sbean);

			}

		} catch (SQLException e) {
			log.error("Erroe in Sql Connection");
			e.printStackTrace();
		} finally {
			try {
				c.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("Erroe in Sql Connection");
				e.printStackTrace();
			}
		}

		return songList;
	}

}
