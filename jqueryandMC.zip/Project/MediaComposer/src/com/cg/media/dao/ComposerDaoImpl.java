package com.cg.media.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.media.dto.ComposerBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;
import com.cg.media.util.DBUtil;
import com.cg.media.util.QueryMapper;

public class ComposerDaoImpl implements IComposerDao {

	private Connection c;
	private int n;
	private ResultSet rs;
	private ComposerBean cb;
	
	Logger log = Logger.getLogger("ComposerDaoImpl");

	@Override
	public int createComposer(ComposerBean composerBean) throws MediaException {

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.COMPOSER_INSERT_QUERY);
			System.out
					.println("ComposerName:" + composerBean.getComposerName());
			System.out.println("ComposerBornDate:"
					+ composerBean.getComposerBornDate());
			System.out.println("ComposerDiedDate:"
					+ composerBean.getComposerDiedDate());
			System.out.println("ComposerCaeipiNum:"
					+ composerBean.getComposerCaeipiNum());
			System.out.println("ComposerMusicSocietyId:"
					+ composerBean.getComposerMusicSocietyId());
			System.out.println("CreatedBy:" + composerBean.getCreatedBy());
			System.out.println("CreatedOn:" + composerBean.getCreatedOn());
			System.out.println("UpdatedBy:" + composerBean.getUpdatedBy());
			System.out.println("UpdatedOn:" + composerBean.getUpdatedOn());

			/*
			 * System.out.println("ComposerDeletedFlag:" +
			 * composerBean.getComposerDeletedFlag());
			 */

			pstmt.setString(1, composerBean.getComposerName());
			pstmt.setDate(2, Date.valueOf(composerBean.getComposerBornDate()));

			if (composerBean.getComposerDiedDate() == null) {
				pstmt.setDate(3, null);
			} else {
				pstmt.setDate(3,
						Date.valueOf(composerBean.getComposerDiedDate()));
			}

			pstmt.setString(4, composerBean.getComposerCaeipiNum());
			pstmt.setString(5, composerBean.getComposerMusicSocietyId());
			pstmt.setInt(6, composerBean.getCreatedBy());
			pstmt.setDate(7, Date.valueOf(composerBean.getCreatedOn()));
			pstmt.setInt(8, composerBean.getUpdatedBy());
			pstmt.setDate(9, Date.valueOf(composerBean.getUpdatedOn()));
			pstmt.setString(10, composerBean.getComposerDeletedFlag());
			
			n = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				log.info("Connection Terminated");
				c.close();
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public int editComposer(ComposerBean composerBean) throws MediaException {
		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.COMPOSER_UPDATE_QUERY);
			System.out
					.println("ComposerName:" + composerBean.getComposerName());
			System.out.println("ComposerBornDate:"
					+ composerBean.getComposerBornDate());
			System.out.println("ComposerDiedDate:"
					+ composerBean.getComposerDiedDate());
			System.out.println("ComposerCaeipiNum:"
					+ composerBean.getComposerCaeipiNum());
			System.out.println("ComposerMusicSocietyId:"
					+ composerBean.getComposerMusicSocietyId());
			System.out.println("UpdatedBy:" + composerBean.getUpdatedBy());
			System.out.println("UpdatedOn:" + composerBean.getUpdatedOn());
			/*
			 * System.out.println("ComposerDeletedFlag:" +
			 * composerBean.getComposerDeletedFlag());
			 */

			pstmt.setString(1, composerBean.getComposerName());
			pstmt.setDate(2, Date.valueOf(composerBean.getComposerBornDate()));
			
			if (composerBean.getComposerDiedDate() == null) {
				pstmt.setDate(3, null);
			} else {
				pstmt.setDate(3,
						Date.valueOf(composerBean.getComposerDiedDate()));
			}

			pstmt.setString(4, composerBean.getComposerCaeipiNum());
			pstmt.setString(5, composerBean.getComposerMusicSocietyId());
			pstmt.setInt(6, composerBean.getUpdatedBy());
			pstmt.setDate(7, Date.valueOf(composerBean.getUpdatedOn()));
			pstmt.setString(8, composerBean.getComposerDeletedFlag());
			pstmt.setInt(9, composerBean.getComposerId());
			n = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				log.info("Connection Terminated");
				c.close();
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaException {
		try {

			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.COMPOSER_ASS_INSERT_QUERY);
			pstmt.setInt(1, composerId);
			pstmt.setInt(2, songId);
			pstmt.setInt(3, id);
			pstmt.setDate(4, Date.valueOf(LocalDate.now()));
			pstmt.setInt(5, id);
			pstmt.setDate(6, Date.valueOf(LocalDate.now()));

			n = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		}

		return n;
	}

	@Override
	public List<SongBean> searchSongByComposerId(int composerId)
			throws MediaException {
		ArrayList<SongBean> mlist = new ArrayList<SongBean>();

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			cb = new ComposerBean();

			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.COMPOSER_SELECT_BY_ID_SONGS);
			pstmt.setInt(1, composerId);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				cb.setComposerId(rs.getInt("cid"));
				cb.setComposerName(rs.getString("cname"));
				SongBean sbean = new SongBean();
				sbean.setSongId(rs.getInt("sid"));
				sbean.setSongName(rs.getString("sname"));
				sbean.setSongDuration(rs.getInt("sdur"));
				sbean.setComposerBean(cb);

				System.out.println(cb.getComposerId() + " "
						+ cb.getComposerName() + " " + sbean.getSongId() + " "
						+ sbean.getSongName() + " " + (sbean.getSongDuration())
						/ 60 + " Minutes");
				System.out.println();

				mlist.add(sbean);

			}

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				log.info("Connection Terminated");
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return mlist;
	}

	@Override
	public List<ComposerBean> searchComposerById(int composerId)
			throws MediaException {
		ArrayList<ComposerBean> mlist = new ArrayList<ComposerBean>();

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			cb = new ComposerBean();

			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.COMPOSER_SELECT_BY_ID);
			pstmt.setInt(1, composerId);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				cb.setComposerId(rs.getInt("composer_id"));
				cb.setComposerName(rs.getString("composer_name"));
				cb.setComposerCaeipiNum(rs.getString(5));
				cb.setComposerMusicSocietyId(rs.getString(6));

				mlist.add(cb);

			}

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				log.info("Connection Terminated");
				c.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return mlist;
	}

	@Override
	public List<ComposerBean> viewAllComposers() throws MediaException {
		ArrayList<ComposerBean> composerList = new ArrayList<ComposerBean>();

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");

			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.COMPOSER_SELECTALL_QUERY);

			rs = pstmt.executeQuery();

			while (rs.next()) {

				cb = new ComposerBean();
				cb.setComposerId(rs.getInt(1));
				cb.setComposerName(rs.getString(2));
				cb.setComposerCaeipiNum(rs.getString(5));
				cb.setComposerMusicSocietyId(rs.getString(6));

				// System.out.println(rs.getString(2)+"  "
				// +rs.getString(5)+"  "+rs.getString(6));

				composerList.add(cb);

			}

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				log.info("Connection Terminated");
				c.close();
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}

		return composerList;
	}

}
