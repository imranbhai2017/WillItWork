package com.cg.media.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.media.dto.ArtistBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;
import com.cg.media.util.DBUtil;
import com.cg.media.util.QueryMapper;

public class ArtistDaoImpl implements IArtistDao {

	private Connection c;
	private int n;
	private ResultSet rs;
	private ArtistBean ab = new ArtistBean();
	
	Logger log = Logger.getLogger("ArtistDaoImpl");

	@Override
	public int createArtist(ArtistBean artistBean) throws MediaException {

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.ARTIST_INSERT_QUERY);
			System.out.println("ArtistName:" + artistBean.getArtistName());

			System.out.println("ArtistType:" + artistBean.getArtistType());
			System.out.println("ArtistBornDate:"
					+ artistBean.getArtistBornDate());
			System.out.println("ArtistDiedDate:"
					+ artistBean.getArtistDiedDate());
			System.out.println("CreatedBy:" + artistBean.getCreatedBy());
			System.out.println("CreatedOn:" + artistBean.getCreatedOn());
			System.out.println("UpdatedBy:" + artistBean.getUpdatedBy());
			System.out.println("UpdatedOn:" + artistBean.getUpdatedOn());
			System.out.println("ArtistDeletedFlag:"
					+ artistBean.getArtistDeletedFlag());

			pstmt.setString(1, artistBean.getArtistName());
			pstmt.setString(2, artistBean.getArtistType());
			pstmt.setDate(3, Date.valueOf(artistBean.getArtistBornDate()));
			
			
			if (artistBean.getArtistDiedDate() == null) {
				pstmt.setDate(4, null);
			} else {
				pstmt.setDate(4,
						Date.valueOf(artistBean.getArtistDiedDate()));
			}
			
			pstmt.setInt(5, artistBean.getCreatedBy());
			pstmt.setDate(6, Date.valueOf(artistBean.getCreatedOn()));
			pstmt.setInt(7, artistBean.getUpdatedBy());
			pstmt.setDate(8, Date.valueOf(artistBean.getUpdatedOn()));
			pstmt.setLong(9, artistBean.getArtistDeletedFlag());

			n = pstmt.executeUpdate();
			System.out.println(n + "rows inserted");

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				c.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}

		return n;
	}

	@Override
	public int editArtist(ArtistBean artistBean) throws MediaException {

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.ARTIST_UPDATE_QUERY);

			pstmt.setString(1, artistBean.getArtistName());
			pstmt.setString(2, artistBean.getArtistType());
			pstmt.setDate(3, Date.valueOf(artistBean.getArtistBornDate()));
			if (artistBean.getArtistDiedDate() == null) {
				pstmt.setDate(4, null);
			} else {
				pstmt.setDate(4,
						Date.valueOf(artistBean.getArtistDiedDate()));
			}
			pstmt.setInt(5, artistBean.getUpdatedBy());
			pstmt.setDate(6, Date.valueOf(artistBean.getUpdatedOn()));
			pstmt.setInt(7, artistBean.getArtistId());
			

			n = pstmt.executeUpdate();

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				c.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public int assignSongToArtist(int songId, int artistId, int id)
			throws MediaException {
		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.ARTISTASS_INSERT_QUERY);
			pstmt.setInt(2, songId);
			pstmt.setInt(1, artistId);
            pstmt.setInt(3,id);
            pstmt.setDate(4,Date.valueOf(LocalDate.now()));
            pstmt.setInt(5, id);
            pstmt.setDate(6, Date.valueOf(LocalDate.now()));
            
			n = pstmt.executeUpdate();
			
			
			
		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		}
		
		return n;
	}

	@Override
	public List<SongBean> searchSongByArtistId(int artistId)
			throws MediaException {
		ArrayList<SongBean> mlist = new ArrayList<SongBean>();

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");
			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.ARTIST_SELECT_QUERY);
			pstmt.setInt(1, artistId);
			rs = pstmt.executeQuery();
			while (rs.next()) {

				ab.setArtistId(rs.getInt("Artist_Id"));
				System.out.println(ab.getArtistId());

				SongBean sbean = new SongBean();
				sbean.setSongId(rs.getInt("Song_Id"));
				sbean.setSongName(rs.getString("Song_Name"));
				sbean.setSongDuration(rs.getInt("Song_Duration"));
				sbean.setArtistBean(ab);

				mlist.add(sbean);

			}

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				c.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}

		return mlist;
	}

	@Override
	public List<ArtistBean> viewAllArtists() throws MediaException {
		List<ArtistBean> artistList = new ArrayList<ArtistBean>();

		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");

			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.ARTIST_SELECTALL_QUERY);

			rs = pstmt.executeQuery();

			while (rs.next()) {
				ab = new ArtistBean();
				ab.setArtistId(rs.getInt(1));
				ab.setArtistName(rs.getString(2));
				ab.setArtistType(rs.getString(3));
				ab.setArtistBornDate(rs.getDate(4).toLocalDate());
				artistList.add(ab);

			}

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				c.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}

		return artistList;
	}

	@Override
	public ArtistBean searchArtistById(int artistId) throws MediaException {
		ArtistBean ab = new ArtistBean();
		try {
			c = DBUtil.getConnection();
			log.info("Connection Established");

			PreparedStatement pstmt = c
					.prepareStatement(QueryMapper.ARTIST_SELECT_QUERY);
			pstmt.setInt(1, artistId);

			rs = pstmt.executeQuery();

			if (rs.next()) {

			ab.setArtistId(rs.getInt(1));
			ab.setArtistName(rs.getString(2));

			}

		} catch (SQLException e) {
			log.error("SQL Error Check SQLQUERY");
			e.printStackTrace();
		} finally {
			try {
				c.close();
				log.info("Connection Terminated");
			} catch (SQLException e) {
				log.error("SQL Error Check SQLQUERY");
				e.printStackTrace();
			}
		}

		return ab;
	}

}
