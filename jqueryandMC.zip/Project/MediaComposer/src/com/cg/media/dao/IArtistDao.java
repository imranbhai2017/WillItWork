package com.cg.media.dao;

import java.util.List;

import com.cg.media.dto.ArtistBean;
import com.cg.media.dto.SongBean;
import com.cg.media.exception.MediaException;

public interface IArtistDao {
	public int createArtist(ArtistBean artistBean) throws MediaException;

	public int editArtist(ArtistBean artistBean) throws MediaException;

	public int assignSongToArtist(int songId, int artistId, int id)
			throws MediaException;

	public List<SongBean> searchSongByArtistId(int artistId)
			throws MediaException;

	public List<ArtistBean> viewAllArtists() throws MediaException;

	public ArtistBean searchArtistById(int artistId) throws MediaException;

}
