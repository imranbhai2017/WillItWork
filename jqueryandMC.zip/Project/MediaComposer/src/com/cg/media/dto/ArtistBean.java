package com.cg.media.dto;

import java.time.LocalDate;

public class ArtistBean {
	private int artistId;
	private String artistName;
	private String artistType;
	private LocalDate artistBornDate;
	private LocalDate artistDiedDate;
	private int createdBy;
	private LocalDate createdOn;
	private int updatedBy;
	private LocalDate updatedOn;
	private int artistDeletedFlag;

	public int getArtistId() {
		return artistId;
	}

	public void setArtistId(int artistId) {
		this.artistId = artistId;
	}

	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public String getArtistType() {
		return artistType;
	}

	public void setArtistType(String artistType) {
		this.artistType = artistType;
	}

	public LocalDate getArtistBornDate() {
		return artistBornDate;
	}

	public void setArtistBornDate(LocalDate artistBornDate) {
		this.artistBornDate = artistBornDate;
	}

	public LocalDate getArtistDiedDate() {
		return artistDiedDate;
	}

	public void setArtistDiedDate(LocalDate artistDiedDate) {
		this.artistDiedDate = artistDiedDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public LocalDate getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDate updatedOn) {
		this.updatedOn = updatedOn;
	}

	public int getArtistDeletedFlag() {
		return artistDeletedFlag;
	}

	public void setArtistDeletedFlag(int artistDeletedFlag) {
		this.artistDeletedFlag = artistDeletedFlag;
	}
}
