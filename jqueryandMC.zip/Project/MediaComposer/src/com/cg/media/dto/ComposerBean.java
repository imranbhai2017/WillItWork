package com.cg.media.dto;

import java.time.LocalDate;

public class ComposerBean {

	private int composerId;
	private String composerName;
	private LocalDate composerBornDate;
	private LocalDate composerDiedDate;
	private String composerCaeipiNum;
	private String composerMusicSocietyId;
	private String composerType;
	private int createdBy;
	private LocalDate createdOn;
	private int updatedBy;
	private LocalDate updatedOn;
	private String composerDeletedFlag;
	
	public String getComposerType() {
		return composerType;
	}

	public void setComposerType(String composerType) {
		this.composerType = composerType;
	}

	

	public String getComposerDeletedFlag() {
		return composerDeletedFlag;
	}

	public void setComposerDeletedFlag(String flag) {
		this.composerDeletedFlag = flag;
	}

	

	public int getComposerId() {
		return composerId;
	}

	public void setComposerId(int composerId) {
		this.composerId = composerId;
	}

	public String getComposerName() {
		return composerName;
	}

	public void setComposerName(String composerName) {
		this.composerName = composerName;
	}

	public LocalDate getComposerBornDate() {
		return composerBornDate;
	}

	public void setComposerBornDate(LocalDate composerBornDate) {
		this.composerBornDate = composerBornDate;
	}

	public LocalDate getComposerDiedDate() {
		return composerDiedDate;
	}

	public void setComposerDiedDate(LocalDate composerDiedDate) {
		this.composerDiedDate = composerDiedDate;
	}

	public String getComposerCaeipiNum() {
		return composerCaeipiNum;
	}

	public void setComposerCaeipiNum(String string) {
		this.composerCaeipiNum = string;
	}

	public String getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}

	public void setComposerMusicSocietyId(String composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDate getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDate createdOn) {
		this.createdOn = createdOn;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updateBy) {
		this.updatedBy = updateBy;
	}

	public LocalDate getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(LocalDate updatedOn) {
		this.updatedOn = updatedOn;
	}



}
