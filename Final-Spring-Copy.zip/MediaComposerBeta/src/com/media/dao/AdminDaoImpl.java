package com.media.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.media.dto.AdminBean;
import com.media.dto.ArtistBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;
@Repository
public class AdminDaoImpl implements IAdminDao {
	
	@PersistenceContext
	EntityManager entity;

	Logger log = Logger.getLogger("AdminDaoImpl");

	@Override
	public boolean validateAdmin(AdminBean adminBean)
			throws MediaComposerException {

		try{
		System.out.println("now in DAO");

		 System.out.println("*******************\nValues form Dao\n*********************");
		 System.out.println("Values form user input");
		 System.out.println("User ID "+adminBean.getUserId());
		 System.out.println("Password "+adminBean.getUserPassword());
		 System.out.println("*******************\nValues form Dao\n*********************");
		

		
		AdminBean adminBeanDb = entity.find(AdminBean.class,
				adminBean.getUserId());
		 System.out.println("User ID "+adminBeanDb.getUserId());
		// System.out.println("Password "+adminBeanDb.getUserPassword());
		// System.out.println("User Name "+adminBeanDb.getUserName());
		if (adminBeanDb.getUserId() == adminBean.getUserId()
				&& adminBeanDb.getUserPassword().equals(
						adminBean.getUserPassword())) {
			System.out.println("returning TRUE");
			return true;
		} else {
			System.out.println("Returning False");
			return false;
		}
		}catch(Exception e){
			System.err.println("Message : "+e.getMessage());
			return false;
		}
	}

}
