package com.media.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.media.dto.ComposerBean;
import com.media.dto.Songs;
import com.media.exception.MediaComposerException;

@Repository
public class ComposerDaoImpl implements IComposerDao {

	@PersistenceContext
	EntityManager entity;

	@Override
	@Transactional
	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaComposerException {

		Query assignQuery = null;
		try {
			System.out.println("Inserting artist song assign bean");
			String insertQueryString = "INSERT into COMPOSER_SONG_ASSOC (composer_id,song_id,created_by)values ("
					+ composerId + "," + songId + "," + id + ")";

			System.out.println("Query " + insertQueryString);
			assignQuery = entity.createNativeQuery(insertQueryString);
			return assignQuery.executeUpdate();

		}/*
		 * catch (TransactionSystemException te) { return 0; }
		 */catch (Exception e) {
			System.out.println("Check your Values");
			return 0;
		}

	}

	@Override
	public List<Songs> searchSongByComposerId(int composerId)
			throws MediaComposerException {
		List<Songs> mlist = new ArrayList<Songs>();

		Query fetchQuery = null;
		try {
			System.out.println("Inserting artist song assign bean");
			String selectArtistString = "SELECT c1.COMPOSER_ID AS cid, s.SONG_ID AS sid, c1.COMPOSER_NAME AS cname, s.SONG_NAME AS sname, s.SONG_DURATION AS sdur FROM composer_song_assoc c, composer_master c1,  song_master s WHERE c.COMPOSER_ID = "
					+ composerId
					+ " AND s.SONG_ID = c.SONG_ID and c1.composer_id = c.composer_id";

			System.out.println("Query " + selectArtistString);
			fetchQuery = entity.createNativeQuery(selectArtistString);

			List<Object[]> values = fetchQuery.getResultList();

			for (Object[] objects : values) {

				System.out.println("Printing " + objects[0] + " " + objects[1]
						+ " " + objects[2]);
				Songs songBean = new Songs();

				songBean.setId(objects[0]);
				songBean.setSongName((String) objects[1]);
				songBean.setDuration(objects[2]);
				mlist.add(songBean);

			}

			for (Songs songBean : mlist) {
				System.out.println("Song bean Values " + songBean);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlist;
	}

	@Override
	public List<ComposerBean> viewAllComposers() throws MediaComposerException {
		TypedQuery<ComposerBean> query = null;
		try {
			query = entity.createQuery("SELECT s from ComposerBean s",
					ComposerBean.class);
			System.out.println("In ComposerBean Dao");
			return query.getResultList();
		} catch (Exception e) {
			System.out
					.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
			e.printStackTrace();
		}
		return query.getResultList();
	}

	@Override
	@Transactional
	public void addComposer(ComposerBean composerBean)
			throws MediaComposerException {
		entity.persist(composerBean);

	}

	@Override
	public ComposerBean findComposerById(int composerId)
			throws MediaComposerException {

		return entity.find(ComposerBean.class, composerId);
	}

	@Override
	@Transactional
	public int editComposer(ComposerBean composerBean)
			throws MediaComposerException {
		System.out.println("Before Merge" + composerBean);
		entity.merge(composerBean);

		return 1;
	}

}
