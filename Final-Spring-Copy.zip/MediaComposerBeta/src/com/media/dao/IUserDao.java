package com.media.dao;

import com.media.dto.UserBean;
import com.media.exception.MediaComposerException;

public interface IUserDao {
	public boolean validateUser(UserBean userBean)
			throws MediaComposerException;
}
