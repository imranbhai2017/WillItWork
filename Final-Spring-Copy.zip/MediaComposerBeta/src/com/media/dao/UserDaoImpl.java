package com.media.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.media.dto.UserBean;
import com.media.exception.MediaComposerException;

@Repository
@Transactional
public class UserDaoImpl implements IUserDao {

	@PersistenceContext
	EntityManager entity;

	Logger log = Logger.getLogger("UserDaoImpl");

	@Override
	public boolean validateUser(UserBean userBean)
			throws MediaComposerException {
		try{
			System.out.println("now in DAO");

			 System.out.println("*******************\nValues form Dao\n*********************");
			 System.out.println("Values form user input");
			 System.out.println("User ID "+userBean.getUserId());
			 System.out.println("Password "+userBean.getUserPassword());
			 System.out.println("*******************\nValues form Dao\n*********************");
			

			
			UserBean userBeanDb = entity.find(UserBean.class,
					userBean.getUserId());
			 System.out.println("User ID "+userBean.getUserId());
			// System.out.println("Password "+adminBeanDb.getUserPassword());
			// System.out.println("User Name "+adminBeanDb.getUserName());
			if (userBeanDb.getUserId() == userBean.getUserId()
					&& userBeanDb.getUserPassword().equals(
							userBean.getUserPassword())) {
				System.out.println("returning TRUE");
				return true;
			} else {
				System.out.println("Returning False");
				return false;
			}
			}catch(Exception e){
				System.err.println("Message : "+e.getMessage());
				return false;
			}
	}


}
