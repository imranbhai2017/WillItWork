package com.media.dao;

import java.util.List;

import com.media.dto.ArtistBean;
import com.media.dto.ArtistSongAssign;
import com.media.dto.Songs;
import com.media.exception.MediaComposerException;

public interface IArtistDao {
	public List<ArtistBean> viewAllArtists() throws MediaComposerException;
	
	public void addArtist(ArtistBean artistBean) throws MediaComposerException;
	
	public int assignSongToArtist(ArtistSongAssign artistSongAssign)
			throws MediaComposerException;
	
	public ArtistBean findArtistById(int artistId) throws MediaComposerException;
	
	public int editArtist(ArtistBean artistBean) throws MediaComposerException;
	
	public List<Songs> searchSongByArtistId(int artistId) throws MediaComposerException;
}
