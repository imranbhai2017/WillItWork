package com.media.service;

import java.util.List;

import com.media.dto.ArtistBean;
import com.media.dto.ArtistSongAssign;
import com.media.dto.Songs;
import com.media.exception.MediaComposerException;

public interface IArtist {
	
	public int assignSongToArtist(ArtistSongAssign artistSongAssign) throws MediaComposerException;
	
	public List<ArtistBean> viewAllArtists() throws MediaComposerException;

	public List<Songs> searchSongByArtistId(int artistId) throws MediaComposerException;
	
	public void addArtist(ArtistBean artistBean) throws MediaComposerException;
	
	public ArtistBean findArtistById(int artistId) throws MediaComposerException;
	
	public int editArtist(ArtistBean artistBean) throws MediaComposerException;
	
}
