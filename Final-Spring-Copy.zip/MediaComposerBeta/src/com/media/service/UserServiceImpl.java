package com.media.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.media.dao.IUserDao;
import com.media.dao.UserDaoImpl;
import com.media.dto.UserBean;
import com.media.exception.MediaComposerException;

@Service
public class UserServiceImpl implements IUser {
	@Autowired
	IUserDao userDao;

	@Override
	public boolean validateUser(UserBean userBean)
			throws MediaComposerException {		
		return userDao.validateUser(userBean);
	}

}