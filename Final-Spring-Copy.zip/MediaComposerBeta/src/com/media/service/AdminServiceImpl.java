package com.media.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.media.dao.IAdminDao;
import com.media.dto.AdminBean;
import com.media.dto.ArtistBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

@Service
public class AdminServiceImpl implements IAdmin {

	@Autowired
	IAdminDao admindao;
	
	@Override
	public boolean validateAdmin(AdminBean adminBean)
			throws MediaComposerException {
		System.out.println("Came to service layer");
		return admindao.validateAdmin(adminBean);
	}

}

