package com.media.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.media.dto.AdminBean;
import com.media.dto.ArtistBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

public interface IAdmin {
	
	public boolean validateAdmin(AdminBean adminBean)
			throws MediaComposerException;
	//public List<SongBean> viewAllSongs() throws MediaComposerException;
	

}
