package com.media.service;

import java.util.List;

import com.media.dto.ComposerBean;
import com.media.dto.Songs;
import com.media.exception.MediaComposerException;

public interface IComposer {

	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaComposerException;

	public List<Songs> searchSongByComposerId(int composerId)
			throws MediaComposerException;

	public List<ComposerBean> viewAllComposers() throws MediaComposerException;

	public void addComposer(ComposerBean composerBean)
			throws MediaComposerException;

	public ComposerBean findComposerById(int composerId)
			throws MediaComposerException;

	public int editComposer(ComposerBean composerBean)
			throws MediaComposerException;

}
