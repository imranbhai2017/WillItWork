package com.media.service;

import java.util.List;

import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

public interface ISong {
	public List<SongBean> viewAllSongs() throws MediaComposerException;
}
