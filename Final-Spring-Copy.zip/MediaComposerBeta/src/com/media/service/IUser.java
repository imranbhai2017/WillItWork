package com.media.service;

import com.media.dto.UserBean;
import com.media.exception.MediaComposerException;

public interface IUser {

	public boolean validateUser(UserBean userBean)
			throws MediaComposerException;

}
