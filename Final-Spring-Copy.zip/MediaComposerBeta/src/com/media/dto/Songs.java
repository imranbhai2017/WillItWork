package com.media.dto;

public class Songs {
	
	private String songName;
	private Object Duration;
	private Object Id;
	
	
	public String getSongName() {
		return songName;
	}
	public void setSongName(String songName) {
		this.songName = songName;
	}
	@Override
	public String toString() {
		return "Songs [songName=" + songName + ", Duration=" + Duration
				+ ", Id=" + Id + "]";
	}
	public Object getDuration() {
		return Duration;
	}
	public void setDuration(Object duration) {
		Duration = duration;
	}
	public Object getId() {
		return Id;
	}
	public void setId(Object id) {
		Id = id;
	}
	
	
	
}
