package com.media.dto;

import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.ws.rs.DefaultValue;

import org.hibernate.validator.NotEmpty;
import org.hibernate.validator.NotNull;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "ARTIST_MASTER")
public class ArtistBean {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ARTIST_SEQ")
	@SequenceGenerator(name = "ARTIST_SEQ", sequenceName = "ARTIST_SEQ", allocationSize = 1)
	@Column(name = "ARTIST_ID")
	private int artistId;

	@NotEmpty
	@Column(name = "ARTIST_NAME")
	private String artistName;
	
	@NotEmpty
	@Column(name = "ARTIST_TYPE")
	private String artistType;

	@NotNull
	@Column(name = "ARTIST_BORNDATE")
	private Date artistBornDate;

	@Override
	public String toString() {
		return "ArtistBean [artistId=" + artistId + ", artistName="
				+ artistName + ", artistType=" + artistType
				+ ", artistBornDate=" + artistBornDate + ", artistDiedDate="
				+ artistDiedDate + ", createdBy=" + createdBy + ", createdOn="
				+ createdOn + ", updatedBy=" + updatedBy + ", updatedOn="
				+ updatedOn + ", artistDeletedFlag=" + artistDeletedFlag + "]";
	}

	@Column(name = "ARTIST_DIEDDATE")
	private Date artistDiedDate;

	@Column(name = "CREATED_BY")
	private int createdBy;

	@Column(name = "CREATED_ON")
	private Date createdOn;

	@Column(name = "UPDATED_BY")
	private int updatedBy;

	@Column(name = "UPDATED_ON")
	private Date updatedOn;

	@Column(name = "ARTIST_DELETEDFLAG")
	private String artistDeletedFlag;

	public int getArtistId() {
		return artistId;
	}

	public void setArtistId(int artistId) {
		this.artistId = artistId;
	}

	public String getArtistName() {
		return artistName;
	}

	public void setArtistName(String artistName) {
		this.artistName = artistName;
	}

	public String getArtistType() {
		return artistType;
	}

	public void setArtistType(String artistType) {
		this.artistType = artistType;
	}

	public Date getArtistBornDate() {
		return artistBornDate;
	}

	public void setArtistBornDate(Date artistBornDate) {
		this.artistBornDate = artistBornDate;
	}

	public Date getArtistDiedDate() {
		return artistDiedDate;
	}

	public void setArtistDiedDate(Date artistDiedDate) {

		this.artistDiedDate = artistDiedDate;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date date) {
		this.createdOn = date;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}

	public void setArtistDeletedFlag(String artistDeletedFlag) {
		this.artistDeletedFlag = artistDeletedFlag;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public String getArtistDeletedFlag() {
		return artistDeletedFlag;
	}

}
