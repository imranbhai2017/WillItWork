package com.media.dto;

import java.sql.Date;
import java.time.LocalDate;

import javafx.beans.DefaultProperty;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.ws.rs.DefaultValue;

import org.hibernate.validator.NotNull;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="COMPOSER_MASTER")
public class ComposerBean {
	
	@Id	
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="COMPOSER_SEQ")
	@SequenceGenerator(name="COMPOSER_SEQ",sequenceName="COMPOSER_SEQ",allocationSize=1)
	@Column(name="COMPOSER_ID")
	@NotNull
	private int composerId;
	
	@NotEmpty
	@Column(name="COMPOSER_NAME")
	private String composerName;
	
	@NotNull
	@Column(name="COMPOSER_BORNDATE")
	private Date composerBornDate;

	@Override
	public String toString() {
		return "ComposerBean [composerId=" + composerId + ", composerName="
				+ composerName + ", composerBornDate=" + composerBornDate
				+ ", composerDiedDate=" + composerDiedDate
				+ ", composerCaeipiNum=" + composerCaeipiNum
				+ ", composerMusicSocietyId=" + composerMusicSocietyId
				+ ", composerType=" + composerType + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", updatedBy=" + updatedBy
				+ ", updatedOn=" + updatedOn + ", composerDeletedFlag="
				+ composerDeletedFlag + "]";
	}

	@Column(name="COMPOSER_DIEDDATE")
	private Date composerDiedDate;
	
	@NotEmpty
	@Column(name="COMPOSER_CAEIPINUMBER")
	private String composerCaeipiNum;
	
	@NotEmpty
	@Column(name="COMPOSER_MUSICSOCIETYID")
	private String composerMusicSocietyId;
	
	@Column(name="COMPOSER_TYPE")
	private String composerType;
	
	
	@Column(name="CREATED_BY")
	private int createdBy;

	
	@Column(name="CREATED_ON")
	private Date createdOn;
	
	@Column(name="UPDATED_BY")
	private int updatedBy;
	
	@Column(name="UPDATED_ON")
	private Date updatedOn;
	
	@Column(name="COMPOSER_DELETEDFLAG")
	private String composerDeletedFlag;
	
	public String getComposerType() {
		return composerType;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setComposerType(String composerType) {
		this.composerType = composerType;
	}

	

	public String getComposerDeletedFlag() {
		return composerDeletedFlag;
	}

	public void setComposerDeletedFlag(String flag) {
		this.composerDeletedFlag = flag;
	}

	

	public int getComposerId() {
		return composerId;
	}

	public void setComposerId(int composerId) {
		this.composerId = composerId;
	}

	public String getComposerName() {
		return composerName;
	}

	public void setComposerName(String composerName) {
		this.composerName = composerName;
	}

	public Date getComposerBornDate() {
		return composerBornDate;
	}

	public void setComposerBornDate(Date composerBornDate) {
		this.composerBornDate = composerBornDate;
	}

	public Date getComposerDiedDate() {
		return composerDiedDate;
	}

	public void setComposerDiedDate(Date composerDiedDate) {
		this.composerDiedDate = composerDiedDate;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public String getComposerCaeipiNum() {
		return composerCaeipiNum;
	}

	public void setComposerCaeipiNum(String string) {
		this.composerCaeipiNum = string;
	}

	public String getComposerMusicSocietyId() {
		return composerMusicSocietyId;
	}

	public void setComposerMusicSocietyId(String composerMusicSocietyId) {
		this.composerMusicSocietyId = composerMusicSocietyId;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updateBy) {
		this.updatedBy = updateBy;
	}

	


}
