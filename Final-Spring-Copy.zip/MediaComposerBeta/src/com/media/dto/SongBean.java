package com.media.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="SONG_MASTER")
public class SongBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="SONG_SEQ")
	 @SequenceGenerator(name="SONG_SEQ",sequenceName="SONG_SEQ",allocationSize=1)
	@Column(name="SONG_ID")
	private int songId;
	
	@Column(name="SONG_NAME")
	private String songName;
	
	@Override
	public String toString() {
		return "SongBean [songId=" + songId + ", songName=" + songName
				+ ", songDuration=" + songDuration + ", createdBy=" + createdBy
				+ ", createdOn=" + createdOn + ", updatedBy=" + updatedBy
				+ ", updatedOn=" + updatedOn + ", artistBean=" + artistBean
				+ ", songDeletedFlag=" + songDeletedFlag + "]";
	}

	@Column(name="SONG_DURATION")
	private int songDuration;
	
	


	@Column(name="CREATED_BY")
	private int createdBy;
	
	

	@Column(name="CREATED_ON")
	private Date createdOn;
	
	@Column(name="UPDATED_BY")
	private int updatedBy;
	
	@Column(name="UPDATED_ON")
	private Date updatedOn;
	
	@OneToOne
	private ArtistBean artistBean;
	
	public Date getCreatedOn() {
		return createdOn;
	}

	public ArtistBean getArtistBean() {
		return artistBean;
	}

	public void setArtistBean(ArtistBean artistBean) {
		this.artistBean = artistBean;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	@Column(name="SONG_DELETEDFLAG")
	private char songDeletedFlag;
	

	public int getSongId() {
		return songId;
	}

	public void setSongId(int songId) {
		this.songId = songId;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public int getSongDuration() {
		return songDuration;
	}

	public void setSongDuration(int songDuration) {
		this.songDuration = songDuration;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}


	public int getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(int updatedBy) {
		this.updatedBy = updatedBy;
	}


	public char getSongDeletedFlag() {
		return songDeletedFlag;
	}

	public void setSongDeletedFlag(char songDeletedFlag) {
		this.songDeletedFlag = songDeletedFlag;
	}

	

}


