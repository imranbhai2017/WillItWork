package com.media.util;

public class QueryMapper {

	public static final String ADMIN_LOGIN_QUERY = "SELECT USER_ID,USER_PASSWORD from ADMIN_MASTER where USER_ID=?";

	public static final String USER_INSERT_QUERY = "Insert into User_Master values(USER_SEQ.NEXTVAL,?,?,?,?,?)";

	public static final String USER_SELECT_QUERY = "Select * from User_Master where User_ID=?";

	public static final String USER_SEQUENCE_QUERY = "SELECT USER_SEQ.CURRVAL FROM DUAL";

	public static final String COMPOSER_INSERT_QUERY = "Insert into Composer_Master values(COMPOSER_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?,?)";

	public static final String COMPOSER_UPDATE_QUERY = "UPDATE Composer_Master SET Composer_Name=?,Composer_BornDate=?,Composer_DiedDate=?,Composer_CaeipiNumber=?,Composer_MusicSocietyID=?,Updated_By=?,Updated_On=?,Composer_DeletedFlag=? WHERE Composer_Id=?";

	public static final String COMPOSER_SELECT_QUERY = "Select * from Composer_Master where Composer_id=?";

	public static final String ARTIST_INSERT_QUERY = "Insert into Artist_Master values(ARTIST_SEQ.NEXTVAL,?,?,?,?,?,?,?,?,?)";

	public static final String ARTIST_SELECT_QUERY = "Select * from Artist_Master where Artist_Id=?";

	public static final String ARTIST_SELECT_BY_ID_SONGS = "SELECT a1.artist_id AS aid, s.SONG_ID AS sid,am.artist_name AS aname,s.SONG_NAME AS sname,s.SONG_DURATION AS sdur FROM artist_song_assoc a1,  artist_master am, song_master s WHERE a1.artist_id = ? AND s.SONG_ID = a1.SONG_ID AND a1.artist_id  = am.artist_id";

	public static final String ARTIST_UPDATE_QUERY = "UPDATE Artist_Master SET Artist_Name=?,Artist_Type=?,Artist_BornDate=?,Artist_DiedDate=?,Updated_By=?,Updated_On=? WHERE Artist_Id=?";

	public static final String ARTISTASS_INSERT_QUERY = "Insert into Artist_Song_Assoc values(?,?,?,?,?,?)";

	public static final String SONGASS_SELECT_QUERY = "Select * from Artist_Song_Assoc where Artist_Id=?";

	public static final String COMPOSER_ASS_INSERT_QUERY = "Insert into Composer_Song_Assoc values(?,?,?,?,?,?)";

	public static final String COMPOSERASS_SELECT_QUERY = "Select * from Composer_Song_Assoc where Composer_Id=?";

	public static final String COMPOSER_SELECT_BY_ID_SONGS = "SELECT c1.COMPOSER_ID AS cid, s.SONG_ID AS sid, c1.COMPOSER_NAME AS cname, s.SONG_NAME AS sname, s.SONG_DURATION AS sdur FROM composer_song_assoc c, composer_master c1,  song_master s WHERE c.COMPOSER_ID = ? AND s.SONG_ID = c.SONG_ID and c1.composer_id = c.composer_id";

	public static final String COMPOSER_SELECT_BY_ID = "SELECT * from COMPOSER_MASTER WHERE composer_id=?";

	public static final String COMPOSER_SELECTALL_QUERY = "Select * from Composer_Master";

	public static final String ARTIST_SELECTALL_QUERY = "Select * from Artist_Master";

	public static final String SONG_SELECT_ALL_OLD = "SELECT s.song_id as song_id, s.song_name as SONG_NAME, s.song_duration as song_duration, am.ARTIST_ID as aid, am.artist_name as artist_name, cm.COMPOSER_ID as cid, cm.composer_name as composer_name FROM song_master s, artist_song_assoc a, composer_song_assoc c, composer_master cm, artist_master am WHERE a.song_id (+) = s.song_id AND   c.song_id (+) = s.song_id AND   cm.composer_id(+)= c.composer_id AND am.ARTIST_ID(+)=a.ARTIST_ID";

	public static final String SONG_SELECT_ALL = "SELECT s.song_id as song_id, s.song_name as SONG_NAME, s.song_duration as song_duration, am.ARTIST_ID as aid, am.artist_name as artist_name, cm.COMPOSER_ID as cid, cm.composer_name as composer_name FROM song_master s, artist_song_assoc a, composer_song_assoc c, composer_master cm, artist_master am WHERE a.song_id (+) = s.song_id AND   c.song_id (+) = s.song_id AND   cm.composer_id(+)= c.composer_id AND am.ARTIST_ID(+)=a.ARTIST_ID";

	public static final String USER_LOGIN_QUERY = "SELECT USER_ID,USER_PASSWORD from user_master where USER_ID=?";
}
