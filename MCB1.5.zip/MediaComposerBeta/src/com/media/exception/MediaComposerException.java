package com.media.exception;

public class MediaComposerException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3891766908832886077L;

	public MediaComposerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public MediaComposerException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public MediaComposerException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MediaComposerException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MediaComposerException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
