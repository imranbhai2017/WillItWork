package com.media.service;

import com.media.exception.MediaComposerException;

public interface IUser {

	public boolean validateUser(int userId, String password)
			throws MediaComposerException;

}
