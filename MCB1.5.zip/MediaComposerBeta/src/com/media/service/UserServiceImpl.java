package com.media.service;

import com.media.dao.IUserDao;
import com.media.dao.UserDaoImpl;
import com.media.exception.MediaComposerException;


public class UserServiceImpl implements IUser {
	
	IUserDao userDao = new UserDaoImpl();

	@Override
	public boolean validateUser(int userId, String password)
			throws MediaComposerException {		
		return userDao.validateUser(userId, password);
	}

}