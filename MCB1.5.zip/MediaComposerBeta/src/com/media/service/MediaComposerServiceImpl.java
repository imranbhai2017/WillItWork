package com.media.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.media.dao.IArtistDao;
import com.media.dao.IComposerDao;
import com.media.dto.ArtistBean;
import com.media.dto.ArtistSongAssign;
import com.media.dto.ComposerBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

@Service
public class MediaComposerServiceImpl implements IComposer, IArtist{

	@Autowired
	IArtistDao artistDao;
	
	@Autowired
	IComposerDao composerDao;
	
	@Override
	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaComposerException {
		return composerDao.assignSongToComposer(songId, composerId, id);
	}

	@Override
	public List<SongBean> searchSongByComposerId(int composerId)
			throws MediaComposerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int assignSongToArtist(ArtistSongAssign artistSongAssign)
			throws MediaComposerException {
		System.out.println("In Service Layer");
		return artistDao.assignSongToArtist(artistSongAssign);
	}

	@Override
	public List<ArtistBean> viewAllArtists() throws MediaComposerException {
		System.out.println("Media Composer Impl View All Artists");
		return artistDao.viewAllArtists();
	}


	@Override
	public List<SongBean> searchSongByArtistId(int artistId)
			throws MediaComposerException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ComposerBean> viewAllComposers() throws MediaComposerException {
		System.out.println("Media Composer Impl View All Artists");
		return composerDao.viewAllComposers();
	}

	@Override
	public void addComposer(ComposerBean composerBean)
			throws MediaComposerException {
		System.out.println("add Composer Service");
		composerDao.addComposer(composerBean);
		
	}

	@Override
	public void addArtist(ArtistBean artistBean) throws MediaComposerException {
		System.out.println("add Artist Service");
		
		artistDao.addArtist(artistBean); 
	}

	@Override
	public ArtistBean findArtistById(int artistId)
			throws MediaComposerException {
		return artistDao.findArtistById(artistId);
	}

	@Override
	public int editArtist(ArtistBean artistBean) throws MediaComposerException {
		return artistDao.editArtist(artistBean);
	}

	@Override
	public ComposerBean findComposerById(int composerId)
			throws MediaComposerException {
		
		return composerDao.findComposerById(composerId);
	}

	@Override
	public int editComposer(ComposerBean composerBean)
			throws MediaComposerException {
	
		return composerDao.editComposer(composerBean);
	}



}
