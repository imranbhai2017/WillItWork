package com.media.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.media.dto.AdminBean;
import com.media.dto.ArtistBean;
import com.media.dto.ArtistSongAssign;
import com.media.dto.ComposerBean;
import com.media.dto.SongBean;
import com.media.dto.UserBean;
import com.media.exception.MediaComposerException;
import com.media.service.IAdmin;
import com.media.service.IArtist;
import com.media.service.IComposer;
import com.media.service.ISong;

@Controller
public class MediaController {

	@Autowired
	IAdmin adminService;

	@Autowired
	ISong songService;

	@Autowired
	IArtist artistService;

	@Autowired
	IComposer composerService;

	@RequestMapping("/home")
	public String home() throws MediaComposerException {
		System.out.println("Came /home");
		return "index";

	}

	@RequestMapping("/adminCheck.obj")
	public ModelAndView adminCheck(AdminBean adminBean, BindingResult result,
			HttpSession session) throws MediaComposerException {
		ModelAndView modelAndView = new ModelAndView();

		System.out.println("Values form user input");
		System.out.println("User ID " + adminBean.getUserId());
		System.out.println("Password " + adminBean.getUserPassword());

		try {

			if (adminService.validateAdmin(adminBean)) {

				session.setAttribute("userId", adminBean.getUserId());

				modelAndView.addObject("admin", adminBean);
				modelAndView.setViewName("adminPanel");
				return modelAndView;
			} else {
				modelAndView.addObject("error", "Invalid Username or Password");
				modelAndView.setViewName("error");
				return modelAndView;
			}

		} catch (NullPointerException ne) {
			modelAndView.addObject("error",
					"Invalid Username or Password from catch");
			modelAndView.setViewName("error");
			return modelAndView;
		}
	}

	@RequestMapping("/userCheck.obj")
	public String userCheck(UserBean userBean, BindingResult result)
			throws MediaComposerException {
		// To do some changes for the user
		return null;
	}

	@RequestMapping("/viewAllSongs")
	public ModelAndView viewAllSongs(HttpSession session)
			throws MediaComposerException {
		ModelAndView mv = null;

		if (!isSessionAvailable(session)) {
			mv = new ModelAndView();
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}

		try {
			System.out.println("Above List");
			List<SongBean> songList = songService.viewAllSongs();
			mv = new ModelAndView();
			mv.addObject("songList", songList);
			mv.setViewName("viewAllSongs");
		} catch (Exception e) {
			System.out.println("This is exception");
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping("/newComposer")
	public ModelAndView createComposer(HttpSession session) {
		System.out.println("Came to new Composer mapping");
		ModelAndView mv = new ModelAndView();

		if (!isSessionAvailable(session)) {
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}

		mv.addObject("ComposerBean", new ComposerBean());
		mv.setViewName("createComposer");
		return mv;
	}

	@RequestMapping("/addComposer")
	public ModelAndView addComposer(
			@ModelAttribute("ComposerBean") @Valid ComposerBean composerBean,
			@RequestParam("composerDDate") String dDate, BindingResult result,
			HttpSession session) throws MediaComposerException {
		ModelAndView mv = new ModelAndView();
		if (!isSessionAvailable(session)) {
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}
		Date diedDate = (dDate.contains("-")) ? Date.valueOf(dDate) : null;
		if (result.hasErrors()) {
			mv.setViewName("createComposer");
			return mv;
		} else {
			composerBean.setCreatedBy((int) session.getAttribute("userId"));
			composerBean.setUpdatedBy((int) session.getAttribute("userId"));
			composerBean.setCreatedOn(Date.valueOf(LocalDate.now()));
			composerBean.setUpdatedOn(Date.valueOf(LocalDate.now()));
			composerBean.setComposerDiedDate(diedDate);
			composerService.addComposer(composerBean);
			mv.addObject("msg", "Composer Added Succesfully");
			mv.setViewName("success");
		}
		return mv;
	}

	@RequestMapping("/addArtist")
	public String addArtist(
			@ModelAttribute("ArtistBean") @Valid ArtistBean artistBean,
			@RequestParam("artistDDate") String dDate, BindingResult result,
			HttpSession session) throws MediaComposerException {

		Date diedDate = (dDate.contains("-")) ? Date.valueOf(dDate) : null;
		if (result.hasErrors()) {
			return "createArtist";
		} else {
			System.out.println(artistBean.getArtistBornDate() + " <-- BDate ");
			System.out.println(artistBean.getArtistDiedDate() + " <-- DDate ");
			artistBean.setCreatedBy((int) session.getAttribute("userId"));
			artistBean.setUpdatedBy((int) session.getAttribute("userId"));
			artistBean.setArtistDiedDate(diedDate);
			artistBean.setCreatedOn(Date.valueOf(LocalDate.now()));
			artistBean.setUpdatedOn(Date.valueOf(LocalDate.now()));
			artistService.addArtist(artistBean);
		}
		System.out.println("Came to save Artist Mapping");
		return "createArtist";
	}

	@RequestMapping("/newArtist")
	public ModelAndView createArtist() {
		System.out.println("Came to new artist mapping");
		ModelAndView mv = new ModelAndView();
		mv.addObject("ArtistBean", new ArtistBean());
		mv.setViewName("createArtist");
		return mv;
	}

	@RequestMapping("/assignSongToArtist")
	public String assignSongToArtist() {
		System.out.println("Came to Assign song ini n n  mapping");
		return "artistAssignSong";
	}

	@RequestMapping("/saveAssignSongToArtist")
	public ModelAndView saveAssignSongToArtist(@RequestParam int artistId,
			@RequestParam int songId, HttpSession session)
			throws MediaComposerException {
		ModelAndView mv = new ModelAndView();
		if (!isSessionAvailable(session)) {
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}
		try {
			System.out.println("Now in assign song else");
			ArtistSongAssign artistSongAssign = new ArtistSongAssign();
			artistSongAssign.setCreatedBy((int) session.getAttribute("userId"));
			artistSongAssign.setCreatedOn(Date.valueOf(LocalDate.now()));
			artistSongAssign.setArtistId(artistId);
			artistSongAssign.setSongId(songId);
			int result = artistService.assignSongToArtist(artistSongAssign);

			if (result > 0) {
				mv.addObject("msg", "Successfully Assigned");
				mv.setViewName("artistAssignSong");
			} else {
				mv.addObject("msg", "Check the ArtistId/SongId");
				mv.setViewName("artistAssignSong");
			}

		} catch (Exception e) {
			System.out.println("Exception Handled");
			mv.addObject("msg", "Check the ArtistId/SongId");
			mv.setViewName("artistAssignSong");
		}
		System.out.println("Came to assign Artist Mapping");
		return mv;
	}

	@RequestMapping("/assignSongToComposer")
	public String assignSongToComposer() {
		System.out.println("Came to Assign song composer");
		return "composerAssignSong";
	}

	@RequestMapping("/saveAssignSongToComposer")
	public ModelAndView saveAssignSongToComposer(@RequestParam int composerId,
			@RequestParam int songId, HttpSession session)
			throws MediaComposerException {
		ModelAndView mv = new ModelAndView();
		if (!isSessionAvailable(session)) {
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}
		try {
			System.out.println("Now in assign song else");
			int id = (int) session.getAttribute("userId");
			int result = composerService.assignSongToComposer(songId,
					composerId, id);
			if (result > 0) {
				mv.addObject("msg", "Successfully Assigned");
				mv.setViewName("composerAssignSong");
			} else {
				mv.addObject("msg", "Check the ComposerId/SongId");
				mv.setViewName("composerAssignSong");
			}
		} catch (Exception e) {
			System.out.println("Exception Handled");
			mv.addObject("msg", "Check the ComposerId/SongId");
			mv.setViewName("composerAssignSong");
		}
		System.out.println("Came to assign Composer Mapping");
		return mv;
	}

	@RequestMapping("/saveEditedArtist")
	public ModelAndView saveEditedArtist(
			@ModelAttribute("ArtistBean") @Valid ArtistBean artistBean,
			@RequestParam("artistDDate") String dDate, BindingResult result,
			HttpSession session) throws MediaComposerException {
		ModelAndView mv = new ModelAndView();
		Date diedDate = (dDate.contains("-")) ? Date.valueOf(dDate) : null;
		System.out.println("Bad request after reaching here");
		if (result.hasErrors()) {
			System.out.println("Died Date In IF " + diedDate);
			mv.setViewName("editArtist");
		} else {
			System.out.println("Now in assign song else");
			artistBean.setUpdatedBy((int) session.getAttribute("userId"));
			artistBean.setUpdatedOn(Date.valueOf(LocalDate.now()));
			System.out.println("Died Date in ELSE" + diedDate);
			artistBean.setArtistDiedDate(diedDate);
			System.out.println("Artist Id " + artistBean.getArtistId());
			artistService.editArtist(artistBean);
			mv.addObject("msg", "Artist Detail Updated Succesfully");
			mv.setViewName("success");
			// artistService.assignSongToArtist(artistSongAssign);
		}
		System.out.println("Came to assign Artist Mapping");
		return mv;
	}

	@RequestMapping("/saveEditedComposer")
	public ModelAndView saveEditedComposer(
			@ModelAttribute("ComposerBean") @Valid ComposerBean composerBean,
			@RequestParam("composerDDate") String dDate, BindingResult result,
			HttpSession session) throws MediaComposerException {
		ModelAndView mv = new ModelAndView();

		if (!isSessionAvailable(session)) {
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}

		Date diedDate = (dDate.contains("-")) ? Date.valueOf(dDate) : null;
		if (result.hasErrors()) {
			System.out.println("Died Date In IF " + diedDate);
			mv.setViewName("editComposer");
		} else {
		
			composerBean.setUpdatedBy((int) session.getAttribute("userId"));
			composerBean.setUpdatedOn(Date.valueOf(LocalDate.now()));
			System.out.println("Died Date in ELSE" + diedDate);
			composerBean.setComposerDiedDate(diedDate);
			System.out.println("Composer Id " + composerBean.getComposerId());
			composerService.editComposer(composerBean);
			mv.addObject("msg", "Composer Detail Updated Succesfully");
			mv.setViewName("success");
			// artistService.assignSongToArtist(artistSongAssign);
		}
		System.out.println("Came to assign Composer Mapping");
		return mv;
	}

	@RequestMapping("/editArtist")
	public ModelAndView editArtist(Model model,
			@RequestParam("artistId") int artistId)
			throws MediaComposerException {

		ModelAndView mv = new ModelAndView();

		ArtistBean artistBean = artistService.findArtistById(artistId);
		model.addAttribute("ArtistBean", artistBean);

		System.out.println("While Finding " + artistBean);

		mv.setViewName("editArtist");
		System.out.println("Came to edit Artist Mapping");

		return mv;
	}

	@RequestMapping("/editComposer")
	public ModelAndView editComposer(Model model,
			@RequestParam("composerId") int composerId, HttpSession session)
			throws MediaComposerException {
		ModelAndView mv = new ModelAndView();

		if (!isSessionAvailable(session)) {
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}

		ComposerBean composerBean = composerService
				.findComposerById(composerId);
		model.addAttribute("ComposerBean", composerBean);

		System.out.println("While Finding " + composerBean);

		mv.setViewName("editComposer");
		System.out.println("Came to edit Composer Mapping");

		return mv;
	}

	@RequestMapping("/adminLogin")
	public String adminLogin() {
		System.out.println("Came to Admin login mapping");
		return "adminLogin";
	}

	@RequestMapping("/userLogin")
	public String userLogin() {
		return "userLogin";
	}

	@RequestMapping("/logout")
	public ModelAndView userLogout(HttpSession session) {
		session.invalidate();

		ModelAndView mv = new ModelAndView();
		mv.addObject("msg", "Logged Out Successfully");
		mv.setViewName("index");
		return mv;
	}

	@RequestMapping("/viewAllArtists")
	public ModelAndView viewAllArtists(HttpSession session)
			throws MediaComposerException {
		ModelAndView mv = null;
		if (!isSessionAvailable(session)) {
			mv = new ModelAndView();
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}

		try {
			System.out.println("Above List");
			List<ArtistBean> artistList = artistService.viewAllArtists();
			mv = new ModelAndView();
			mv.addObject("artistList", artistList);
			mv.setViewName("viewAllArtists");
		} catch (Exception e) {
			System.out.println("Exception");
			e.printStackTrace();
		}

		return mv;
	}

	@RequestMapping("/viewAllComposers")
	public ModelAndView viewAllComposers(HttpSession session)
			throws MediaComposerException {
		ModelAndView mv = null;

		if (!isSessionAvailable(session)) {
			mv = new ModelAndView();
			mv.addObject("msg", "Login First");
			mv.setViewName("adminLogin");
			return mv;
		}

		try {
			System.out.println("Above List");
			List<ComposerBean> composerList = composerService
					.viewAllComposers();
			mv = new ModelAndView();
			mv.addObject("composerList", composerList);
			mv.setViewName("viewAllComposers");
		} catch (Exception e) {
			System.out.println("Exception");
			e.printStackTrace();
		}
		return mv;
	}

	public boolean isSessionAvailable(HttpSession session) {
		if (session.getAttribute("userId") != null) {
			return true;
		} else {
			return false;
		}

	}

}
