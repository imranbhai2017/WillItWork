package com.media.dao;

import java.util.List;

import com.media.dto.ComposerBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

public interface IComposerDao {

	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaComposerException;

	public List<SongBean> searchSongByComposerId(int composerId)
			throws MediaComposerException;

	public List<ComposerBean> viewAllComposers() throws MediaComposerException;

	public void addComposer(ComposerBean composerBean)
			throws MediaComposerException;
	
public ComposerBean findComposerById(int composerId) throws MediaComposerException;
	
	public int editComposer(ComposerBean composerBean) throws MediaComposerException;
	
}
