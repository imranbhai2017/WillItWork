package com.media.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.media.dto.UserBean;
import com.media.exception.MediaComposerException;

@Repository
@Transactional
public class UserDaoImpl implements IUserDao {

	@PersistenceContext
	EntityManager entity;

	Logger log = Logger.getLogger("UserDaoImpl");

	@Override
	public boolean validateUser(int userId, String password)
			throws MediaComposerException {
		
		UserBean userBean = entity.find(UserBean.class,userId);
		
				if (userBean.getUserId() == userId && userBean.getUserPassword().equals(password)) {
					return true;
				} else {
					return false;
				}

	}

}
