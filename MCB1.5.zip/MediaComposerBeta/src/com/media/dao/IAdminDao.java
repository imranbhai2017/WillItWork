package com.media.dao;

import com.media.dto.AdminBean;
import com.media.exception.MediaComposerException;

public interface IAdminDao {
	public boolean validateAdmin(AdminBean adminBean)
			throws MediaComposerException;

}
