package com.media.dao;

import java.util.List;

import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

public interface ISongDao {
	public List<SongBean> viewAllSongs() throws MediaComposerException;
}
