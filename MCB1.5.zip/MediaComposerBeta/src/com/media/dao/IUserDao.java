package com.media.dao;

import com.media.exception.MediaComposerException;

public interface IUserDao {
	public boolean validateUser(int userId, String password)
			throws MediaComposerException;
}
