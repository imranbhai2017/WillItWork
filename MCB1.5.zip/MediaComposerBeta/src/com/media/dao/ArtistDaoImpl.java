package com.media.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionSystemException;

import com.media.dto.ArtistBean;
import com.media.dto.ArtistSongAssign;
import com.media.exception.MediaComposerException;

@Repository
public class ArtistDaoImpl implements IArtistDao {

	@PersistenceContext
	EntityManager entity;

	@Override
	public List<ArtistBean> viewAllArtists() throws MediaComposerException {
		TypedQuery<ArtistBean> query = null;
		try {
			query = entity.createQuery("SELECT s from ArtistBean s",
					ArtistBean.class);
			System.out.println("In ArtistBean Dao");
			return query.getResultList();
		} catch (Exception e) {
			System.out
					.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
			e.printStackTrace();
		}
		return query.getResultList();
	}

	@Override
	@Transactional
	public void addArtist(ArtistBean artistBean) throws MediaComposerException {
		entity.persist(artistBean);

	}

	@Override
	@Transactional
	public int assignSongToArtist(ArtistSongAssign artistSongAssign)
			throws MediaComposerException {
		Query assignQuery = null;
		try {
			System.out.println("Inserting artist song assign bean");
			String insertQueryString = "INSERT into ARTIST_SONG_ASSOC (artist_id,song_id,created_by)values ("
					+ artistSongAssign.getArtistId()
					+ ","
					+ artistSongAssign.getSongId()
					+ ","
					+ artistSongAssign.getCreatedBy() + ")";

			System.out.println("Query " + insertQueryString);
			assignQuery = entity.createNativeQuery(insertQueryString);
			return assignQuery.executeUpdate();

		} catch (TransactionSystemException te) {
			return 0;
		} catch (Exception e) {
			System.out.println("Check your Values");
			return 0;
		}

	}

	@Override
	public ArtistBean findArtistById(int artistId)
			throws MediaComposerException {
		return entity.find(ArtistBean.class, artistId);
	}

	@Override
	@Transactional
	public int editArtist(ArtistBean artistBean) throws MediaComposerException {

		System.out.println("Details");

		System.out.println(artistBean);

		entity.merge(artistBean);
		return 0;
	}

}
