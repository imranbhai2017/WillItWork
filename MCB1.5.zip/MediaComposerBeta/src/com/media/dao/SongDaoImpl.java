package com.media.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.media.dto.ArtistBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

@Repository
public class SongDaoImpl implements ISongDao {

	@PersistenceContext
	EntityManager entity;

	@Override
	public List<SongBean> viewAllSongs() throws MediaComposerException {
		TypedQuery<SongBean> query =null;
		List<SongBean> songList = new ArrayList<SongBean>();
		try{
		 query = entity.createQuery(
				"SELECT s from SongBean s", SongBean.class);
		System.out.println("In Song Dao");
		songList = query.getResultList();
		return songList;
		}
		catch(Exception e){
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
			e.printStackTrace();
		}
		return songList;
	}
	
/*	@Override
	public List<ArtistBean> viewAllArtists() throws MediaComposerException {
		TypedQuery<ArtistBean> query =null;
		List<ArtistBean> artistList = new ArrayList<ArtistBean>();
		try{
		 query = entity.createQuery(
				"SELECT s from ArtistBean s", ArtistBean.class);
		System.out.println("In Artist Dao");
		artistList = query.getResultList();
		return artistList;
		}
		catch(Exception e){
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
			e.printStackTrace();
		}
		return artistList;
	}*/


}
