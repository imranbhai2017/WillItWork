package com.media.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.TransactionSystemException;

import com.media.dto.ComposerBean;
import com.media.dto.SongBean;
import com.media.exception.MediaComposerException;

@Repository
public class ComposerDaoImpl implements IComposerDao {

	@PersistenceContext
	EntityManager entity;
	
	@Override
	@Transactional
	public int assignSongToComposer(int songId, int composerId, int id)
			throws MediaComposerException {
	
		Query assignQuery = null;
		try {
			System.out.println("Inserting artist song assign bean");
			String insertQueryString = "INSERT into COMPOSER_SONG_ASSOC (composer_id,song_id,created_by)values ("
					+ composerId + ","
					+songId + ","
					+ id+ ")";

			System.out.println("Query " + insertQueryString);
			assignQuery = entity.createNativeQuery(insertQueryString);
			return assignQuery.executeUpdate();

		}/* catch (TransactionSystemException te) {
			return 0;
		}*/ catch (Exception e) {
			System.out.println("Check your Values");
			return 0;
		}

	}

	@Override
	public List<SongBean> searchSongByComposerId(int composerId)
			throws MediaComposerException {
		return null;
	}

	@Override
	public List<ComposerBean> viewAllComposers() throws MediaComposerException {
		TypedQuery<ComposerBean> query =null;
		try{
		 query = entity.createQuery(
				"SELECT s from ComposerBean s", ComposerBean.class);
		System.out.println("In ComposerBean Dao");
		return query.getResultList();
		}
		catch(Exception e){
			System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++++");
			e.printStackTrace();
		}
		return query.getResultList();
	}

	@Override
	@Transactional
	public void addComposer(ComposerBean composerBean)
			throws MediaComposerException {
		entity.persist(composerBean);
		
	}

	@Override
	public ComposerBean findComposerById(int composerId)
			throws MediaComposerException {
		
		return entity.find(ComposerBean.class, composerId);
	}

	@Override
	public int editComposer(ComposerBean composerBean)
			throws MediaComposerException {
		entity.merge(composerBean);
		return 0;
	}

}
