package com.capg.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.cms.bean.Customer;
import com.capg.cms.dao.ICustomerDao;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao dao;

	@Override
	public List<Customer> retriveAll() {

		return dao.retriveAll();

	}

	@Override
	public Customer retriveCustomer(int customerId) {
		// TODO Auto-generated method stub
		return dao.retriveCustomer(customerId);
	}

	@Override
	public void updateCustomerPack(Customer customer) {
		dao.updateCustomerPack(customer);
		
	}

	@Override
	public void updateCustomer(Customer customer) {
		dao.updateCustomer(customer);
		
	}

}
