package com.cg.jpastart.entities;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class StudentTest {

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		Student student = new Student();
		em.getTransaction().begin();
		//Student student = new Student();
		//student.setStudentId(1001);
		
		System.out.println("Enter 1 to select.");
		System.out.println("Enter 2 to update.");
		System.out.println("Enter 3 to insert.");
		System.out.println("Enter 0 to exit.");
		
		System.out.println("Enter your option:");
		
		int val = s.nextInt();
		switch (val) {
		case 1:
			Student st = em.find(Student.class, 50);
			if (st!=null) {
				
				
				System.out.println(st.getName());
			}
			else{
				System.out.println("not found.");
			}
			break;
case 2:
	Student st1 = em.find(Student.class, 50);
	if (st1!=null) {
		
		System.out.println("enter new name:");
		String name =s.next();
		st1.setName(name);
		
		System.out.println("updated value for "+st1.getStudentId()+" "+"is"+" "+st1.getName());
	}
	em.getTransaction().commit();
			break;
case 3:
	

	System.out.println("enter  name:");
	String name1 = s.next();
	student.setName(name1);
	
	em.persist(student);
	em.getTransaction().commit();
	break;
case 0:
	
	break;

		default:
			break;
		}
	
		em.getTransaction().commit();
		s.close();
		em.close();
		factory.close();
	}
}
