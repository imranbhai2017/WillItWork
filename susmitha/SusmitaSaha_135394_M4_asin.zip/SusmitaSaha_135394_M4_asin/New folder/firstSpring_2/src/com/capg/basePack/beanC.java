package com.capg.basePack;

import org.springframework.stereotype.Component;

@Component
public class beanC {

	
	public void C(){
		System.out.println("beanC");
	}
	
}
