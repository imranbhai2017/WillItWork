package com.capg.basePack;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	public static void main(String[] args) {
		AbstractApplicationContext con = new ClassPathXmlApplicationContext("ContextBasePack.xml");
}}
