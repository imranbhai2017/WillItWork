package com.capg.pms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capg.pms.bean.Product;

@Repository
@Transactional
public class ProductDaoImpl implements IProductDao {
	@PersistenceContext
	EntityManager entity;

	@Override
	public List<Product> retriveAll() {

		TypedQuery<Product> query = entity.createQuery(
				"select p from Product p", Product.class);
		return query.getResultList();
	}

	@Override
	public int deleteProduct(int productId) {
		Product product = entity.find(Product.class, productId);
		entity.remove(product);
		;
		return 1;
	}

	@Override
	public Product addProduct(Product product) {
		entity.persist(product);
		entity.flush();
		return product;
	}

}
