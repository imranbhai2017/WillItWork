package com.capg.pms.service;

import java.util.List;

import com.capg.pms.bean.Product;

public interface IProductService {

	public List<Product> retriveAll();

	public int deleteProduct(int productId);
	
	public Product addProduct(Product product);
}
