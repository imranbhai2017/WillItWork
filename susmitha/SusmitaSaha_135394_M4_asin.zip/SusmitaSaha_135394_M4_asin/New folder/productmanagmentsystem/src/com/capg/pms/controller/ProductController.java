package com.capg.pms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.pms.bean.Product;
import com.capg.pms.service.IProductService;

@Controller
public class ProductController {
	@Autowired
	IProductService service;
	
	@RequestMapping("/home")
	public ModelAndView show( ) {
		
		List<Product> list = service.retriveAll();
		ModelAndView mv = new ModelAndView();
		mv.addObject("list", list);
		mv.setViewName("index");
	
		return mv;
	}
	
	
	@RequestMapping("/deleteProduct")
	public String delete(@RequestParam("productId") int productId){
		int status = service.deleteProduct(productId);
		return"redirect:/home.obj";
	}
	
	@RequestMapping("/addNewProduct")
	public String addProduct(Model model){
		model.addAttribute("pro",new Product());
		return "new";
	}
	
	
	@RequestMapping("/save")
	public String insert(@ModelAttribute("pro")@Valid Product product ,BindingResult result){
		
		
		if(result.hasErrors()){
			return "new";
		}
		else
		{
		service.addProduct(product);
		return "Success";
		}
	}
	
	
}
