package com.capg.firstspring.bean;

public class bean {
	private String message;
	private int id;

	public String getMessage() {
		return message;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void display() {
		System.out.println("hi!"+" "+id+" "+message);
		
	}

	public bean(String message,int id) {
		super();
		this.message = message;
		this.id = id;
	}
	
}
