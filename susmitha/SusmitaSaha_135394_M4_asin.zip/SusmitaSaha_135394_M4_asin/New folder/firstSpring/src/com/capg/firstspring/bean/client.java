package com.capg.firstspring.bean;


import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class client {

	public static void main(String[] args) {
		Resource res = new ClassPathResource("ApplicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(res);
		bean b =(bean) factory.getBean("id1");
		b.display();
		
	}

}
