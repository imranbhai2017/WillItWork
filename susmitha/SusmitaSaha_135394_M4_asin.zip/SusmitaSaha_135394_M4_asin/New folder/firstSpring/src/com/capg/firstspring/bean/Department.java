package com.capg.firstspring.bean;

public class Department {
 private int deptid;
 
 
 public int getDeptid() {
	return deptid;
}


public void setDeptid(int deptid) {
	this.deptid = deptid;
}


public void show(){
	 System.out.println(deptid);
 }
}
