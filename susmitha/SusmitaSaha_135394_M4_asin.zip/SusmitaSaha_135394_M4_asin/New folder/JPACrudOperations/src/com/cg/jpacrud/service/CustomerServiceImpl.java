package com.cg.jpacrud.service;

import com.cg.jpacrud.dao.CustomerDao;
import com.cg.jpacrud.dao.CustomerDaoImpl;
import com.cg.jpacrud.entities.Customer;

public class CustomerServiceImpl implements CustomerService {
	
	private CustomerDao dao;

	public CustomerServiceImpl() {
		dao = new CustomerDaoImpl();
	}

	@Override
	public Customer getCustomerById(int id) {
		Customer Customer  = dao.getCustomerById(id);
		return Customer;
		
	}

	@Override
	public void getCustomer() {
		dao.getCustomer();
		
	}

	@Override
	public void addCustomer(Customer Customer) {
		dao.beginTransaction();
		dao.addCustomer(Customer);
		dao.commitTransaction();
		
	}



	@Override
	public void updateCustomer(int custId) {
		dao.beginTransaction();
		dao.updateCustomer(custId);
		dao.commitTransaction();
		
	}

	@Override
	public void deleteCustomer(int custId) {
		dao.beginTransaction();
		dao.deleteCustomer(custId);
		dao.commitTransaction();
		
	}

	@Override
	public Customer getCustomerByMob(int mob) {
		Customer Customer  = dao.getCustomerByMob(mob);
		return Customer;
	}
	

}
