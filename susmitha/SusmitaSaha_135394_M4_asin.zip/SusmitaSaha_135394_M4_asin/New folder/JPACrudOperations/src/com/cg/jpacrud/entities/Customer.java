package com.cg.jpacrud.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="cust_tab")
public class Customer implements Serializable {

		private static final long serialVersionUID = 1L;
		@Id
		@Column(name = "cust_id")
		private int custId;
		@Column(name = "cust_name")
		private String custName;
		@Column(name = "cust_mob")
		private int custMob;
		@Column(name = "cust_dob")
		private String custDob;
		@Column(name = "cust_email")
		private String custEmail;
		public int getCustId() {
			return custId;
		}
		public void setCustId(int custId) {
			this.custId = custId;
		}
		public String getCustName() {
			return custName;
		}
		public void setCustName(String custName) {
			this.custName = custName;
		}
		public int getCustMob() {
			return custMob;
		}
		public void setCustMob(int custMob) {
			this.custMob = custMob;
		}
		public String getCustDob() {
			return custDob;
		}
		public void setCustDob(String custDob) {
			this.custDob = custDob;
		}
		public String getCustEmail() {
			return custEmail;
		}
		public void setCustEmail(String custEmail) {
			this.custEmail = custEmail;
		}
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		
	
	
	
}
