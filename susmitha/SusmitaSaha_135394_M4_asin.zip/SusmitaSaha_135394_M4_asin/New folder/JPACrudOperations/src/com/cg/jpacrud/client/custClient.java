package com.cg.jpacrud.client;

import java.util.Scanner;

import com.cg.jpacrud.entities.Customer;
import com.cg.jpacrud.service.CustomerService;
import com.cg.jpacrud.service.CustomerServiceImpl;

public class custClient {

	public static void main(String[] args) {
		Scanner s =new Scanner(System.in);
		CustomerService service = new CustomerServiceImpl();

		
		System.out.println("Enter 1 to select with perticular value.");
		System.out.println("Enter 2 to update.");
		System.out.println("Enter 3 to insert.");
		System.out.println("Enter 4 to select table.");
		System.out.println("Enter 5 to delete.");
		System.out.println("Enter 6 to select with perticular mobile number.");
		System.out.println("Enter 0 to exit.");
		
		System.out.println("Enter your option:");
		
		int val = s.nextInt();
		switch (val) {
		case 3:
			Customer Customer = new Customer();
			System.out.println("enter  id:");
			int id = s.nextInt();
			Customer.setCustId(id);
			System.out.println("enter name:");
			String name = s.next();
			Customer.setCustName(name);
			System.out.println("enter mobile number");
			int mob = s.nextInt();
			Customer.setCustMob(mob);
			System.out.println("enter dob");
			String dob = s.next();
			Customer.setCustDob(dob);
			System.out.println("enter email");
			String email = s.next();
			Customer.setCustEmail(email);;
			service.addCustomer(Customer);

			break;
		case 1:
			System.out.println("enter id to find customer:");
			int id1 = s.nextInt();
			Customer = service.getCustomerById(id1);
			System.out.print("ID:" + Customer.getCustId());
			System.out.println(" Name:" + Customer.getCustName());
			System.out.println(" mob:" + Customer.getCustMob());
			System.out.println(" dob:" + Customer.getCustDob());
			System.out.println(" email:" + Customer.getCustEmail());

			break;
		case 2:
			System.out.println("enter customer id for update :");
			int custId =s.nextInt();
			service.updateCustomer(custId);
			break;
		case 4:
		service.getCustomer();	
			break;
			 
		case 5:
			System.out.println("enter customer id for  delete:");
			int custId1 =s.nextInt();
			service.deleteCustomer(custId1);
			break;
		case 6:
			
			System.out.println("enter mobile number to find customer:");
			int mob1 = s.nextInt();
			Customer = service.getCustomerByMob(mob1);
			System.out.print("ID:" + Customer.getCustId());
			System.out.println(" Name:" + Customer.getCustName());
			System.out.println(" mob:" + Customer.getCustMob());
			System.out.println(" dob:" + Customer.getCustDob());
			System.out.println(" email:" + Customer.getCustEmail());
			break;
		default:
			System.out.println("invalid option");
			break;
		}
		
		s.close();

	}
}
