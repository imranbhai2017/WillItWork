package com.cg.jpacrud.dao;

import com.cg.jpacrud.entities.Customer;

public interface CustomerDao {

	
	public abstract Customer getCustomerById(int id);
	
	public abstract Customer getCustomerByMob(int mob);
	
	public abstract void getCustomer();
	
	
	public abstract void deleteCustomer(int custId);

	public abstract void addCustomer(Customer Customer);

	public abstract void updateCustomer(int custId);
	
	public abstract void commitTransaction();

	public abstract void beginTransaction();
}
