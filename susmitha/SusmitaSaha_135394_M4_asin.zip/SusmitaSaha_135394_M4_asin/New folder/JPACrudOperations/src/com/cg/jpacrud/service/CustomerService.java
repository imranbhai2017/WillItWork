package com.cg.jpacrud.service;

import com.cg.jpacrud.entities.Customer;

public interface CustomerService {
	public abstract Customer getCustomerById(int id);
	
	public abstract Customer getCustomerByMob(int mob);

	public abstract void getCustomer();

	public abstract void addCustomer(Customer Customer);

	public abstract void deleteCustomer(int custId);
	public abstract void updateCustomer(int custId);
}
