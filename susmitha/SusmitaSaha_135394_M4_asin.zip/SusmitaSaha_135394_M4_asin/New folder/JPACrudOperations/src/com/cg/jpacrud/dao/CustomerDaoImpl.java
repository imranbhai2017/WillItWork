package com.cg.jpacrud.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.jpacrud.entities.Customer;

public class CustomerDaoImpl  implements CustomerDao{
	Scanner s =new Scanner(System.in);	
	private EntityManager entityManager;
	
	public CustomerDaoImpl(){
		entityManager = JPAUtil.getEntityManager();
		
	}

	@Override
	public Customer getCustomerById(int id) {
		Customer customer = entityManager.find(Customer.class, id);
		return customer;
		
	}

	@Override
	public void  getCustomer() {
	    TypedQuery<Customer> display = entityManager.createQuery("select c from Customer c",Customer.class);
	    java.util.List<Customer> clist = display.getResultList();
	    
	    for(int i=0;i<clist.size();i++)
	    {
	    	System.out.println("id : "+clist.get(i).getCustId()+"   name : "+clist.get(i).getCustName()+"     mobile number : "+clist.get(i).getCustMob()
	    			+"       DOB : "+clist.get(i).getCustDob()+"     email : "+clist.get(i).getCustEmail());
	    	
	    }
	   
	}

	@Override
	public void addCustomer(Customer Customer) {
		entityManager.persist(Customer);
		
		
	}

	

	@Override
	public void updateCustomer(int custId) {
		Customer c1 = entityManager.find(Customer.class,custId);
		if (c1!=null) {
			
			
			System.out.println("enter new name:");
			String name =s.next();
			c1.setCustName(name);
			int custMob = s.nextInt();
			c1.setCustMob(custMob);
			String custDob = s.next();
			c1.setCustDob(custDob);
			String custEmail = s.next();
			c1.setCustEmail(custEmail);
			
			System.out.println("updated value for "+c1.getCustId()+" "+"is"+" "+c1.getCustName());
		}
		
	}
	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void deleteCustomer(int custId) {
		Customer c1 = entityManager.find(Customer.class, custId);
		 
		
		entityManager.remove(c1);
		
	}

	@Override
	public Customer getCustomerByMob(int mob) {
		TypedQuery<Customer> typedQuery =
				entityManager.createQuery("Select c From Customer c WHERE c.custMob =" + mob,Customer.class);
        return typedQuery.getSingleResult();
		
	}
}
