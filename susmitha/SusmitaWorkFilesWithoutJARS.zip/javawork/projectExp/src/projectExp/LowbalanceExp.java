package projectExp;

public class LowbalanceExp extends Exception {
	
	public LowbalanceExp() {
		
	super();
	}

	@Override
	public String toString() {
		return "sorry ur balance is low";
	}

	

}
