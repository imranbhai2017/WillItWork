package projectExp;

public class ExpDemo {

	public static void main(String[] args) {
		System.out.println("open file.");
		System.out.println("write data....");
		int c = 9 / 3;

		try {
			ExpDemo.m1();
		} catch (ArithmeticException ae) {
			System.err.println("number cannot be devided 0");
			// or
			System.out.println(ae);
			// or
			ae.printStackTrace();

		}
		ExpDemo.m2();
	}

	public static void m1() throws ArithmeticException {
		int c = 9 / 0;
		System.out.println("close file");
	}

	public static void m2() {
		try {
			int c = 9 / 0;
			int a[] = { 1, 2, 3 };
			System.out.println(a[5]);
		} catch (ArithmeticException a) {
			System.err.println("number cannot be devided 0");
		} catch (ArrayIndexOutOfBoundsException aie) {
			System.err.println("not proper array index");
		}
		System.out.println("close file");
	}
}
