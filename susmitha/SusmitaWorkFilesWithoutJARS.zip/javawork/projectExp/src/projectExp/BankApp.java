package projectExp;

public class BankApp {

	public static void main(String[] args) {
		
		int acNo[]={110,120,130};
		String name[]={"susmita","ram","sam"};
		int bal[]={1000,12200,13300};
		
		
		for (int i = 0; i < acNo.length; i++) {
			
			
			System.out.println("details:"+"  "+acNo[i]+"  "+name[i]+"   "+bal[i]);
			
			if (bal[i]< 10000) {
				try {
					throw new LowbalanceExp();
				} catch (Exception e) {
					System.err.println("balance is low");
				}
				
			}
		}
		
		
		
		
		
		/*try {
			throw new LowbalanceExp();
		} catch (LowbalanceExp e) {
			System.err.println(e);
		}*/
		

	}

}
