package projectExp;

public class ExpDemo2 {

	public static void main(String[] args) {
		System.out.println("line1");
		System.out.println("line2");
		
		//Thread.sleep(10000);

	}

}
