package opps;


public class Parent {
	int pid = 1001;

	public static void main(String[] args) {

	}

	public void m1() {
		System.out.println("m1 method");
	}

}
