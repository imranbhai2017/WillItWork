package opps;

public class Child extends Parent {
	int cid = 1002;

	public static void main(String[] args) {

		/*Parent p = new Parent();
		System.out.println(p.pid);
		p.m1();
		*/
		
		
		//typecasting
		Parent p = new Child();
		//Child c = (Child)p;
	
		Child c = new Child();
		System.out.println(c.toString());
		
		System.out.println(p instanceof Parent);
		
		System.out.println(c.pid);
		c.m1();
		c.m2();
		
	}

	public void m2() {
		System.out.println("m2 method");
	}
}
