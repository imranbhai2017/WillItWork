package library;

import java.util.Scanner;

public class Emp {

	public static void main(String[] args) {
		
	System.out.println(Empl.Raju.eid);
	System.out.println(Empl.Tom.eid);	
	Scanner sc = new Scanner("1,2,3,4,5");
	sc.useDelimiter(",");
	while (sc.hasNextInt()){
		System.out.println(sc.nextInt());
	}
		
	sc.close();
	}

}

enum Empl{
	
	Raju(1001,50000),Satish(102,15000),Tom(103,24000),jay(104,35000);
	
	int eid;
	double salary;
	private Empl(int eid,double salary){
	this.eid = eid;
	this.salary = salary;
	}
	
}