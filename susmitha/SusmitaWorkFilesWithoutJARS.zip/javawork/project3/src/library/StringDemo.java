package library;

public class StringDemo {

	public static void main(String[] args) {
		
		System.out.println("-------- creating implct object-----------");
		
		String s1 = "raju";
		String s2 = "raju";
		System.out.println(  "String class equals(value):"+ s1.equals(s2));
		System.out.println( "object class equals(hashcode):" + (s1 == s2));
		
		System.out.println("-------- creating explct object-----------");
		
		String s3 = new String("satish");
		String s4 = new String("satish");
		
		System.out.println("String class equals(value):" + s3.equals(s4));
		System.out.println("object class equals(hashcode):" + (s3 == s4));
		
		
		System.out.println("-------- using compareTo function -----------");
		
		String s5 = "A       ";
		String s6 = "b";
		String s ="";
		System.out.println(s5.compareTo(s6));
		System.out.println(s5.compareToIgnoreCase(s6));
		
		
		System.out.println(s1.length());// length function 
		System.out.println(s1.indexOf('j')); // indexOf method
		System.out.println(s1.substring(2,3));
		System.out.println(s5 + s6);
		System.out.println(s5.trim() + s6);
		
		System.out.println("withouth using valueOf() :" + (5 +6));
		System.out.println("using valueOf() :" + (s.valueOf(5) + s.valueOf(6)));
		
		System.out.println("-------- stringBuffer: append-----------");
		StringBuffer sb1 = new StringBuffer("java");
		StringBuffer sb2 = new StringBuffer("lang");
		 sb1= sb1.append(sb2);
		 System.out.println(sb1);
		
	}

}
