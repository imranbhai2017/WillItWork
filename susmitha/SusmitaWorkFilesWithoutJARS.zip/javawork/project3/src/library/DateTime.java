package library;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class DateTime {

	public static void main(String[] args) {
		
		 LocalDate now = LocalDate.now();
		 LocalDate indp = LocalDate.of(1947,Month.AUGUST,15);
		 System.out.println(now);
		 System.out.println(indp);
		 System.out.println("tommrow:"+now.plusDays(2));
		 
		 System.out.println(indp.isLeapYear());
		 System.out.println( now.getYear() -indp.getYear());
		 System.out.println(now.withYear(1995));
		 System.out.println("----------------------------ZONE DATE TIME -----------------------");
		 ZonedDateTime currTime = ZonedDateTime.now();
		 
		 ZonedDateTime currParisTime = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
	System.out.println("Indian time:"+ currTime);
	System.out.println("Paris time:"+ currParisTime);
	System.out.println("------------------------CHRONOUNIT----------------------------");
	Period p = indp.until(now);
	System.out.println("duration:"+ p.get(ChronoUnit.DAYS)+"days "+ p.get(ChronoUnit.MONTHS)+"months "+ p.get(ChronoUnit.YEARS)+"months");
	System.out.println("duration:"+ p.getDays());
	
	System.out.println("---------------------DATE TIME FORMATER-------------------------------");
	
	DateTimeFormatter form= DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
	DateTimeFormatter form1= DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
	DateTimeFormatter form2= DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
	DateTimeFormatter form3= DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
	System.out.println("medium: "+now.format(form));
	System.out.println("long: "+now.format(form1));
	System.out.println("full: "+now.format(form2));
	System.out.println("short: "+now.format(form3));
	
	
	System.out.println("---------------------DATE TIME FORMATER ( CUSTOMISED)-------------------------------");
	DateTimeFormatter userFor = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	Scanner sc = new Scanner(System.in) ;
	String text=sc.next();
	//String text="12/02/2014";
	LocalDate date = LocalDate.parse(text, userFor);
	System.out.println(date);
	
	sc.close();
	
	
	
	
	}

}
