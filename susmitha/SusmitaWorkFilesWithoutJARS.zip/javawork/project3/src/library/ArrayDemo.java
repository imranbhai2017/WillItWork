package library;

public class ArrayDemo {

	public static void main(String[] args) {
    int arr[]= new int[3];
    arr[0]=11;
    arr[1]=12;
    arr[2]=13;
    
    int arr1[]={11,12,13};
    //System.out.println();
    System.out.println("=== FOR LOOP=======");
    for (int i = 0; i < arr1.length; i++) {
		System.out.println(arr1[i]);
	}
    
    
    System.out.println("=======FOREACH: only for reading the array no conditions========");
    for (int i : arr) {
    	System.out.println(i);
		
	}

    	int arr2[][]= new int[3][2];
    	arr2[0][0]=88;
    	
    	 arr2[0]= new int[2];
    	 arr2[1]= new int[3];
    	 arr2[2]= new int[4];
    	System.out.println(arr2[0][0]);
	}

}
