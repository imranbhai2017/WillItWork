package com.capgemini.eqs.test;

import java.sql.Connection;

import static junit.framework.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.qes.dao.util.DbUtil;

public class DbUtilTest {
//DbUtil db = new DbUtil();
	
	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}
	@Test
	public void test() {
		Connection dbCon = DbUtil.getConnection();
		assertNotNull(dbCon);
	}
	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		
	}
}
