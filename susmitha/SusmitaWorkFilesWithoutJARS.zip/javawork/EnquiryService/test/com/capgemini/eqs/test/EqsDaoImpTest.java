package com.capgemini.eqs.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.eqs.dao.service.EqsDaoImp;
import com.capgemini.eqs.bean.Applicant;
import com.capgemini.eqs.exception.EnquriyException;

public class EqsDaoImpTest {
	static EqsDaoImp dao;
	static  Applicant a;
	ResultSet rs;
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new EqsDaoImp();
		a = new Applicant();
	}
	
	@Test
	public void testSelectApplicant() {

		try {
			int eid = 1002;
			
			a = dao.selectApplicant(eid);
			assertEquals(eid,a.getEnquiryID());
		} catch (EnquriyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		}
	

	@Test
	public void testAddApplicant() throws EnquriyException {
	
		assertTrue("Data Inserted successfully",
				(dao.addApplicant(a)) > 0);
	}

}
