package com.capg.eqs.dao.service;

import com.capgemini.eqs.bean.Applicant;
import com.capgemini.eqs.exception.EnquriyException;

public interface EqsDao {
	Applicant selectApplicant(int EnquiryId) throws EnquriyException;
	int addApplicant(Applicant a) throws EnquriyException;
	
}
