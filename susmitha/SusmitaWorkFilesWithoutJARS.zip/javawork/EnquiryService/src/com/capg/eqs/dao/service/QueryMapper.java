package com.capg.eqs.dao.service;

public class QueryMapper {
	public static final String INSERTQ = "INSERT INTO applicant values(qid.nextval,?,?,?,?,?)";

	public static final String SELECTQ = "SELECT * FROM applicant where enquiryid = ?";
	public static final String SELECTQ1 ="SELECT qid.currval from dual";
}
