package com.capg.eqs.dao.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import org.apache.log4j.Logger;

import com.capgemini.eqs.bean.Applicant;
import com.capgemini.eqs.exception.EnquriyException;
import com.capgemini.qes.dao.util.DbUtil;

public class EqsDaoImp implements EqsDao {

	private ResultSet rs;
	private Connection c;
	private int n;
	static Logger log = Logger.getRootLogger();
	@Override
	public Applicant selectApplicant(int EnquiryId) throws EnquriyException{
			c = DbUtil.getConnection();
			PreparedStatement ps;
			Applicant a = new Applicant();
			try {
				ps = c.prepareStatement(QueryMapper.SELECTQ);
				ps.setInt(1, EnquiryId);
				rs = ps.executeQuery();
				
				while (rs.next()) {
					a.setEnquiryID(rs.getInt(1));
					a.setFirstName(rs.getNString(2));
					a.setLastName(rs.getNString(3));
					a.setContactNumber(rs.getNString(4));
					a.setPrefrDomain(rs.getNString(5));
					a.setPrefrLocation(rs.getNString(6));
				}
				
			log.info("data retrived");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				log.error("problem in retriving data");
			}
			return a;
	}

	@Override
	public int addApplicant(Applicant a) throws EnquriyException{
		try {

			c = DbUtil.getConnection();

			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERTQ);

			
			ps.setString(1, a.getFirstName());
			ps.setString(2, a.getLastName());
			ps.setString(3, a.getContactNumber());
			ps.setString(4, a.getPrefrDomain());
			ps.setString(5, a.getPrefrLocation());

			n = ps.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit\
			
			PreparedStatement ps1 = c.prepareStatement(QueryMapper.SELECTQ1);
			rs = ps1.executeQuery();
			log.info("data added");
			while (rs.next()) {
				
				System.out.println("Thank you "+ a.getFirstName()+" "+ a.getLastName() +" your Unique Id is "+rs.getInt(1)+" we will contact you shorly");
			}
		}catch (SQLIntegrityConstraintViolationException se){
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			e1.printStackTrace();
			log.error("problem in adding data");
		} finally {

			try {
				c.close();
				log.info("Connection closed");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				log.error("Connection not closed");
			}
		}
		return n;

	}

	

}
