package com.capgemini.eqs.bean;

public class Applicant {

	private String firstName;
	private String lastName;
	private String contactNumber;
	private String prefrDomain;
	private String prefrLocation;
	private int enquiryID;
	
	public int getEnquiryID() {
		return enquiryID;
	}
	public void setEnquiryID(int enquiryID) {
		this.enquiryID = enquiryID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getPrefrDomain() {
		return prefrDomain;
	}
	public void setPrefrDomain(String prefrDomain) {
		this.prefrDomain = prefrDomain;
	}
	public String getPrefrLocation() {
		return prefrLocation;
	}
	public void setPrefrLocation(String prefrLocation) {
		this.prefrLocation = prefrLocation;
	}
	
	
}
