package com.capgemini.eqs.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.eqs.bean.Applicant;

public class ValidateDetails {
	static Scanner sc = new Scanner(System.in);
	static Logger log = Logger.getRootLogger();
	public static boolean validName(Applicant a) {

		Pattern pattern = Pattern.compile("[A-Z][a-z]{2,}");
		Matcher matcher = pattern.matcher(a.getFirstName());
		if (matcher.matches()) {
			System.out.println("Name Valid");
			log.info("Name validation done");
		} else {
			enterName(a);
		}
		return true;
	}
	
	public static boolean validNumber(Applicant a) {

		Pattern pattern = Pattern.compile("[789][0-9]{9}");
		Matcher matcher = pattern.matcher(a.getContactNumber());
		if (matcher.matches()) {
			System.out.println("Number valid");
			log.info("number validation done");
		} else {
			enterNumber(a);
		}
		return true;
	}


	public static void enterName(Applicant a){
		System.out.println("Not a Valid First Name");
		System.out.println("Enter a Valid First Name:");
		a.setFirstName(sc.next());
		ValidateDetails.validName(a);
	}
	public static void enterNumber(Applicant a){
		System.out.println("Not a Valid contact number");
		System.out.println("Enter a Valid contact number:");
		a.setContactNumber(sc.next());
		ValidateDetails.validNumber(a);
	}
	

}
