package com.capgemini.eqs.exception;

public class EnquriyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public static void main(String[] args) {
		

	}
	
	
}
