package com.capgemini.eqs.service;

import java.sql.Connection;
import java.sql.ResultSet;

import com.capg.eqs.dao.service.EqsDaoImp;
import com.capgemini.eqs.bean.Applicant;
import com.capgemini.eqs.exception.EnquriyException;

public class EnquiryServiceImp implements EnquiryService {

	int n;
	Connection c = null;
	ResultSet rs;
	EqsDaoImp dao = new EqsDaoImp();
	Applicant a;

	
	@Override
	public int  addApplicant(Applicant a) throws EnquriyException {
		if ( ValidateDetails.validName(a) && ValidateDetails.validNumber(a)
			) {
		
			return n=dao.addApplicant(a);
		} else {
			return 0;
		}
	}

	@Override
	public Applicant selectApplicant(int EnquiryId) throws EnquriyException {
		
		return dao.selectApplicant(EnquiryId);
	}

}
