package com.capgemini.eqs.service;

import com.capgemini.eqs.bean.Applicant;
import com.capgemini.eqs.exception.EnquriyException;

public interface EnquiryService {
	
	
	int addApplicant(Applicant a) throws EnquriyException;
	public Applicant selectApplicant(int EnquiryId) throws EnquriyException;
	
	
}
