package com.capgemini.eqs.ui;

import java.util.Scanner;

import com.capgemini.eqs.bean.Applicant;
import com.capgemini.eqs.exception.EnquriyException;
import com.capgemini.eqs.service.EnquiryServiceImp;

public class UI {
	private static Scanner sc;
	public static Applicant a;
	static Applicant a1 = new Applicant();
	static EnquiryServiceImp eqi = new EnquiryServiceImp();

	public static void main(String[] args) throws EnquriyException {

		sc = new Scanner(System.in);
		a = new Applicant();

		System.out.println("****************Global Recruitments****************");
		System.out.println("Chose an option:");
		System.out.println("1.Enter Enquiry Details");
		System.out.println("2.View Enquery Details on Id");
		System.out.println("0.exit");
		System.out.println("***************************************************");
		

		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			System.out.println("");
			getDetails(a);
			break;
		case 2:

			System.out.println("Enter Enquery ID");
			int EnquiryId = sc.nextInt();
			
		a1 = eqi.selectApplicant(EnquiryId);
			
			if(a1.getFirstName()== null){
				System.out.println("Sorry Please Check your ID");
			}else{
				System.out.println(a1.getFirstName());
				
				 System.out.println("Id" + "       "
									+ "First Name"+"     "+"Last Name"+"  "
									+"ContactNo."+"    "+"Preferred Domain"+"   "
									+"Preferred Location");
				System.out.println(a1.getEnquiryID() + "      "
									+ a1.getFirstName()+"       "+a1.getLastName()+"        "
									+a1.getContactNumber()+"            "+a1.getPrefrDomain()+"            "
									+a1.getPrefrLocation());
						
				
			}
			
			

			break;
		case 0:
			System.exit(0);
			break;
		
		default:
			System.out.println("Not a Valid Input");
			break;
		}

	}

	private static void getDetails(Applicant a) throws EnquriyException {

		System.out.println("Enter First Name:");
		a.setFirstName(sc.next());
		System.out.println("Enter Last Name:");
		a.setLastName(sc.next());
		System.out.println("Enter contact Number:");
		a.setContactNumber(sc.next());
		System.out.println("Enter Preferred Domain:");
		a.setPrefrDomain(sc.next());
		System.out.println("Enter Preferred Location:");
		a.setPrefrLocation(sc.next());

		// esi = new EmployeeServiceImp(); //Object Creation
		int addRes = eqi.addApplicant(a);

		System.out.println(addRes + " Row Inserted");

	}
}
