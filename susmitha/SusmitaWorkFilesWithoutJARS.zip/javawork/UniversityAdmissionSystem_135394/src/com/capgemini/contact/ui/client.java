package com.capgemini.contact.ui;

import java.util.Scanner;



import org.apache.log4j.Logger;

import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.service.ApplyServiceImpl;

import exception.ApplicantException;

public class client {
	private static Scanner sc;
	
	static Logger log = Logger.getRootLogger();
	static ApplicantBean a1 = new ApplicantBean();
	public static ApplicantBean apply = new ApplicantBean();
	static ApplyServiceImpl asi = new ApplyServiceImpl();
public static void main(String[] args) throws ApplicantException {
	

		sc = new Scanner(System.in);
		//a = new Applicant();

		System.out.println("*********Admission Managment System*********");
		System.out.println("Select an Operation");
		System.out.println("1.Enter Details");
		System.out.println("2.View Details based on Applicant Id");
		System.out.println("0.exit");
		System.out.println("*******************************************");
		System.out.println("Plese enter a choice:");
		System.out.println("*******************************************");
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			log.info("case one selected");
			System.out.println("");
			getDetails(apply);
			break;
		case 2:
			log.info("case two selected");
			System.out.println("Enter Applicant ID");
			int applyid = sc.nextInt();
			
		  a1 = asi.getApplicantDetails(applyid);
			
			if(a1.getlName()== null){
				System.out.println("Sorry no details found.");
			}else{
				
	
				 System.out.println("Id" + "       "+ " first Name"+"     "
									+ "last Name"+"     "+"ContactNo"+"     "
									+"Stream"+"        "+"Aggregate"+"       "
									+"Email");
				System.out.println(a1.getApplyid() + "      "+ a1.getfName()+"          "
									+ a1.getlName()+"        "+a1.getContactNo()+"      "
									+a1.getStream()+"          "+a1.getAggreate()+"         "
									+a1.getEmail());
				log.info("data displayed.");
				
			}
			
			

			break;
		case 0:
			System.out.println("Thank you for applying.");
			log.info("user exited");
			System.exit(0);
			
			break;
		
		default:
			System.out.println("Not a Valid Input");
			log.info("enterd invalid case value");
			break;
		}

	}
/*
 * This function will call the service layer method and return the bean
 */

	private static void getDetails(ApplicantBean apply) throws ApplicantException{

		try{System.out.println("Enter first Name:");
		apply.setfName(sc.next());
		System.out.println("Enter last Name:");
		apply.setlName(sc.next());
		System.out.println("Enter Mobile Number:");
		apply.setContactNo(sc.nextLong());
		System.out.println("Enter email:");
		apply.setEmail(sc.next());
		sc.nextLine();
		System.out.println("Enter stream (should be computer science or information technology)");
		apply.setStream(sc.nextLine());
		System.out.println("Enter  Aggregate in Qualified Exam:");
		apply.setAggreate(sc.nextFloat());

		// esi = new EmployeeServiceImp(); //Object Creation
		int addRes = asi.addApplicantDetails(apply);

		System.out.println(addRes + " Row Inserted");
		log.info("row passed to service layer");
		}
	catch(ApplicantException e){
		System.out.println(e);
	}
	}
}

