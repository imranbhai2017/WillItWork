package com.capgemini.contact.bean;

public class ApplicantBean {
	private long applyid;
	private String fName;
	private String lName;
	private String email;
	private long contactNo;
	private String stream;
	private float aggreate;

	public long getApplyid() {
		return applyid;
	}
	public void setApplyid(long applyid) {
		this.applyid = applyid;
	}
	public String getfName() {
		return fName;
	}
	public void setfName(String fName) {
		this.fName = fName;
	}
	public String getlName() {
		return lName;
	}
	public void setlName(String lName) {
		this.lName = lName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getContactNo() {
		return contactNo;
	}
	public void setContactNo(long contactNo) {
		this.contactNo = contactNo;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public float getAggreate() {
		return aggreate;
	}
	public void setAggreate(float aggreate) {
		this.aggreate = aggreate;
	}
	
}