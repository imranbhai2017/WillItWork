package com.capgemini.contact.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;
import com.capgemini.contact.ui.client;

import exception.ApplicantException;

public class ApplyServiceImpl implements ApplyService {
	int n;
	
	ApplyDaoImpl adi = new ApplyDaoImpl();
	ApplicantBean apply;
	Scanner sc = new Scanner(System.in);
	static Logger log = Logger.getRootLogger();
	
	
	/*******************************************************************************************************
	 - Function Name	:	addApplicantDetails
	 - Input Parameters	:	ApplicantBean object
	 - Return Type		:	been
	 - Throws			:  	ApplicantException
	 - Author			:	susmita saha
	 - Creation Date	:	27/09/2017
	 - Description		:	adding Applicant to database calls dao method addApplicantDetails(apply)
	 ********************************************************************************************************/
	@Override
	public int addApplicantDetails(ApplicantBean apply) throws ApplicantException {
		if (isValidApplicant(apply)) {
			log.info("data inserted");
			return n=adi.addApplicantDetails(apply);
			
		}
		return 0;
			
				
			
	}
	
	/*******************************************************************************************************
	 - Function Name	:	getApplicantDetails
	 - Input Parameters	:	long applyid
	 - Return Type		:	Applicant object
	 - Throws		    :  	ApplicantException
	 - Author		    :	Susmita Saha
	 - Creation Date	:	27/109/2017
	 - Description		:	calls dao method getApplicantDetails(applyid)
	 ********************************************************************************************************/

	@Override
	public ApplicantBean getApplicantDetails(long applyid) throws ApplicantException{
		log.error("data retrived");
		return adi.getApplicantDetails(applyid);
		
	}
	
	
	
	/*******************************************************************************************************
	 - Function Name	: isValidApplicant(ApplicantBean apply)
	 - Input Parameters	: ApplicantBean apply
	 - Return Type		: boolean
	 - Throws		    : ApplicantException
	 - Author	      	: Susmita Saha
	 - Creation Date	: 27/109/2017
	 - Description		: validates the ApplicantBean object
	 ********************************************************************************************************/

	@Override
	public boolean isValidApplicant(ApplicantBean apply) throws ApplicantException {
			
			if (validateFirstName(apply.getfName())) {
				if (validateLastName(apply.getlName())) {
			
				if (validateContactNo(apply.getContactNo())) {
					
					if (validateEmail(apply.getEmail())) {
						
						if (validateStream(apply.getStream())) {
							
							if (validateAggregate(apply.getAggreate())) {
								System.out.println("Entered");
								log.info("validation done.");
								return true;
								
							}
						}
					}
				}
				}
			}
			return false;
	}
	public boolean validateContactNo(long contactNo){
		String contNo = String.valueOf(contactNo);
		Pattern pattern = Pattern.compile("[789][0-9]{9}");
		Matcher matcher = pattern.matcher(contNo);
		if (matcher.matches()) {
			System.out.println("Number valid");
			//log.info("number validation done");
			log.info("contactNo validation done.");
		} else {
			System.out.println("Not a Valid contact number");
			System.out.println("Enter a Valid contact number:");
			contactNo = sc.nextLong();
			client.apply.setContactNo(contactNo);
			validateContactNo(contactNo);
		}
		
		return true;

	}

	public boolean validateFirstName(String fName) {

		if (fName.length()>0) {
			System.out.println("First Name Valid");
			
			 log.info("first Name validation done");
		} else {
			System.out.println("Not a First Valid Name");
			System.out.println("Enter a Valid Name:");
			fName = sc.next();
		client.apply.setfName(fName);
			//Client.apply.(name);
		validateFirstName(fName);
		}
		return true;

	}
	public boolean validateLastName(String lName) {

		if (lName.length()>0) {
			System.out.println(" Last Name Valid");
			
			log.info("Last Name validation done");
		} else {
			System.out.println("Not a Last Valid Name");
			System.out.println("Enter a Valid Name:");
			lName = sc.next();
		client.apply.setlName(lName);
			//Client.apply.(name);
		validateLastName(lName);
		}
		return true;

	}

	public boolean validateStream(String stream) {
		
		if (stream.toLowerCase().equals("computer science")||stream.toLowerCase().equals("information technology")) {
			System.out.println("stream Valid");
			log.info("stream validation done");
		} else {
			System.out.println("Not a Valid stream");
			System.out.println("Enter a Valid stream:");
			stream = sc.nextLine();
			client.apply.setStream(stream);
			validateStream(stream);
		}
		return true;

	}

	public boolean validateEmail(String email) {
		Pattern pattern = Pattern.compile("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}");
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			System.out.println("Number email");
			log.info("email validation done");
		} else {
			System.out.println("Not a Valid email");
			System.out.println("Enter a Valid email:");
			email = sc.next();
			client.apply.setEmail(email);
			validateEmail(email);
		}
		
		return true;
		
		

	}

	
	
	public boolean validateAggregate(float aggregate) {
		if (aggregate!=0.0) {
			System.out.println("valid aggregate");
			 log.info("aggregate validation done");
		} else {
			System.out.println("Not a Valid aggregate");
			System.out.println("Enter a Valid aggregate:");
			aggregate = sc.nextFloat();
			client.apply.setAggreate(aggregate);
			validateAggregate(aggregate);
		}
		return true;
		
		

	}
}
