package com.capgemini.apply.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

public class DbUtil {
	private static FileInputStream fis;
	private static Properties p;
	public static Connection c;
	static Logger log = Logger.getRootLogger();
	
	
	
	
	/************************************************************************************
	 *  - Author : Susmita Saha
	 *  - Creation Date : 27/09/2017
	 *  - Desc:Loads the  jdbc.properties file and Driver Class and gets the connection
	 ***************************************************************************************/
	public static Connection getConnection() {
		try {
			fis = new FileInputStream("resources/jdbc.properties");

			p = new Properties();

			p.load(fis);

			String url = p.getProperty("url");
			String uname = p.getProperty("uname");
			String pass = p.getProperty("pwd");

			c = DriverManager.getConnection(url, uname, pass);
			log.info("connected to db");
        //  log.info("Connection done");
	
		} catch (IOException e) {

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}/*finally{
			try {
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}*/
		return c;
	}
}
