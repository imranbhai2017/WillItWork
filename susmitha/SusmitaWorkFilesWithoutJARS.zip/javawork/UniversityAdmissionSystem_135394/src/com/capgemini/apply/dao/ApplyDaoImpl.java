package com.capgemini.apply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import org.apache.log4j.Logger;

import com.capgemini.contact.bean.ApplicantBean;

import exception.ApplicantException;

public class ApplyDaoImpl implements ApplyDao {

	private ResultSet rs;
	private Connection c;
	private int n;
	
	static Logger log = Logger.getRootLogger();
	ApplicantBean apply = new ApplicantBean();
	
	/*******************************************************************************************************
	 - Function Name	:	addApplicantDetails(ApplicantBean ApplicantBean)
	 - Input Parameters	:	ApplicantBean ApplicantBean
	 - Return Type		:	int
	 - Throws			:  	ApplicantException
	 - Author			:	Susmita Saha
	 - Creation Date	:	27/09/2017
	 - Description		:	Adding Applicant
	 ********************************************************************************************************/
	@Override
	public int addApplicantDetails(ApplicantBean apply) throws ApplicantException{
		try {
			//PropertyConfigurator.configure("resources/log4j.properties");
			c = DbUtil.getConnection();

			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERTQ);

			
			ps.setString(1, apply.getfName());
			ps.setString(2, apply.getlName());
			ps.setLong(3, apply.getContactNo());
			ps.setString(4, apply.getEmail());
			ps.setFloat(5, apply.getAggreate());
			ps.setString(6, apply.getStream());
			

			n = ps.executeUpdate();
			//c.setAutoCommit(false); Disabling the Auto Commit
			
			PreparedStatement ps1 = c.prepareStatement(QueryMapper.SELECTQ1);
			rs = ps1.executeQuery();
		log.info("data added");
			while (rs.next()) {
				System.out.println("**********************************************************************");
				System.out.println("Thank you "+ apply.getfName()+" "+apply.getlName() +" "+" your Unique Id is "+rs.getInt(1)+" we will contact you shorly");
				System.out.println("**********************************************************************");
			}
		}catch (SQLIntegrityConstraintViolationException se){
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			e1.printStackTrace();
			log.error("problem in adding data");
		} finally {

			try {
				c.close();
				log.info("Connection closed");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				log.error("Connection not closed");
			}
		}
		return n;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	getApplicantDetails(long applyid)
	 - Input Parameters	:	ApplicantBean ApplicantBean
	 - Return Type		:	ApplicantBean
	 - Throws			:  	ApplicantException
	 - Author			:	Susmita Saha
	 - Creation Date	:	27/09/2017
	 - Description		:	fetching  Applicant  details
	 ********************************************************************************************************/

	@Override
	public ApplicantBean getApplicantDetails(long applyid) throws ApplicantException {
		c = DbUtil.getConnection();
		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.SELECTQ);
			ps.setLong(1, applyid);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				apply.setApplyid(rs.getLong(1));
				apply.setfName(rs.getNString(2));
				apply.setlName(rs.getNString(3));
				apply.setContactNo(rs.getLong(4));
				apply.setEmail(rs.getNString(5));
				apply.setAggreate(rs.getFloat(6));
				apply.setStream(rs.getNString(7));
				
			}
			
		log.info("data retrived");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			log.error("problem in retriving data");
		}finally {

			try {
				c.close();
				log.info("Connection closed");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				log.error("Connection not closed");
			}
		}
		return apply;
	}

}
