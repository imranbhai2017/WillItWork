package com.capgemini.apply.dao;

import com.capgemini.contact.bean.ApplicantBean;

import exception.ApplicantException;

public interface ApplyDao {
	public int addApplicantDetails(ApplicantBean apply) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long applyid) throws ApplicantException;
}
