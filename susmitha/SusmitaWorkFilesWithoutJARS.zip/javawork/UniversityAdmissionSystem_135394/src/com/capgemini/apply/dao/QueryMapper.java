package com.capgemini.apply.dao;

public class QueryMapper {
	public static final String INSERTQ = "INSERT INTO  Candidate_Detail values(apply_id_seq.nextval,?,?,?,?,?,?)";

	public static final String SELECTQ = "SELECT * FROM  Candidate_Detail where applyid = ?";
	public static final String SELECTQ1 ="SELECT apply_id_seq.currval from dual";
}
