package test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicantBean;

import exception.ApplicantException;

public class ApplyDaoImplTest {
ApplyDaoImpl adi= new ApplyDaoImpl();

	
@Test
	public void testAddApplicantDetails() {
		int n;
		ApplicantBean a = new ApplicantBean();
		
		try {
			a.setfName("Susmita");
			a.setlName("Saha");
			a.setContactNo(8989898);
			a.setEmail("saha@hh.com");
			a.setStream("it");
			a.setAggreate(20);
			n = adi.addApplicantDetails(a);
			
			assertEquals(1,n);
			
			assertEquals("test succesfull",1,n);
			
		} catch (ApplicantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

@Test
public void testAddApplicantDetails1() {
	int n;
	ApplicantBean a = new ApplicantBean();
	
	try {
		a.setfName("joy");
		a.setlName("nath");
		a.setContactNo(8989898);
		a.setEmail("joy@hh.com");
		a.setStream("it");
		a.setAggreate(20);
		n = adi.addApplicantDetails(a);
		
		assertTrue("Data Inserted successfully",n < 2);
		
	} catch (ApplicantException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}

	@Test
	public void testGetApplicantDetails() throws ApplicantException {
		ApplicantBean a1 = new ApplicantBean();
			int eid = 1002;
			
			a1 = adi. getApplicantDetails(eid);
			assertEquals(eid,a1.getApplyid());
		
	}

	@Test
	public void testGetApplicantDetails1() throws ApplicantException {
		
			int eid = 1009;
			
			assertEquals("Susmita", adi.getApplicantDetails(eid).getfName());
		
	}
}
