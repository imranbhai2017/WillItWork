package exception;

public class ApplicantException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ApplicantException() {
		
		super();
		}

		@Override
		public String toString() {
			return " application exception has occured";
		}

}
