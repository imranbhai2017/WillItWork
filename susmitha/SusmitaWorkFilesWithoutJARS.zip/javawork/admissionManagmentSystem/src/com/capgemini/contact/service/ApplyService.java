package com.capgemini.contact.service;

import com.capgemini.contact.been.ApplicantBeen;

import exception.ApplicantException;

public interface ApplyService {

	public int addApplicantDetails(ApplicantBeen apply) throws ApplicantException;
	public ApplicantBeen getApplicantDetails(long applyid) throws ApplicantException;
	public boolean isValidApplicant(ApplicantBeen apply) throws ApplicantException;
}
