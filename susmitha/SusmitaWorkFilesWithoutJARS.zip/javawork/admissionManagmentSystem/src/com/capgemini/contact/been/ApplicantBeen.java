package com.capgemini.contact.been;

public class ApplicantBeen {
private long applyid;
private String name;
private String email;
private long mno;
private String stream;
private float aggreate;
public long getApplyid() {
	return applyid;
}
public void setApplyid(long applyid) {
	this.applyid = applyid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public long getMno() {
	return mno;
}
public void setMno(long mno) {
	this.mno = mno;
}
public String getStream() {
	return stream;
}
public void setStream(String stream) {
	this.stream = stream;
}
public float getAggreate() {
	return aggreate;
}
public void setAggreate(float aggreate) {
	this.aggreate = aggreate;
}


}