package com.capgemini.contact.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.contact.been.ApplicantBeen;
import com.capgemini.contact.service.ApplyServiceImpl;

import exception.ApplicantException;

public class client {
	private static Scanner sc;
	
	static Logger log = Logger.getRootLogger();
	static ApplicantBeen a1 = new ApplicantBeen();
	public static ApplicantBeen apply = new ApplicantBeen();
	static ApplyServiceImpl asi = new ApplyServiceImpl();
public static void main(String[] args) throws ApplicantException {
	

		sc = new Scanner(System.in);
		//a = new Applicant();

		System.out.println("****************Admission Managment System****************");
		System.out.println("Select an Operation");
		System.out.println("1.Enter Details");
		System.out.println("2.View Details based on Applicant Id");
		System.out.println("0.exit");
		System.out.println("***************************************************");
		System.out.println("Plese enter a choice:");
       
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			System.out.println("");
			getDetails(apply);
			break;
		case 2:

			System.out.println("Enter Enquery ID");
			int applyid = sc.nextInt();
			
		  a1 = asi.getApplicantDetails(applyid);
			
			if(a1.getName()== null){
				System.out.println("Sorry Please Check your ID");
			}else{
	
				 System.out.println("Id" + "       "
									+ "Name"+"     "+"ContactNo"+"  "
									+"Stream"+"     "+"Aggregate"+"       "
									+"Email");
				System.out.println(a1.getApplyid() + "      "
									+ a1.getName()+"       "+a1.getMno()+"      "
									+a1.getStream()+"          "+a1.getAggreate()+"         "
									+a1.getEmail());
				log.info("data displayed.");
				
			}
			
			

			break;
		case 0:
			System.exit(0);
			log.info("user exited");
			break;
		
		default:
			System.out.println("Not a Valid Input");
			break;
		}

	}

	private static void getDetails(ApplicantBeen apply) throws ApplicantException{

		System.out.println("Enter Name:");
		apply.setName(sc.next());
		System.out.println("Enter Mobile Number:");
		apply.setMno(sc.nextLong());
		System.out.println("Enter email:");
		apply.setEmail(sc.next());
		System.out.println("Enter stream (should be Bsc or IT):");
		apply.setStream(sc.next());
		System.out.println("Enter  Aggregate in Qualified Exam:");
		apply.setAggreate(sc.nextFloat());

		// esi = new EmployeeServiceImp(); //Object Creation
		int addRes = asi.addApplicantDetails(apply);

		System.out.println(addRes + " Row Inserted");

	}
}

