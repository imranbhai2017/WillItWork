package com.capgemini.contact.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.been.ApplicantBeen;
import com.capgemini.contact.ui.client;

import exception.ApplicantException;

public class ApplyServiceImpl implements ApplyService {
	int n;
	
	ApplyDaoImpl adi = new ApplyDaoImpl();
	ApplicantBeen apply;
	Scanner sc = new Scanner(System.in);
	static Logger log = Logger.getRootLogger();
	@Override
	public int addApplicantDetails(ApplicantBeen apply) throws ApplicantException {
		if (isValidApplicant(apply)) {
			log.info("data inserted");
			return n=adi.addApplicantDetails(apply);
			
		}
		return 0;
			
				
			
	}

	

	@Override
	public ApplicantBeen getApplicantDetails(long applyid) throws ApplicantException{
		log.error("data retrived");
		return adi.getApplicantDetails(applyid);
		
	}

	@Override
	public boolean isValidApplicant(ApplicantBeen apply) throws ApplicantException {
			
			if (validateName(apply.getName())) {
			
				if (validateContactNo(apply.getMno())) {
					
					if (validateEmail(apply.getEmail())) {
						
						if (validateStream(apply.getStream())) {
							
							if (validateAggregate(apply.getAggreate())) {
								System.out.println("Entered");
								log.info("validation done.");
								return true;
								
							}
						}
					}
				}

			}
			return false;
	}
	public boolean validateContactNo(long contactNo){
		String contNo = String.valueOf(contactNo);
		Pattern pattern = Pattern.compile("[789][0-9]{9}");
		Matcher matcher = pattern.matcher(contNo);
		if (matcher.matches()) {
			System.out.println("Number valid");
			//log.info("number validation done");
		} else {
			System.out.println("Not a Valid contact number");
			System.out.println("Enter a Valid contact number:");
			contactNo = sc.nextLong();
			client.apply.setMno(contactNo);
			validateContactNo(contactNo);
		}
		
		return true;

	}

	public boolean validateName(String name) {

		if (name.length()>0) {
			System.out.println("Name Valid");
			
			// log.info("Name validation done");
		} else {
			System.out.println("Not a Valid Name");
			System.out.println("Enter a Valid Name:");
			name = sc.next();
		client.apply.setName(name);
			//Client.apply.(name);
			validateName(name);
		}
		return true;

	}

	public boolean validateStream(String stream) {
		
		if (stream.toLowerCase().equals("bsc")||stream.toLowerCase().equals("it")) {
			System.out.println("stream Valid");
			// log.info("Name validation done");
		} else {
			System.out.println("Not a Valid stream");
			System.out.println("Enter a Valid stream:");
			stream = sc.next();
			client.apply.setStream(stream);
			validateStream(stream);
		}
		return true;

	}

	public boolean validateEmail(String email) {
		Pattern pattern = Pattern.compile("[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}");
		Matcher matcher = pattern.matcher(email);
		if (matcher.matches()) {
			System.out.println("Number email");
			//log.info("number validation done");
		} else {
			System.out.println("Not a Valid email");
			System.out.println("Enter a Valid email:");
			email = sc.next();
			client.apply.setEmail(email);
			validateEmail(email);
		}
		
		return true;
		
		

	}

	
	
	public boolean validateAggregate(float aggregate) {
		if (aggregate!=0.0) {
			System.out.println("valid aggregate");
			// log.info("Name validation done");
		} else {
			System.out.println("Not a Valid aggregate");
			System.out.println("Enter a Valid aggregate:");
			aggregate = sc.nextFloat();
			client.apply.setAggreate(aggregate);
			validateAggregate(aggregate);
		}
		return true;
		
		

	}
}
