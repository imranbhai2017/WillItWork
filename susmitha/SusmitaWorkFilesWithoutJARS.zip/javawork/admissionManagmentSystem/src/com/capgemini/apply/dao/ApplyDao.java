package com.capgemini.apply.dao;

import com.capgemini.contact.been.ApplicantBeen;

import exception.ApplicantException;

public interface ApplyDao {
	public int addApplicantDetails(ApplicantBeen apply) throws ApplicantException;
	public ApplicantBeen getApplicantDetails(long applyid) throws ApplicantException;
}
