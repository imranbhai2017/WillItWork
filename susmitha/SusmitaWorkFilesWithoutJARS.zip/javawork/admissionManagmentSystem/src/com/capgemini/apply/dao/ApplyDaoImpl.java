package com.capgemini.apply.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import org.apache.log4j.Logger;

import com.capgemini.contact.been.ApplicantBeen;

import exception.ApplicantException;

public class ApplyDaoImpl implements ApplyDao {

	private ResultSet rs;
	private Connection c;
	private int n;
	
	static Logger log = Logger.getRootLogger();
	ApplicantBeen apply = new ApplicantBeen();
	@Override
	public int addApplicantDetails(ApplicantBeen apply) throws ApplicantException{
		try {
			//PropertyConfigurator.configure("resources/log4j.properties");
			c = DbUtil.getConnection();

			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERTQ);

			
			ps.setString(1, apply.getName());
			ps.setLong(2, apply.getMno());
			ps.setString(3, apply.getEmail());
			ps.setString(4, apply.getStream());
			ps.setFloat(5, apply.getAggreate());

			n = ps.executeUpdate();
			//c.setAutoCommit(false); Disabling the Auto Commit
			
			PreparedStatement ps1 = c.prepareStatement(QueryMapper.SELECTQ1);
			rs = ps1.executeQuery();
		log.info("data added");
			while (rs.next()) {
				
				System.out.println("Thank you "+ apply.getName()+" " +" your Unique Id is "+rs.getInt(1)+" we will contact you shorly");
			}
		}catch (SQLIntegrityConstraintViolationException se){
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			e1.printStackTrace();
			log.error("problem in adding data");
		} finally {

			try {
				c.close();
				log.info("Connection closed");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				log.error("Connection not closed");
			}
		}
		return n;
	}

	@Override
	public ApplicantBeen getApplicantDetails(long applyid) throws ApplicantException {
		c = DbUtil.getConnection();
		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.SELECTQ);
			ps.setLong(1, applyid);
			rs = ps.executeQuery();
			
			while (rs.next()) {
				apply.setApplyid(rs.getLong(1));
				apply.setName(rs.getNString(2));
				apply.setMno(rs.getLong(3));
				apply.setEmail(rs.getNString(4));
				apply.setStream(rs.getNString(5));
				apply.setAggreate(rs.getFloat(6));
			}
			
		log.info("data retrived");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			log.error("problem in retriving data");
		}finally {

			try {
				c.close();
				log.info("Connection closed");
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
				log.error("Connection not closed");
			}
		}
		return apply;
	}

}
