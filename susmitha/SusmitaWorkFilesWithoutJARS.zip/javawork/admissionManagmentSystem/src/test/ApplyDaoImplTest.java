package test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.been.ApplicantBeen;

import exception.ApplicantException;

public class ApplyDaoImplTest {
ApplyDaoImpl adi= new ApplyDaoImpl();

	
@Test
	public void testAddApplicantDetails() {
		int n;
		ApplicantBeen a = new ApplicantBeen();
		
		try {
			a.setName("susmita");
			a.setMno(8989898);
			a.setEmail("bdjh@hh.com");
			a.setStream("gghg");
			a.setAggreate(20);
			n = adi.addApplicantDetails(a);
			//System.out.println("hgao"+n);
			assertEquals(1,n);
			
		} catch (ApplicantException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Test
	public void testGetApplicantDetails() throws ApplicantException {
		ApplicantBeen a1 = new ApplicantBeen();
			int eid = 1008;
			
			a1 = adi. getApplicantDetails(eid);
			assertEquals(eid,a1.getApplyid());
		
	}

}
