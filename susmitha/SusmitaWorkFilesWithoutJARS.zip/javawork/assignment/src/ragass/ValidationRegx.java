package ragass;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationRegx {

	public static void main(String[] args) {
		Pattern em = Pattern.compile(("[a-zA-Z][a-zA-Z0-9-.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+"));
		Pattern ph = Pattern.compile(("[7-9][0-9]{9}"));
		Pattern fna = Pattern.compile(("[A-Z][a-z]{1,10}"));
		Pattern lna = Pattern.compile(("[A-Z][a-z]{1,10}"));
	
		Scanner sc = new Scanner(System.in);
		System.out.println("enter First name:");
		String first = sc.next();
		System.out.println("enter Last name:");
		String last = sc.next();
		System.out.println("enter mobile number:");
		String mob = sc.next();
		System.out.println("enter Email id:");
		String email = sc.next();
		Matcher m = em.matcher(email);
		Matcher m1 = fna.matcher(first);
		Matcher m2 = lna.matcher(last);
		Matcher m3 = ph.matcher(mob);
		if (m.find() && m.group().equals(email)) {
			System.out.println("valid email");

		} else {
			System.out.println("not valid email");
		}

		
		if (m1.find() && m1.group().equals(first)) {
			System.out.println("valid first name");

		} else {
			System.out.println("not valid first name");
		}
		
		
		if (m2.find() && m2.group().equals(last)) {
			System.out.println("valid last name");

		} else {
			System.out.println("not valid last name");
		}
		
		
		if (m3.find() && m3.group().equals(mob)) {
			System.out.println("valid number");

		} else {
			System.out.println("not valid number");
		}
		
		sc.close();
	}

}
