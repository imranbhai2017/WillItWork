package Lab8;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ass8_1 {
	public static void main(String[] args) {
        FileReader is;
        FileWriter os;
		try {
			is = new FileReader("readerfile.txt");
		 os = new FileWriter("out.txt");
		 int c;
         while ((c=is.read())!= -1){
        	 
         os.write(c);
        	 
         }
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       
        
		
		
		
		
		
		
		
		/*	FileReader fr = null;
		FileWriter fw = null;
		
		try {
			fr = new FileReader("readerfile.txt");
			
			int n;
			while((n=fr.read()) != -1){
				System.out.print((char)n);
				
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}*/
}
}