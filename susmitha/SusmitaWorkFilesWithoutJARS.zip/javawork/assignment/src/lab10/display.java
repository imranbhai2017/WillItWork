package lab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.util.Properties;

public class display {
	private static FileInputStream fis;
	
	private static Properties p;
	public static Connection c;
	public static void main(String[] args) {
		
     
		displayDetails();

			
	
}

	public static void displayDetails() {
	
			try {
				fis = new FileInputStream("personProp.properties");
				p = new Properties();

				p.load(fis);

				String url = p.getProperty("url");
				String uname = p.getProperty("uname");
				String pass = p.getProperty("pwd");
				
				System.out.println(url);
				System.out.println(uname);
				System.out.println(pass);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				
				e.printStackTrace();
			}
}
	
}