package Lab4;

public class Exp extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Exp() {
		
		super();
		}

		@Override
		public String toString() {
			return "balance cant be less then 500 so withdraw cant be done";
		}


}
