package Lamda;

public class LamdaExp implements lam {

	public static void main(String[] args) {
		lam l = new LamdaExp();
		int x = l.max(4, 5);
		System.out.println("max no.:"+x);
	}
	@Override
	public int max(int n1 ,int n2) {
		return n1>n2?n1:n2;
		
	}
	

}
