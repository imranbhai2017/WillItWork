package Lamda;

public class DemoLamda {
	public static void main(String[] args) {
		lam l = (n1,n2)->n1>n2?n1:n2;
		System.out.println(l.max(6, 4));
	}


}
