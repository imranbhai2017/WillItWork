package Lab9;

import static org.junit.Assert.assertEquals;
import lab2.Person;

import org.junit.Test;

public class PersonTest {
	Person p = new Person();
	@Test
	public void testGetFirstName() {
		p.setFirstName("susmita");
		
		assertEquals("susmita",p.getFirstName());

		
	}

	@Test
	public void testGetLastName() {
		p.setLastName("saha");
		
		assertEquals("saha",p.getLastName());

		
	}

	@Test
	public void testGetGender() {
		p.setGender("F");
		assertEquals("F",p.getGender());
}
}