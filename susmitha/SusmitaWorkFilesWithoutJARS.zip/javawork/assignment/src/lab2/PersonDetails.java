package lab2;

public class PersonDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String firstName = "Divya";
		String lastName = "Bharati";
		String gender = "F";
		int age = 20;
		double weight =85.55;

		System.out.println("First name :" + firstName);
		System.out.println("Last name:" + lastName);
		System.out.println("Gender:" + gender);
		System.out.println("age:" + age);
		System.out.println("Weight:" + weight);

	}

}
