package lab2;

public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p = new Person("Susmita","Saha","female");
		
		System.out.println("First Name:" +p.getFirstName());
		System.out.println("Last Name:" +p.getLastName());
		System.out.println("Gender:"+p.getGender());
	}

}
