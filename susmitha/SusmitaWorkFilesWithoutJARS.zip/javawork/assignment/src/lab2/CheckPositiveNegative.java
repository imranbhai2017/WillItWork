package lab2;
//import java.util.Scanner;
public class CheckPositiveNegative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Scanner reader = new Scanner(System.in);  // Reading from System.in
		//System.out.println("Enter a number: ");
		//int n = reader.nextInt(); 
		int n = Integer.parseInt(args[0]);
		
		if( n>0 )
	{System.out.println("positive number");
			}
		else {
			System.out.println("negative number");}
		}

}
