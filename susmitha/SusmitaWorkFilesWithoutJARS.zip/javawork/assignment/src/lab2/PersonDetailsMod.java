package lab2;

public class PersonDetailsMod {
	private String firstName;
	private String lastName;
	private String gender;
	private int phone;
	
	public String getFirstName() {
		return firstName;
	}
	/*public void setFirstName(String firstName) {
		this.firstName = firstName;
	}*/
	public String getLastName() {
		return lastName;
	}
	/*public void setLastName(String lastName) {
		this.lastName = lastName;
	}*/
	public String getGender() {
		return gender;
	}
	/*public void setGender(String gender) {
		this.gender = gender;
	}*/
	PersonDetailsMod(){
		
	}
	
	PersonDetailsMod(String firstName,String lastName,String gender){  
		 	this.firstName=firstName;
		 	this.lastName=lastName;
		 	this.gender=gender;
		    }  
	
	
	public int setPhone(int phone){
		this.phone = phone;
	return phone;	
	}
	
	public void displayDetails(){
		PersonDetailsMod d =new PersonDetailsMod("susmita","saha","Female");
		
		System.out.println("first name:"+d.getFirstName());
		System.out.println("last name:"+ d.getLastName());
		System.out.println("gender:"+d.getGender());
		System.out.println("phone numbmber:"+d.setPhone(3333));
	}
	


}