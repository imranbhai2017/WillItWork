package lab2;


public class PersonModMain {

	public static void main(String[] args) {
		PersonDetailsMod m = new PersonDetailsMod();
		m.displayDetails();

	}

}
