package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringOperation {

	String str1;
	

	
	public static void main(String[] args) throws IOException {
		StringOperation o = new StringOperation();

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
		
		System.out.println("string operations");
		System.out.println("1 for add");
		System.out.println("2 for odd palce change");
		System.out.println("3 for replace ");
		System.out.println("4 for upper case");
		System.out.println("enter option:");
		//int number =3;
		//Scanner sc = new Scanner(System.in);
		//int number = sc.nextInt();
		//sc.nextLine();
		//System.out.println(number);
		
		int value = Integer.parseInt(br.readLine());
		o.convert(value); 
		
		//sc.close();
	}
	
	public String input() throws IOException {
		System.out.println("enter string:");
		BufferedReader  b = new BufferedReader(new InputStreamReader(System.in));
		String str = b.readLine();
		return str;
	}
	
	public void convert(int value) throws IOException {
		
		switch (value) {
		case 1:
			addString();
			
			break;
		case 2:
			replaceString();
			break;
		case 3:
			removeDuplicateString();
			break;

		case 4:
			uppercaseString();
			break;
		default:
			System.out.println("Not in 10, 20 or 30");
			break;
		}

	

	}

	public void addString() throws IOException {
		String str5 = input();
		//this.str1 = str5 + str5;
		System.out.println(str5 + str5);

	}

	public void replaceString() throws IOException {
		String str5 = input();
		 
	        for (int i = 0; i < str5.length(); i++) {
	            
	            if (i%2!=0) 
	            	System.out.print("#");
	            else
	            	
	            	System.out.print(str5.charAt(i));
	}
	}

	public void removeDuplicateString() throws IOException {
		String str5 = input();
		String output = new String();

		 for (int i = 0; i < str5.length(); i++) {
	            for (int j = 0; j < output.length(); j++) {
	                if (str5.charAt(i) != output.charAt(j)) {
	                    output = output + str5.charAt(i);
	                }
	            }
	            System.out.println(output);
	        }

	        

	    
	}

	public void uppercaseString() throws IOException {
		String str5 = input();
		  for (int i = 0; i < str5.length(); i++) {
	            
	            if (i%2 == 0) 
	            	System.out.print(str5.toUpperCase().charAt(i));
	            else
	            	
	            	System.out.print(str5.charAt(i));
	

	}

}
}