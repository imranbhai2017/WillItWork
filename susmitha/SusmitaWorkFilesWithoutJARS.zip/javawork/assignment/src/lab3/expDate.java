package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class expDate {
	
	public static void main(String[] args) throws IOException {
		
		expDate e = new expDate();
		e.calExpDate();
	}

	public void calExpDate() throws IOException{
		int month;
		int year;
		String day;
		int expMonth;
		int expYear;
		BufferedReader  b = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter  day:");
		 day = b.readLine();
		 System.out.println("enter  month:");
		 month = Integer.parseInt(b.readLine());
		 System.out.println("enter  year:");
		 year = Integer.parseInt(b.readLine());
		 System.out.println("enter exp month:");
		 expMonth = Integer.parseInt(b.readLine());
		 System.out.println("enter exp year:");
		 expYear =Integer.parseInt(b.readLine());
		  System.out.println("expiry date:"+ day +"/" + (month+expMonth) +"/" + (year+expYear) );
		
	}
}
