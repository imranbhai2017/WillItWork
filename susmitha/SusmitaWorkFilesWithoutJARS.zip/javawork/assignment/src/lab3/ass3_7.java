package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Calendar;

public class ass3_7 {
	public static void main(String[] args) throws IOException {
		
		ass3_7 a = new ass3_7();
		a.fullName();
		a.calAge();

	}
	public void calAge() throws IOException{
		BufferedReader  b = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("------------------Date Of Birth---------------");
		System.out.println("enter  day:");
		 int day =Integer.parseInt( b.readLine());
		 System.out.println("enter  month:");
		 int month = Integer.parseInt(b.readLine());
		 System.out.println("enter  year:");
		 int year = Integer.parseInt(b.readLine());
		 int year1 = Calendar.getInstance().get(Calendar.YEAR);
		 System.out.println("age:" + (year1-year));
	}
 
	 public void fullName() throws IOException{
		 BufferedReader  b = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("enter first name:");
			 String fName = b.readLine();
			 System.out.println("enter second name:");
			 String  sName = b.readLine();
			 
			 
			 System.out.println("full name:"+ fName +" " + sName);
	 }
}
