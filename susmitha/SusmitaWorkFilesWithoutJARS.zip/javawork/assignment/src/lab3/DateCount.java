package lab3;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class DateCount {

	    public static void main(String[] args) throws IOException {

	    	long day;
	    	double month;
	    	double year;
	    	
	    	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
			Scanner scanner = new Scanner(System.in);
			System.out.print("Enter date in dd/MM/yyyy format:");
			String input  = scanner.nextLine();
			
			//Almost every class in java.time package provides parse() method to parse the date or time
			LocalDate oldDate = LocalDate.parse(input,formatter);
			LocalDate currentDate = LocalDate.now();
			
			System.out.println("Entered Date:"+ oldDate);
			
			
	        System.out.println("\n--- Duration.between --- ");

	        System.out.println(oldDate);
	        System.out.println(currentDate);

	       //System.out.println( "days:" + currentDate.get(ChronoUnit.DAYS));
	        //count seconds between dates
	        Duration duration = Duration.between(oldDate, currentDate);
	       
	        day = duration.getSeconds()/86400;
	        month=duration.getSeconds()/2.628e+6;
	        year = duration.getSeconds()/3.154e+7;
	        		///86400;
	        
	        System.out.println( Math.round(day) + " days");
	        System.out.println( Math.round(month) + " month");
	        System.out.println(Math.round(year) + " year");
	        scanner.close();
	    }
	}

