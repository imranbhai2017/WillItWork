package lab3;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class CheckString {

	public static void main(String[] args) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String string = br.readLine();
	
		 for (int i = 0; i < string.length()-1; i++) {
	            
	            if (((int)string.charAt(i))>((int)string.charAt(i+1))) 
	            	{System.out.print("negative");
	            
	            	}
	            else
	            {      System.out.println("possitive");
	            }
		
		 }
	}
}
