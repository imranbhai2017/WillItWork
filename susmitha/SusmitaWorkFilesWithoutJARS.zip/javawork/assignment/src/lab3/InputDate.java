package lab3;
import java.util.*;
import java.text.*;
public class InputDate {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		SimpleDateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		Date testDate = null;
		String date = sc.nextLine(); 
		try{
		    testDate = df.parse(date);
		} catch (ParseException e){ System.out.println("invalid format");}
		 
		if (!df.format(testDate).equals(date)){
		    System.out.println("invalid date!!");
		} else {
		    System.out.println("valid date");
		}
		

	 
	}
}
