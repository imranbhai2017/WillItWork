package Lab7;

import java.util.Arrays;

public class ArraySort {

	public static void main(String[] args) {
		String[] productArr = new String[]{"phone", "air", "camera", "wiper", "marker", "bob"};
		 Arrays.sort(productArr);
		 //print sorted elements
         for(int i=0; i < productArr.length; i++){
                 System.out.println(productArr[i]);
         }
	}

}
