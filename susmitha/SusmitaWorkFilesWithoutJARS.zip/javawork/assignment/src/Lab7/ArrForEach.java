package Lab7;

import java.util.Arrays;

public class ArrForEach {
	public static void main(String[] args) {
	String[] productArr = new String[]{"phone", "air", "camera", "wiper", "marker", "bob"};
	 Arrays.sort(productArr);

	 for (String  i : productArr) {
	    	System.out.println(i);
			
		}
	}
}
