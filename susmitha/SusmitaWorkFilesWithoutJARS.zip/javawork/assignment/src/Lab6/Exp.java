package Lab6;

public class Exp extends Exception {
	public Exp() {
		
		super();
		}

		@Override
		public String toString() {
			return "balance cant be less then 500 so withdrawcantbe done";
		}


}
