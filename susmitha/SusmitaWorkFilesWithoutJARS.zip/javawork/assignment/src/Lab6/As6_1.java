package Lab6;



public class As6_1 {
	private String firstName;
	private String lastName;
	private String gender;
	private int phone;
	
	public String getFirstName() {
		return firstName;
	}
	/*public void setFirstName(String firstName) {
		this.firstName = firstName;
	}*/
	public String getLastName() {
		return lastName;
	}
	/*public void setLastName(String lastName) {
		this.lastName = lastName;
	}*/
	public String getGender() {
		return gender;
	}
	/*public void setGender(String gender) {
		this.gender = gender;
	}*/
	As6_1(){  
	 
	    }  
	
	As6_1(String firstName,String lastName,String gender){  
		 	this.firstName=firstName;
		 	this.lastName=lastName;
		 	this.gender=gender;
		    }  
	
	
	public int setPhone(int phone){
		this.phone = phone;
	return phone;	
	}
	
	public void displayDetails(){
		As6_1 d =new As6_1("","saha","Female");
		if(d.getFirstName().isEmpty())
		{
			try{
				throw new EmptyExp();
			}catch (EmptyExp e) {
				System.out.println(e);
			}
			
		}
		else{
			System.out.println("first name:"+d.getFirstName());
		}
				
		
		System.out.println("last name:"+ d.getLastName());
		System.out.println("gender:"+d.getGender());
		System.out.println("phone numbmber:"+d.setPhone(3333));
	}
	
}
