package Lab6;

import java.util.Scanner;

import Lab4.Account;
import Lab4.Exp;

public class As6_2 {
	public static void main(String[] args) {
		 Account a = new Account();
		 Scanner sc = new Scanner(System.in);
		 
		 int minimum= 100;
		 int maximum =200;
		 int accnum;
		 int accnum1;
		 int deposit;
		 int withdraw;
		 accnum=minimum + (int)(Math.random() * maximum); 
		 accnum1=minimum + (int)(Math.random() * maximum); 
		 
		
		 System.out.println("----------------------------------------------------");
		 
		 a.setName("Smith");
		 System.out.println(" accunt holder name:"+a.getName());
		 a.setAge(10);
		 System.out.println("age:"+a.getAge());
		 
		 if(a.getAge()<15){
			 try{
				 System.out.println("try after few years");
				  throw new Exp1();
			 }catch(Exp1 e){
				 
			 System.out.println(e);
			 }
		 }
		 else{
			 System.out.println(" age:"+a.getAge());
			 a.setAccNum(accnum);
			 System.out.println("account no:"+a.getAccNum());
			 a.setBalance(2000);
			 double ob1= a.getBalance();
			 System.out.println("Exsisting balance:"+ a.getBalance());
			 System.out.println("enter amount to be deposited :");
			 deposit = sc.nextInt();
			 a.setBalance(a.getBalance() + deposit);
			 if (a.getBalance()< 500) {
				 
					try {
						throw new Exp();
					} catch (Exception e) {
						
					System.err.println("minimum balance required in 500 so withdraw not possible");
					System.out.println("present balance:"+ ob1);
					}
				 
			 }
			 else{
			 System.out.println("present balance:"+ a.getBalance());
			 }
			 
		 }
		 
		 System.out.println("----------------------------------------------------");
		 
		 a.setName("Kathy");
		 System.out.println(" accunt holder name:"+a.getName());
		 a.setAge(35);
		 if(a.getAge()>15){
			 try{
		 System.out.println(" age:"+a.getAge());
		 a.setAccNum(accnum1);
		 System.out.println("account no:"+a.getAccNum());
		 a.setBalance(3000);
		 double ob =a.getBalance();
		 System.out.println("balance:"+ a.getBalance());
		 System.out.println("enter amount to be withdraw :");
		 withdraw = sc.nextInt();
		 a.setBalance(a.getBalance() - withdraw);
		 sc.close();
		 if (a.getBalance()< 500) {
			 
				try {
					throw new Exp();
				} catch (Exception e) {
					
				System.err.println("minimum balance required in 500 so withdraw not possible");
				System.out.println("present balance:"+ ob);
				}
			 
		 }
		 else{
			 System.out.println("present balance:"+ a.getBalance());
			 }
		 throw new Exp1();
			 }catch(Exception e){
				 
			 //System.out.println("age not sufficent");
			 }
		 }
		 else{
			  System.out.println("try after few years");
		 }
		// System.out.println(a.getAccNum());
		sc.close();
	}
}
