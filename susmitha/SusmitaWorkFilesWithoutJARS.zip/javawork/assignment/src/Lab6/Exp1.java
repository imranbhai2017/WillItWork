package Lab6;

public class Exp1 extends Exception {
public Exp1() {
		
		super();
		}

		@Override
		public String toString() {
			return "age not sufficent222";
		}

}
