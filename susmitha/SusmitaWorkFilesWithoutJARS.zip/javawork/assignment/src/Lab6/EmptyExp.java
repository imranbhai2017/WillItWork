package Lab6;


public class EmptyExp extends Exception{
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public EmptyExp(){
	super();
	
}

@Override
public String toString() {
	return "field empty";
}

}
