package Lab6;


public class As6_1Main {

	
	public static void main(String[] args) throws EmptyExp {
	 As6_1 a = new As6_1();
		
		
	a.displayDetails();

	}

}
 