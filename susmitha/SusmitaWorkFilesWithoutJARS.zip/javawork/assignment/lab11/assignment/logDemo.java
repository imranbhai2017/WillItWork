package assignment;

import org.apache.log4j.Logger;

public class logDemo {
	static Logger log = Logger.getRootLogger();
public static void main(String[] args) {
	
	
	int number1=10;
	int number2 = 20;
	log.info("number initialized");
	System.out.println("adition of number 1 and nunber 2"+"  :  "+(number1+number2));
	log.info("addition done");
}
}
