package thread;

public class Counselling implements Runnable {

	int seat = 1;
	
	public synchronized void run(){
	
		System.out.println("no. of seats befour"+ seat);
	
		if(seat>0)
		{
			System.out.println("seat allocated to "+ Thread.currentThread().getName());
		
		seat--;
		}
		else 
		{
			System.out.println("no seats available");
		}
		System.out.println("no seats after:"+seat);
	}
	
	public static void main(String[] args) {
	 Counselling c = new Counselling();  
	 
	 Thread t1 = new Thread(c,"rajiv");
	
	 Thread t2 = new Thread(c,"satakshi");
	 t1.setPriority(Thread.MIN_PRIORITY);  
	  t2.setPriority(Thread.MAX_PRIORITY);  
	 
	 t1.start();
	 t2.start();
	 
	 
	}

}
