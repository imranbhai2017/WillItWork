package lab5_3;

import java.util.Scanner;


public class AccountUpdate {

	public static void main(String[] args) {
		 Account a = new Account();
		 Scanner sc = new Scanner(System.in);
		 
		 int minimum= 100;
		 int maximum =200;
		 int accnum;
		 int accnum1;
		 int deposit;
		 //int withdraw;
		 accnum=minimum + (int)(Math.random() * maximum); 
		 accnum1=minimum + (int)(Math.random() * maximum); 
		 
		
		 System.out.println("----------------------------------------------------");
		 
		 a.setName("Smith");
		 System.out.println(" accunt holder name:"+a.getName());
		 a.setAge(30);
		 System.out.println(" age:"+a.getAge());
		 a.setAccNum(accnum);
		 System.out.println("account no:"+a.getAccNum());
		 a.setBalance(2000);
		 double ob1= a.getBalance();
		 System.out.println("Exsisting balance:"+ a.getBalance());
		 System.out.println("enter amount to be deposited :");
		 deposit = sc.nextInt();
		 a.setBalance(a.getBalance() + deposit);
		 if (a.getBalance()< 500) {
			 sc.close();
				try {
					throw new Exp();
				} catch (Exp e) {
					
				System.err.println("exception" + e);
				System.out.println("present balance:"+ ob1);
				}
			 
		 }
		 else{
		 System.out.println("present balance:"+ a.getBalance());
		 }
		 
		 
		 
		 System.out.println("----------------------------------------------------");
		 
		 a.setName("Kathy");
		 System.out.println(" accunt holder name:"+a.getName());
		 a.setAge(35);
		 System.out.println(" age:"+a.getAge());
		 a.setAccNum(accnum1);
		 System.out.println("account no:"+a.getAccNum());
		 a.setBalance(3000);
		 
		 System.out.println("balance:"+ a.getBalance());
		 withdrawf();
		
		 sc.close();
		
		
		// System.out.println(a.getAccNum());
		
	}

	public void deposit(){
		
	}
	
	public static void withdrawf(){
		 int withdraw;
		 Scanner sc = new Scanner(System.in);
		   Account a = new Account();
		   a.setBalance(3000);
		 System.out.println("enter amount to be withdraw :");
		 withdraw = sc.nextInt();
		
		 a.setBalance(a.getBalance() - withdraw);
		 
		 if (a.getBalance()< 500) {
			 sc.close();
				try {
					throw new Exp();
				} catch (Exp e) {
					
				System.err.println(e);
				//System.out.println("present balance:"+ ob);
				}
			 
		 }
		 else{
		 System.out.println("present balance:"+ a.getBalance());
		 }
		 
		 
	}
	
	public void getBal(){
	}

}
