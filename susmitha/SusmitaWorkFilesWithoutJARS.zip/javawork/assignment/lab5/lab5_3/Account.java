package lab5_3;



public class Account extends Person{

	
    private long accNum;
    private double balance;
    private Person accHolder;
   // Scanner sc = new Scanner(System.in);
    //Account a = new Account();
	public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	} 
    
    
	}

