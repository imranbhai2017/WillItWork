package com.capgemini.emp.ui;

import com.capgemini.emp.sevice.EmployeeService;

public class Util {

public static EmployeeService getObject(){
		
		return new UI();
	}
	
}
