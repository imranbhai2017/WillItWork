package com.capgemini.emp.exception;

public class Exception {

}
