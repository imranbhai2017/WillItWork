package com.capgemini.emp.sevice;

import com.capgemini.emp.bean.Employee;

public interface EmployeeService {
	public abstract int getDetails(Employee e);
		
}
