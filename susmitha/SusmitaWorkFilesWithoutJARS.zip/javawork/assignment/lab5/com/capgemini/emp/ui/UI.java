package com.capgemini.emp.ui;

import java.util.Scanner;

import com.capgemini.emp.bean.Employee;
import com.capgemini.emp.sevice.EmployeeService;
import com.capgemini.emp.sevice.EmployeeServiceImp;

public class UI extends EmployeeServiceImp {

	public static void main(String[] args) {
		
		EmployeeService ei = Util.getObject();
		Employee e = new Employee();
		
		System.out.println("*********************************");
		System.out.println("welcom to emply medical insurance system ");
		System.out.println("*********************************");
		System.out.println("1. Register details.");
		System.out.println("2.exit.");
		System.out.println("-----------------------------------");
			
			
		Scanner sc = new Scanner(System.in);
		int key= sc.nextInt();
		System.out.println("you have entered" + key);
		System.out.println("-----------------------------------");
		
		switch (key) {
		case 1:
			
		
			ei.getDetails( e);
			
			break;
		case 2:
			System.exit(0);
			break;
		default:
			
			System.err.println("enter valid option.");
			break;
		}
		sc.close();
	}
}
