package proutil;

public class Employee {
	int eid;
	public Employee(int eid){
		this.eid = eid;
		
	}
	public int hashcode(){
		return eid;
		
	}
	public String toString(){
		return eid+"";
	}

}
