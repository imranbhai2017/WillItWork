package proutil;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		
		System.out.println("-------- hash map---------");
		Map<Integer, String> m = new HashMap<Integer, String>();
		m.put(101, "susmita");
		m.put(103, "megha");
		m.put(104, "souma");
		m.put(null, "joy");
		m.put(102, "tuhim");
		System.out.println(m);

		System.out.println("-------- hash table---------");
		Map<Integer, String> mh = new Hashtable<Integer, String>();
		mh.put(101, "susmita");
		mh.put(103, "megha");
		mh.put(104, "souma");
		mh.put(101, "joy");
		mh.put(102, "tuhim");
	
		System.out.println(mh);
	

		System.out.println("--------linked  hash map---------");
		Map<Integer, String> m1 = new LinkedHashMap<Integer, String>();
		m1.put(101, "susmita");
		m1.put(103, "megha");
		m1.put(102, "souma");
		m1.put(106, "joy");
		System.out.println(m1);
		System.out.println(m1.get(106));
		
		Set<Integer> s = m1.keySet();
		
		
		/*for (Integer i: s) {
			
			System.out.println(i + "  " +  m1.get(k));
		}*/
		
		System.out.println("------------------------------");
		
		Iterator<Integer> it =  s.iterator();
		while (it.hasNext()){
			Integer k = it.next();
			String v = m.get(k);
			
			System.out.println(k + " " + v);
		}
		
		
		
		
		
	}
	}

