package proutil;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;

public class ListDemo {

	public static void main(String[] args) {
		System.out.println("--------------Array List-----------------");
		List<Integer> list = new ArrayList<Integer>();
		/*list.add(new Integer(4));
		list.add(new String("java"));
		list.add(new ListDemo());
		*/
		
		
		System.out.println(list.add(4));
		list.add(5);
		list.add(5);
		list.add(7);
		list.add(6);
		System.out.println(list.add(null));
		
		for (Integer i : list) {
			System.out.println(i);
		}
		//System.out.println(list);
		
		System.out.println("-------------Link List------------------");
		
		
		List<Integer> listL = new LinkedList<Integer>();
		
		System.out.println(listL.add(4));
		listL.add(5);
		listL.add(5);
		listL.add(7);
		listL.add(6);
		//listL.addFirst(10);
		//listL.addLast(11);
		
		System.out.println(listL.add(null));
		
		System.out.println(listL);
		
		System.out.println("-------------Vector------------------");
		Vector<Integer> listv = new Vector<Integer>();
		
		System.out.println(listv.add(4));
		listv.add(5);
		listv.add(5);
		listv.add(7);
		listv.add(6);
		//listL.addFirst(10);
		//listL.addLast(11);
		
		System.out.println(listv.add(null));
		
		System.out.println(listv);
		
		
		System.out.println("-------------Iterator------------------");
		
		
		ListIterator<Integer> it = list.listIterator();
		it.hasNext(); it.hasNext();
		while (it.hasNext()) {
			System.out.println(it.next());
			
		}
	}
	

}
