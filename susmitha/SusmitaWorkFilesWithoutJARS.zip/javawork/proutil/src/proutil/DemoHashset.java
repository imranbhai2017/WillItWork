package proutil;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class DemoHashset {

	public static void main(String[] args) {
		System.out.println("------------Link hash set---");
		Set<String> s = new LinkedHashSet<String>();
		System.out.println(s.add("B"));
		s.add("E");
		s.add("A");
		s.add("D");
		s.add("C");
		System.out.println(s.add("B"));
		s.add(null);
	System.out.println(s);
System.out.println("------------Tree set---");
	

	Set<Integer> ts = new TreeSet<Integer>();
	System.out.println(ts.add(6));
	ts.add(4);
	ts.add(2);
	ts.add(1);
	ts.add(7);
	System.out.println(ts.add(8));
	
System.out.println(ts);

System.out.println("------------stringbuffer set---");


Set<StringBuffer> s1 = new TreeSet<StringBuffer>(new MyComparator());

s1.add(new StringBuffer("A"));
s1.add(new StringBuffer("C"));
s1.add(new StringBuffer("D"));
s1.add(new StringBuffer("B"));


System.out.println(s1);

	}

}
