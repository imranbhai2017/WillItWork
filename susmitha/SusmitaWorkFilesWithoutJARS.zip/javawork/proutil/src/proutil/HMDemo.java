package proutil;

import java.util.Hashtable;
import java.util.Map;

public class HMDemo {
//duplicate key can be done by overriding hashcode method 
	
	public static void main(String[] args) {
		Map<Employee,String> m = new Hashtable<Employee,String>();
		m.put(new Employee(101), "raju");
		m.put(new Employee(102), "kiyara");
		m.put(new Employee(105), "rahul");
		m.put(new Employee(104), "doog");
		m.put(new Employee(106), "nill");
		System.out.println(m);
	}

}
