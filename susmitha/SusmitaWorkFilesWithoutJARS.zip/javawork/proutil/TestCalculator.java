package com.test;

import static junit.framework.Assert.*;//after this u dont need to use Assert keyword

import org.junit.Test;

public class TestCalculator {                 
	Calculator c = new Calculator();
	@Test 									   	//anutation : referance
	public void TestAdd() {                    //test methods
		assertEquals(10, c.add(5,5));
		//Assert.assertEquals(10, c.add(5,5));	//checks the output
        //Assert.assertNotNull(c);
	}
												//right click > run as > junit
	@Test
	public void TestSub() {
		//Assert.assertEquals(1, c.sub(3,2));
		assertEquals(1, c.sub(3,2));
	}

}
