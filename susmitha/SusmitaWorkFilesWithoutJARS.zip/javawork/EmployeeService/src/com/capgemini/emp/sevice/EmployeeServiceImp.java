package com.capgemini.emp.sevice;

import java.util.Scanner;

import com.capgemini.emp.bean.Employee;

public class EmployeeServiceImp implements EmployeeService {
	
	
	@Override
	public int getDetails(Employee e) {
		//Employee e =new Employee();
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter id:");
		int eid=sc.nextInt();
		sc.nextLine();
		e.setEmpid(eid);
		
		
		System.out.println("enter name:");
		String ename=sc.next();
		sc.nextLine();
		e.setEmpname(ename);
		
		
		System.out.println("enter salary:");
		double esalary=sc.nextDouble();
		sc.nextLine();
		e.setEmpsalary(esalary);
		
		if(e.getEmpsalary()>500 && e.getEmpsalary()<20000){
			e.setEmpdesig("system associate");
			e.setInsuranceScheme("schema C");
		}else if(e.getEmpsalary()>= 20000 && e.getEmpsalary()<40000){
			
			e.setEmpdesig("programer");
			e.setInsuranceScheme("schema B");
		}else if( e.getEmpsalary()<5000){
			
			e.setEmpdesig("clerk");
			e.setInsuranceScheme("No schema ");
		}else{
			e.setEmpdesig("maneger");
			e.setInsuranceScheme("schema A");
		}

		
		System.out.println("insertion done....");
		System.out.println("ID:"+e.getEmpid());
		System.out.println("Name:"+e.getEmpname());
		System.out.println("Salary:"+e.getEmpsalary());
		System.out.println("Designation:"+e.getEmpdesig());
		System.out.println("Insurance Schema:"+e.getInsuranceScheme());
		
		sc.close(); 
		return 0;
	}

	@Override
	public Object selectEmp(Employee e) {
		
	System.out.println("employee selected.");
	
	return null;
	}

	@Override
	public int updateEmp(Employee e) {
		System.out.println("employee updated.");
		return 0;
	}

	@Override
	public int deleteEmp(Employee e) {
		System.out.println("employee deleted.");
	return 0;
	}


	

}
