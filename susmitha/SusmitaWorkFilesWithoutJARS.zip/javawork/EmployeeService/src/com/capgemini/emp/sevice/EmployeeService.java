package com.capgemini.emp.sevice;

import com.capgemini.emp.bean.Employee;

public interface EmployeeService {
	public abstract int getDetails(Employee e);
	public abstract Object selectEmp(Employee e);
	public abstract int updateEmp(Employee e);
	public abstract int deleteEmp(Employee e);
	
}
