package com.test;

//import static org.junit.Assert.*;

import static junit.framework.Assert.*;

import org.junit.Before;
import org.junit.Test;
public class CalculatorTest {
   Calculator c;
   
   @Before
   public void m1(){
	   c=new Calculator();
	   System.out.println("m1 method called b4 annotation");
   }
	@Test
	public void testAdd() {
		assertEquals(10, c.add(5,5));
		
		
	}
	@Test(expected= ArithmeticException.class)
	public void testDiv() {
		assertEquals(10, c.div(5,0));
		
		
	}

	@Test
	//@Ignore
	public void testSub() {
		assertEquals(1, c.sub(6,5));
	}

}
