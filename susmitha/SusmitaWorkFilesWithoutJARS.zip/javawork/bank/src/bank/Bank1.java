package bank;

public abstract class Bank1 implements IBank {

	public void deposit(){
		System.out.println("deposited.....");
	}
	public abstract void withdraw();
	/*public void width(){
		System.out.println("");
	}*/
}
