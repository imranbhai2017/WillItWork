package bank;

public class Bank2 extends Bank1 {

	public void withdraw(){
		System.out.println("withdraw done... ");
	}
}
