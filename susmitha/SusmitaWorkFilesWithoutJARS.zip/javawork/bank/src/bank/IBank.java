package bank;

public interface IBank {

		public static final int ifc = 2009;
		public abstract void deposit();
		public abstract void withdraw();
		
		public default void m1(){
			System.out.println("in java 8 methods can be diclared in interface by using default keywork");
		}
		
		
	
}
