package bank;

import java.util.Scanner;

public class User {

	public static void main(String[] args) {
		
		
		
		IBank b2= Util.getObject();
		
		System.out.println("*************************");
		System.out.println("WELCOME TO ATM");
		System.out.println("*************************");

		System.out.println("1.enter for deposit.");
		System.out.println("2.enter for withraw.");
		System.out.println("3.exit.");
		
		Scanner sc = new Scanner(System.in);
		int choice = sc.nextInt();
		
		switch (choice) {
		case 1:
			b2.deposit();
			break;
		case 2:
			b2.withdraw();
			break;

		case 3:
			System.exit(0);//kill jvm (main thrd) 
			break;


		default:
		/*for printing in red */ System.err.println("enter a valid option.");
			break;
		}
		
	
	sc.close();
	b2.m1();

	}

}
