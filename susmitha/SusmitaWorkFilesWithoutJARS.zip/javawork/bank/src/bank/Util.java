package bank;

public class Util {
		
	public static IBank getObject(){
		
		return new Bank2();
	}
}
