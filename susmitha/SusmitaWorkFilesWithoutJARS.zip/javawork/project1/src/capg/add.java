package capg;

public class add {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("welcom to first project of java");
		byte b = (byte) 500; //explcit type casting
		short s = b; //implcit  type casting
		float f = 4.55f;
		System.out.println(s+ "    "+b+"  "+f);
		for (int i = 0; i < args.length; i++) {
			
		}
}
}