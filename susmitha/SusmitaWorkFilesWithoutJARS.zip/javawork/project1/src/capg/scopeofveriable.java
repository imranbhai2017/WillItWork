package capg;

public class scopeofveriable {

}
