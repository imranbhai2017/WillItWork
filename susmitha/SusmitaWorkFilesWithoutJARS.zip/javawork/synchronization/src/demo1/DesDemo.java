package demo1;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DesDemo {
public static void main(String[] args) {
	FileInputStream fis = null;
	ObjectInputStream ois;
	try {
		fis = new FileInputStream("input.ser");
		
		ois = new ObjectInputStream(fis);
		Object o = ois.readObject();
		Employee e = (Employee) o;//type casting 
		System.out.println(e.getEid()+"          " +e.getEname());
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
}
}
