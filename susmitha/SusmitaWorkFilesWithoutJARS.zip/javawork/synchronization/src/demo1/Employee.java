package demo1;

import java.io.Serializable;

public class Employee implements Serializable{
   transient int eid;//not to serialize while serializing object 
   public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}
String ename;
	public static void main(String[] args) {
		

	}

}
