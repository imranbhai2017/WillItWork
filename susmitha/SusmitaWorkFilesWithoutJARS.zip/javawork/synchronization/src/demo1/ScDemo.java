package demo1;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ScDemo {
	
	static FileOutputStream fos =  null;
	static ObjectOutputStream oos = null;
	
	public static void main(String[] args) {
		Employee e = new Employee();
		e.setEid(1001);
		e.setEname("raju");
		
		
		try {
			fos = new FileOutputStream("input.ser");
			 oos = new ObjectOutputStream(fos);
			 oos.writeObject(e);
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}

}
