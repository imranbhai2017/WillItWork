package io.pak;

import java.io.File;

public class FDemo {

	public static void main(String[] args) {
		File f = new File("input.txt");
		
		System.out.println("exists::"+f.exists());
		System.out.println("length::"+f.length());
		System.out.println("getAbsolutePath::"+f.getAbsolutePath());
		System.out.println("getName::"+f.getName());
		System.out.println("isFile::"+f.isFile());
		System.out.println("lastModified::"+f.lastModified());
		System.out.println("canRead::"+f.canRead());
		
		
	
	
	}

}
