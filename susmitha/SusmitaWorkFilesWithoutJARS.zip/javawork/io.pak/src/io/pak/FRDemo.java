package io.pak;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FRDemo {

	public static void main(String[] args) {
		FileReader fr = null;
		try {
			fr = new FileReader("output.txt");
			
			int n;
			while((n=fr.read()) != -1){
				System.out.print((char)n);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
