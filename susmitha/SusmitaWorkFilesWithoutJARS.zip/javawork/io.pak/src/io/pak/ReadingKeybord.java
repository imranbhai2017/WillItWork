package io.pak;

import java.io.IOException;

public class ReadingKeybord {

	public static void main(String[] args) {
		try {
			int n;
			while((n=System.in.read()) != -1){
				System.out.print((char)n);
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
