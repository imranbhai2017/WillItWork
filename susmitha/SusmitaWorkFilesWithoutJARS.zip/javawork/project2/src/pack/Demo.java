package pack;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class Demo {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		/*Scanner sc = new Scanner(System.in);//creating an object of Scanner class
		
		System.out.println("id:");
		String id = sc.nextLine(); //read value from keyboard by next() and store in str. next() can read only one token 
		System.out.println("id:"+ id);//printing it ..
		
		System.out.println("name:");
		String name = sc.nextLine();
		System.out.println("name:" +name);
		
		System.out.println("salary:");
		double sal = sc.nextDouble();
		System.out.println("salary:" +sal);
		sc.nextLine();
		System.out.println("phone:");
		int phone = sc.nextInt();
		System.out.println("number:" +phone);*/
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter first name :");
		String fname = br.readLine();
		System.out.println("enter last name :");
		String lname = br.readLine();
		
		System.out.println("enter salary :");
		int sal = Integer.parseInt(br.readLine());
		
		//int sal1 = Integer.parseInt(sal);
		
		System.out.println("Full name :" +fname + " "+ lname);
		System.out.println("salary:"+sal);
					/*Employee e = new Employee();
					
					e.setEid(101);
					e.setEname("susmita");
					int eid = e.getEid();
					String ename = e.getEname();
	  				System.out.println(eid);
					System.out.println(ename);*/
				
		br.close();
}
}