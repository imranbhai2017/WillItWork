package pack;

public class demo1 {

	public static void main(String[] args) {
		
		customer c1 = new customer(101,"susmita",4444);
		customer c2 = new customer(102,"megha",4004);
		
		customer c3 = new customer(103,"mr.khan",5003);
		
		System.out.println(c1.getcNo());
		System.out.println(c1.getcName());
		System.out.println(c1.getcPhone());
		
		System.out.println(c2.getcNo());
		System.out.println(c2.getcName());
		System.out.println(c2.getcPhone());
		
		System.out.println(c3.getcNo());
		System.out.println(c3.getcName());
		System.out.println(c3.getcPhone());
	}

}
