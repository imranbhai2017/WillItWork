package pack;

public class Studdemo {

}
