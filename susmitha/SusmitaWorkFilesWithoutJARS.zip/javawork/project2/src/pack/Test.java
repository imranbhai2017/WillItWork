package pack;

public class Test {
	
	
	
		int eid;
		String ename;
		
	public Test() {
		super();
		System.out.println("test cunstructor is called");
	}
	public int getEid() {
		return eid;
	}
	public String getEname() {
		return ename;
	}
	
	
	
	public Test(int eid,String ename){
		this();
		this.eid = eid;
		this.ename = ename;
		
	}

	public static void main(String[] args) {
		
		Test t= new Test(1001,"susmita");
		System.out.println(t.getEid());
		System.out.println(t.getEname());
		t.m1();
		t.m1(1,1.1f);
	}
	public void m1(){
		System.out.println("m1() is called");
	}
	
	public void m1(int i,float f){
		System.out.println("m1(parameter) is called");
	}
	public void m1(int ...x){
		System.out.println("m1(..)"+x[0]);
		
	}
	
}
