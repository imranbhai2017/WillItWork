package pack;

public class customer {
/* @Override
	public String toString() {
		return this.cNo+"";
	}
	*/
private int cNo;
 private String cName;
 private int cPhone;
public int getcNo() {
	return cNo;
}
public void setcNo(int cNo) {
	this.cNo = cNo;
}
public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
public int getcPhone() {
	return cPhone;
}
public void setcPhone(int cPhone) {
	this.cPhone = cPhone;
}
public customer(int cNo, String cName, int cPhone) {
	super();
	this.cNo = cNo;
	this.cName = cName;
	this.cPhone = cPhone;
}
 
}
