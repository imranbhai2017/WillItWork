package com.capg.ems.service;

import java.sql.ResultSet;

import com.capg.ems.bean.Employee;

public interface EmployeeService {
	int updateEmp(Employee e);
	int deleteEmp(Employee e);
	ResultSet selectEmp(Employee e);
	int addEmp(Employee e);
}
