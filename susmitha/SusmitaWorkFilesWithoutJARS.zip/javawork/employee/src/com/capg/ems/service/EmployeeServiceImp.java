package com.capg.ems.service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Scanner;

import com.capg.dao.service.EmpDaoImp;
import com.capg.ems.bean.Employee;

public class EmployeeServiceImp implements EmployeeService {

	int n;
	Connection c = null;
	ResultSet rs;
	EmpDaoImp dao = new EmpDaoImp();
	private Scanner in = new Scanner(System.in);

	@Override
	public int updateEmp(Employee e) {
		/* int geid = e.getEid(); */

		System.out.println("Enter First Name:");
		e.setFname(in.next());
		System.out.println("Enter Last Name:");
		e.setLname(in.next());
		System.out.println("Enter Employee Salary:");
		e.setSal(in.nextDouble());
		return dao.updateEmp(e);
	}

	@Override
	public int deleteEmp(Employee e) {
		// Validation-perform
		// System.out.println("This is esi delete function");
		return dao.deleteEmp(e);
	}

	@Override
	public ResultSet selectEmp(Employee e) {

		return dao.selectEmp(e);

	}

	@Override
	public int addEmp(Employee e) {

		if (ValidateDetails.validEid(e) && ValidateDetails.validName(e)
				&& ValidateDetails.validSal(e)) {
			return dao.addEmp(e);
		} else {
			return 0;
		}

	}

}