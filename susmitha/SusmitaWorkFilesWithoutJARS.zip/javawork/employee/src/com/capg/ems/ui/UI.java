package com.capg.ems.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.capg.ems.bean.Employee;
import com.capg.ems.service.EmployeeServiceImp;

public class UI {
	private static Scanner in;
	public static Employee e;
	static EmployeeServiceImp esi = new EmployeeServiceImp();

	public static void main(String[] args) {

		in = new Scanner(System.in);
		e = new Employee();

		System.out.println("Enter The Choice");
		System.out.println("1.Add New Employee");
		System.out.println("2.Select Employee");
		System.out.println("3.Update Employee");
		System.out.println("4.Delete Employee");
		System.out.println("5.Exit");

		int choice = in.nextInt();

		switch (choice) {
		case 1:
			System.out.println("");
			getDetails(e);
			break;
		case 2:

			System.out.println("Enter Employee ID");
			e.setEid(in.nextInt());
			// esi = new EmployeeServiceImp();
			ResultSet rs = esi.selectEmp(e);
			try {
				while (rs.next()) {
					System.out.println(rs.getInt(1) + "    "
							+ rs.getString("fname"));
				}
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			break;
		case 3:
			System.out.println("Enter Employee ID to Update:");

			e.setEid(in.nextInt());
			System.out.println(esi.updateEmp(e) + " Row Updated");
			break;
		case 4:

			System.out.println("Enter Employee ID to Delete Record:");
			e.setEid(in.nextInt());
			int n1 = esi.deleteEmp(e);
			System.out.println(n1 + " Record Deleted");

			break;
		default:
			System.out.println("Not a Valid Input");
			break;
		}

	}

	private static void getDetails(Employee e) {

		System.out.println("Enter Employee ID:");
		e.setEid(in.nextInt());
		System.out.println("Enter First Name:");
		e.setFname(in.next());
		System.out.println("Enter Last Name:");
		e.setLname(in.next());
		System.out.println("Enter Employee Salary:");
		e.setSal(in.nextDouble());

		// esi = new EmployeeServiceImp(); //Object Creation
		int addRes = esi.addEmp(e);

		System.out.println(addRes + " Row Inserted");

	}
}
