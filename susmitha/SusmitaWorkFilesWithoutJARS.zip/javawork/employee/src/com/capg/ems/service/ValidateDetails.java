package com.capg.ems.service;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.ems.bean.Employee;

public class ValidateDetails {
	static Scanner in = new Scanner(System.in);

	public static boolean validName(Employee e) {

		Pattern pattern = Pattern.compile("[A-Z][a-z]{2,}");
		Matcher matcher = pattern.matcher(e.getFname());
		if (matcher.matches()) {
			System.out.println("Name Valid");

		} else {
			enterName(e);
		}
		return true;
	}

	public static boolean validSal(Employee e) {

		return (e.getSal() > 0) ? true : false;

	}

	public static boolean validEid(Employee e) {
		
		return true;
	}

	public static void enterName(Employee e){
		System.out.println("Not a Valid First Name");
		System.out.println("Enter a Valid First Name:");
		e.setFname(in.next());
		ValidateDetails.validName(e);
	}
	public static void enterSal(Employee e){
		System.out.println("Salary Not Valid");
		System.out.println("Enter a Valid Amount:");
		e.setSal(in.nextDouble());
		ValidateDetails.validSal(e);
	}
}
