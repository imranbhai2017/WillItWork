package com.capg.dao.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import com.capg.dao.util.DBUtil;
import com.capg.ems.bean.Employee;


public class EmpDaoImp implements Empdao {

	private ResultSet rs;
	private Connection c;
	private int n;

	@Override
	public int updateEmp(Employee e) {
		try {
			c = DBUtil.getConnection();
			PreparedStatement ps = c.prepareStatement(QueryMapper.UPDATEQ);
			
		/*	
			if(e.getFname().isEmpty()) {
				
			}else {
				ps.setString(1, e.getFname());
			}	*/		

			ps.setString(1, e.getFname());
			ps.setString(2, e.getLname());
			ps.setDouble(3, e.getSal());
			ps.setInt(4, e.getEid());
			
			n = ps.executeUpdate();

		} catch (SQLIntegrityConstraintViolationException se) {
			System.out.println("Updated");
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {
			try {
				c.close();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}

		return n;
	}

	@Override
	public int deleteEmp(Employee e) {
		try {
			c = DBUtil.getConnection();

			PreparedStatement ps = c.prepareStatement(QueryMapper.DELETEQ);

			ps.setInt(1, e.getEid());

			n = ps.executeUpdate();
			System.out.println(e.getEid());
			System.out.println("This is dao delete function");
			// c.setAutoCommit(false); Disabling the Auto Commit
			return n;
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;

	}

	@Override
	public ResultSet selectEmp(Employee e) {
		c = DBUtil.getConnection();
		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.SELECTQ);
			ps.setInt(1, e.getEid());
			rs = ps.executeQuery();
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return rs;
	}

	@Override
	public int addEmp(Employee e) {

		try {

			c = DBUtil.getConnection();

			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERTQ);

			ps.setInt(1, e.getEid());
			ps.setString(2, e.getFname());
			ps.setString(3, e.getLname());
			ps.setDouble(4, e.getSal());

			n = ps.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

		}catch (SQLIntegrityConstraintViolationException se){
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;

	}

}
