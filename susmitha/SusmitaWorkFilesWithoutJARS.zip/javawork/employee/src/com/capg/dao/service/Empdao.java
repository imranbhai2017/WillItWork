package com.capg.dao.service;

import java.sql.ResultSet;

import com.capg.ems.bean.Employee;

public interface Empdao {
	int updateEmp(Employee e);
	int deleteEmp(Employee e);
	ResultSet selectEmp(Employee e);
	int addEmp(Employee e);	
}
