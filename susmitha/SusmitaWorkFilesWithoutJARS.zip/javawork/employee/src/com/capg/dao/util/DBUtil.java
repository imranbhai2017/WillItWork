package com.capg.dao.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil {

	private static FileInputStream fis;
	private static Properties p;
	public static Connection c;

	public static Connection getConnection() {
		try {
			fis = new FileInputStream("jdbc.properties");

			p = new Properties();

			p.load(fis);

			String url = p.getProperty("url");
			String uname = p.getProperty("uname");
			String pass = p.getProperty("pwd");

			c = DriverManager.getConnection(url, uname, pass);

	
		} catch (IOException e) {

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return c;
	}
}
