package com.capg.dao.service;

public interface QueryMapper {
	public static final String INSERTQ = "INSERT INTO rec values(?,?,?,?)";
	public static final String UPDATEQ = "UPDATE rec SET fname=?,lname=?,sal=? WHERE eid = ?";
	public static final String DELETEQ = "DELETE FROM rec WHERE eid = ?";
	public static final String SELECTQ = "SELECT * FROM rec where eid = ?";
}
