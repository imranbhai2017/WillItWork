package com.capg.cms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capg.cms.bean.Customer;


@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao {

	@PersistenceContext
	EntityManager entity;
	
	@Override
	public List<Customer> retriveAll() {
		TypedQuery<Customer> query = entity.createQuery(
				"select c from Customer c", Customer.class);
		return query.getResultList();
	}

	@Override
	public Customer retriveCustomer(int customerId) {
		Customer customer = entity.find(Customer.class, customerId);
		return customer;
		
	}

	@Override
	public void updateCustomerPack(Customer customer) {
		entity.merge(customer);
	}

	@Override
	public void updateCustomer(Customer customer) {
		
		entity.merge(customer);

			
		
	}


}
