package com.capg.cms.service;

import java.util.List;

import com.capg.cms.bean.Customer;

public interface ICustomerService {
	public List<Customer> retriveAll();
	
	public Customer retriveCustomer(int customerId);
	
	public void updateCustomerPack(Customer customer);
	public void updateCustomer(Customer customer);
}
