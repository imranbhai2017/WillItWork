package com.capg.cms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.cms.bean.Customer;
import com.capg.cms.exception.CustomerException;
import com.capg.cms.service.ICustomerService;


@Controller
public class CustomerController {

	@Autowired
	ICustomerService service;
	
	
	@RequestMapping("/home")
	public String showFirstPage(){
	
		return "index";
	}
	

	@RequestMapping("/customerDetails")
	public ModelAndView showFDetails() throws CustomerException{
		
		List<Customer> list = service.retriveAll();
	
		ModelAndView mv = new ModelAndView();
		mv.addObject("list", list);
		mv.setViewName("result");
		return mv;
		
	}
	
	@RequestMapping("/customer")
	public ModelAndView showCustomerPage(@RequestParam("customerId") int customerId) throws CustomerException{
	    
		
		Customer customer = service.retriveCustomer(customerId);
		if(customer.getOptionalPack()==null){
			customer.setOptionalPack("none");
			service.updateCustomerPack(customer);
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("customer", customer);
		mv.setViewName("customerinfo");
		return mv;

	}
	@RequestMapping("/updateDetails")
	public String gotoUpdate(){
		return "update";
	}
	
	@RequestMapping("/updatedone")
	public String update(Customer customer,Model model) throws CustomerException{
		try{
			service.updateCustomer(customer);
		}catch(DataAccessException dataAccessException){
		model.addAttribute("msg","so technical issue :update not possible");
		return "MyError";
		}
		return "redirect:/customerDetails.obj";
	}
}
