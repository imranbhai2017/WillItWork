package com.capg.cms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer1")
public class Customer {
	@Id
	@Column(name="customer_id")
	private int customerId;
	@Column(name="base_pack")
	private String basePack;
	@Column(name="optional_pack")
	private String optionalPack;

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getBasePack() {
		return basePack;
	}

	public void setBasePack(String basePack) {
		this.basePack = basePack;
	}

	public String getOptionalPack() {
		return optionalPack;
	}

	public void setOptionalPack(String optionalPack) {
		this.optionalPack = optionalPack;
	}

}
