package com.capg.lims.service;

import java.util.List;

import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsService {
	User checkUser(String userId);
	List<BooksRegistration> fetchBookRequestByUserId(String userId);
	BooksTransaction fetchBookTransactionByRegistrationId(String registrationId);
	public User changePassword(String userId);
}
