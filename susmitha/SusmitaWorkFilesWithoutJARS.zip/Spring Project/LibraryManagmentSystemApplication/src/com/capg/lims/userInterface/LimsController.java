package com.capg.lims.userInterface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;

@Controller
public class LimsController {

	@Autowired
	ILimsService iLimsService;

	@RequestMapping("/home")
	public String showIndex() {

		return "index";
	}

	@RequestMapping("/StartApplication")
	public String goToLoginPage() {

		return "login";
	}

	@RequestMapping("/openAccount")
	public ModelAndView loginToAccount(@RequestParam("userId") String userId,
			@RequestParam("password") String password) {

		ModelAndView modelAndView = new ModelAndView();
		User user = iLimsService.checkUser(userId);
		System.out.println(user.getUserId() + user.getUserName()
				+ user.getPassword());
		if (user.getUserId().equals(userId)
				&& user.getPassword().equals(password)) {
			if (user.getLibrarian().equals("Y")) {

				modelAndView.addObject("userId", userId);
				modelAndView.setViewName("redirect:/successLibrarian.obj");
			} else {

				modelAndView.addObject("userId", userId);
				modelAndView.setViewName("redirect:/UserHome.obj");
			}
		} else {
			modelAndView.setViewName("redirect:/StartApplication.obj");
		}
		return modelAndView;
	}

	@RequestMapping("/UserHome")
	public ModelAndView successUser(@RequestParam("userId") String userId) {
		System.out.println("++++++++++++++++++" + userId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("userId", userId);
		modelAndView.setViewName("successUser");
		return modelAndView;
	}

	@RequestMapping("/successLibrarian")
	public String successLibrarian() {

		return "successLibrarian";
	}

	@RequestMapping("/requestForBook")
	public String requestForBook() {

		return "page";
	}

	@RequestMapping("/changePassword")
	public String changePassword() {

		return "page";
	}

	@RequestMapping("/checkRequest")
	public ModelAndView checkRequest(@RequestParam("userId") String userId) {

		System.out.println("jhfgdjytdcjmhgcjyhcj");
		System.out.println("********************" + userId);

		List<BooksRegistration> bookRequestList = iLimsService
				.fetchBookRequestByUserId(userId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("bookRequestList", bookRequestList);
		modelAndView.setViewName("userRequestDisplay");

		return modelAndView;

	}

	@RequestMapping("/checkTransaction")
	public ModelAndView checkTransactions(BooksTransaction booksTransaction) {
		String registrationId = booksTransaction.getRegistrationId();
		BooksTransaction bookTransaction = iLimsService
				.fetchBookTransactionByRegistrationId(registrationId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("bookTransaction", bookTransaction);
		modelAndView.setViewName("checkTransaction");

		return modelAndView;

	}

	
}
