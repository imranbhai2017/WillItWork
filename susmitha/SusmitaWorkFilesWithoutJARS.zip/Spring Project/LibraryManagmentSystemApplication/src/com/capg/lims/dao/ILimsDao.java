package com.capg.lims.dao;

import java.util.List;

import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;


public interface ILimsDao {
	User checkUser(String userId);
	List<BooksRegistration> fetchBookRequestByUserId(String userId);
	BooksTransaction fetchBookTransactionByRegistrationId(String registrationId);
	public void changePassword(String userId);
}
