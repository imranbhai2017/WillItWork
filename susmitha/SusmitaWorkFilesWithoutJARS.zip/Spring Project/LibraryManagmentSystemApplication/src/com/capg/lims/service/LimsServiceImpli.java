package com.capg.lims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.dao.ILimsDao;

@Service
public class LimsServiceImpli implements ILimsService {
	@Autowired
	ILimsDao iLimsDao;
	
	@Override
	public User checkUser(String userId) {
		
		return iLimsDao.checkUser(userId);
	}

	@Override
	public List<BooksRegistration> fetchBookRequestByUserId(String userId) {
		// TODO Auto-generated method stub
		return iLimsDao.fetchBookRequestByUserId(userId);
	}

	@Override
	public BooksTransaction fetchBookTransactionByRegistrationId(
			String registrationId) {
		// TODO Auto-generated method stub
		return iLimsDao.fetchBookTransactionByRegistrationId(registrationId);
	}

	@Override
	public User changePassword(String userId) {
		
		return iLimsDao.changePassword(userId);
		
	}

}
