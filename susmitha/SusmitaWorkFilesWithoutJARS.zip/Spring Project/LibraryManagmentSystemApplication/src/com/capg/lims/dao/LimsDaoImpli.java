package com.capg.lims.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

@Repository
@Transactional
public class LimsDaoImpli implements ILimsDao {

	
	@PersistenceContext
	EntityManager entity;

	
	@Override
	public User checkUser(String userId) {
		try{User user = entity.find(User.class, userId);
		System.out.println(user.getPassword());
		System.out.println(user.getUserName());
		System.out.println("********************************************************");
		return user;}catch(NullPointerException exception){
			exception.getStackTrace();
		}
		return null;
	}


	@Override
	public List<BooksRegistration> fetchBookRequestByUserId(String userId) {
		String qStr = "SELECT r FROM BooksRegistration r WHERE r.userId LIKE :userId";
		TypedQuery<BooksRegistration> query = entity.createQuery(qStr, BooksRegistration.class);
		query.setParameter("userId",userId);
		return query.getResultList();
	}


	@Override
	public BooksTransaction fetchBookTransactionByRegistrationId(
			String registrationId) {
		String qStr = "SELECT t FROM BooksTransaction t WHERE t.registrationId LIKE :registrationId";
		TypedQuery<BooksTransaction> query = entity.createQuery(qStr, BooksTransaction.class);
		query.setParameter("registrationId",registrationId);
		return query.getSingleResult();
	}


	@Override
	public User changePassword(String userId) {
		
		User user = entity.find(User.class, userId);
		return user;
		
	}

}
