package com.capg.pms.dao;

import java.util.List;

import com.capg.pms.bean.Product;

public interface IProductDao {

	public List<Product> retriveAll();

	public int deleteProduct(int productId);
	
	public Product addProduct(Product product);
}
