package com.capg.pms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.pms.bean.Product;
import com.capg.pms.dao.IProductDao;

@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductDao dao;

	public List<Product> retriveAll() {

		return dao.retriveAll();
	}

	@Override
	public int deleteProduct(int productId) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productId);
	}

	@Override
	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return dao.addProduct(product);
	}

}
