package com.capg.pms.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Product")
public class Product {
	
	@Id
	@NotNull(message="required")
	//@Min(2)
	private Integer productId;
	@NotEmpty
	@Size(min=3, max=10,message="atlist 3 character")
	private String productName;
	@NotNull
	@Min(2)
	private Integer productPrice;
	@NotNull(message="required")
	@Min(2)
	private Integer productQuantity;
	@NotEmpty
	@Pattern(regexp="[A-Z][a-z]{3}",message="first letter capital [A-Z][a-z]{3}")
	private String productDesc;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Integer productPrice) {
		this.productPrice = productPrice;
	}

	public Integer getProductQuantity() {
		return productQuantity;
	}

	public void setProductQuantity(Integer productQuantity) {
		this.productQuantity = productQuantity;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	

}
