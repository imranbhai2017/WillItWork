package com.capg.sscsa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.sscsa.bean.Client;
import com.capg.sscsa.exception.SkyException;
import com.capg.sscsa.service.ISkyService;

@Controller
public class SkyController {

	@Autowired
	ISkyService iSkyService;
	
	
	/***********************************************************
	 * Method Name: showFirstPage() Return type:String
	 * Parameters:na
	 * Description:This method returns the name
	 * of the view that is to be displayed on the browser.
	 * 
	 * @author Susmita Saha
	 ***********************************************************/
	@RequestMapping("/home")
	public String showFirstPage(){
	
		return "index";
	}
	

	/***********************************************************
	 * Method Name: showFDetails() Return type:ModelAndView
	 * Parameters:na
	 * Description:This method returns the modele object
	 * of the view the details of the customer.
	 * 
	 * @author Susmita Saha
	 ***********************************************************/
	@RequestMapping("/customerDetails")
	public ModelAndView showFDetails() {
		
		List<Client> clientList = iSkyService.retriveAll();
		
		for(int i=0;i<clientList.size();i++){
			if(clientList.get(i).getOptionalPack()==null)
		{
				clientList.get(i).setOptionalPack("None");
				}
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("clientList", clientList);
		mv.setViewName("CustReport");
		return mv;
		
	}
	
	/***********************************************************
	 * Method Name: showCustomerPage() Return type:ModelAndView
	 * Parameters:na
	 * Description:This method returns the modele object
	 * of the view the details of the customer.
	 * 
	 * @author Susmita Saha
	 ***********************************************************/
	
	@RequestMapping("/customer")
	public ModelAndView showCustomerPage(@RequestParam("customerNumber") String customerNumber,Model model)throws SkyException{
	    
		try{
		Client client= iSkyService.retriveCustomer(customerNumber);
		
		if(client.getOptionalPack()==null){
			client.setOptionalPack("none");
		}
		ModelAndView mv = new ModelAndView();
		mv.addObject("client", client);
		mv.setViewName("CustDetail");
		
		return mv;
		}
		catch(Exception exception){
			ModelAndView mv = new ModelAndView();
			
			mv.addObject("msg", "No Customer Found");
			mv.setViewName("myError");
			return mv;
		}
		
	}
	
}
