package com.capg.sscsa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.sscsa.bean.Client;
import com.capg.sscsa.dao.ISkyDao;
import com.capg.sscsa.exception.SkyException;

@Service
public class SkyServiceImpl implements ISkyService {

	
	@Autowired
	ISkyDao iSkyDao;
	@Override
	public List<Client> retriveAll() {
		// TODO Auto-generated method stub
		try {
			return iSkyDao.retriveAll();
		} catch (SkyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Client retriveCustomer(String customerNumber) {
		// TODO Auto-generated method stub
		try {
			return iSkyDao.retriveCustomer(customerNumber);
		} catch (SkyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
}
