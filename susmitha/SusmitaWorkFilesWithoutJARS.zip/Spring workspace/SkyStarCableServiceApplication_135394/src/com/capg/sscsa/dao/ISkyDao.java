package com.capg.sscsa.dao;

import java.util.List;

import com.capg.sscsa.bean.Client;
import com.capg.sscsa.exception.SkyException;

public interface ISkyDao {
	public List<Client> retriveAll()throws SkyException;
	public Client retriveCustomer(String customerNumber) throws SkyException;
	
	
}
