package com.capg.sscsa.service;

import java.util.List;

import com.capg.sscsa.bean.Client;

public interface ISkyService {

	public List<Client> retriveAll();
	public Client retriveCustomer(String customerNumber);
	
}
