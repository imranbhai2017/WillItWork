package com.capg.sscsa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;

import com.capg.sscsa.bean.Client;
import com.capg.sscsa.exception.SkyException;

@Repository
@Transactional
public class SkyDaoImpli implements ISkyDao {

	@PersistenceContext
	EntityManager entity;

	@Override
	public List<Client> retriveAll() {
		TypedQuery<Client> query = entity.createQuery(
				"select c from Client c", Client.class);
		return query.getResultList();
	}

	@Override
	public Client retriveCustomer(String customerNumber) {
		try{Client client = entity.find(Client.class, customerNumber);
		return client;
		}
		catch(DataAccessException dataAccessException){
			dataAccessException.printStackTrace();
		}
		return null;
	}

	
}
