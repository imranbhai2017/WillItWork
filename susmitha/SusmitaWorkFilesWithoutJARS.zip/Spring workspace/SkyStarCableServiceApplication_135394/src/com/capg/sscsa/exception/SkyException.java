package com.capg.sscsa.exception;

public class SkyException extends Exception{

	
	public SkyException()
	{
		
	}
	public SkyException(String msg)
	{
		super(msg);
	}
}
