package com.capg.sscsa.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="SKYCustomers")
public class Client {

	@Id
	@Column(name="CustNum")
	private String customerNumber;
	@Column(name="basePack")
	private String basePack;
	@Column(name="optionalPack")
	private String optionalPack;
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getBasePack() {
		return basePack;
	}
	public void setBasePack(String basePack) {
		this.basePack = basePack;
	}
	public String getOptionalPack() {
		return optionalPack;
	}
	public void setOptionalPack(String optionalPack) {
		
		this.optionalPack = optionalPack;
		
	}
	

}
