package com.capg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {
	@RequestMapping("/show")
	public ModelAndView showForm()
	{
		System.out.println("hi");
		
		return new ModelAndView("Login");
		
	}
	@RequestMapping("/display")
	public ModelAndView display(@RequestParam("uname") String uname,@RequestParam("pwd") String pwd)
	{
		
		
		if(uname.equals("cg") && pwd.equals("qw")){
			Login l = new Login();
			l.setUname(uname);
			l.setPwd(pwd);
			System.out.println(l.getUname()+"     "+l.getPwd());
			return new ModelAndView("sucesss");
		}
		else{
			return new ModelAndView("error");
		}
		
	}
}
