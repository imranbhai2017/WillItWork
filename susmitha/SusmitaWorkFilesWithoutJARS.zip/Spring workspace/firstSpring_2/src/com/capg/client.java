package com.capg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



public class client {

	public static void main(String[] args) {
		/*Resource res = new ClassPathResource("ApplicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(res);*/
		
		ApplicationContext cxt = new ClassPathXmlApplicationContext("ApplicationContext.xml");
		Employee e =(Employee) cxt.getBean("id1");
		e.display();
		
	}

}
