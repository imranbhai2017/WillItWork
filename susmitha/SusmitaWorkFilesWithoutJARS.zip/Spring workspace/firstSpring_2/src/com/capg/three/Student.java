package com.capg.three;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Student implements InitializingBean, DisposableBean {
	private int stuId;
	private String studName;
	public int getStuId() {
		return stuId;
	}
	public void setStuId(int stuId) {
		this.stuId = stuId;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	/*public void init(){
		System.out.println("init");
	}

	public void destroy(){
		System.out.println("destroy");
	}*/
	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("initialized");
		
	}
	@Override
	public void destroy() throws Exception {
		System.out.println("destroied");
		
	}

}
