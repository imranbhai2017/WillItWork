package com.capg.three;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
public static void main(String[] args) {
	AbstractApplicationContext con = new ClassPathXmlApplicationContext("Context3.xml");
	
	Student s = con.getBean("id1",Student.class);
	con.registerShutdownHook();
	
	
	System.out.println(s.getStuId());
	System.out.println(s.getStudName());
	}
}
