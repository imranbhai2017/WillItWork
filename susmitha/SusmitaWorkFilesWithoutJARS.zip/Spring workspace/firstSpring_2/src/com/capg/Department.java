package com.capg;

public class Department {
	private int deptid;

	@Override
	public String toString() {
		return "Department [deptid=" + deptid + "]";
	}

	public int getDeptid() {
		return deptid;
	}

	public void setDeptid(int deptid) {
		this.deptid = deptid;
	}

}
