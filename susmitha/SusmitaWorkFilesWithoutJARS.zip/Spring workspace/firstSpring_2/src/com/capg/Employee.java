package com.capg;

import org.springframework.beans.factory.annotation.Autowired;

public class Employee {
	private String eid;
	
	
	@Autowired
	public Employee(String eid, Department dept) {
		super();
		this.eid = eid;
		this.dept = dept;
	}

	private Department dept;

	public String getEid() {
		return eid;
	}

	public void setEid(String eid) {
		this.eid = eid;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}
	
	public void display(){
		System.out.println(eid);
		System.out.println(dept);
	}

}
