package com.capg.basePack;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class beanA {

	private beanB beanB;
	private beanC beanC;
	
	
	public  beanA() {
		System.out.println(" creating bean BeanA");
	}


	public beanB getBeanB() {
		return beanB;
	}

@Autowired
	public void setBeanB(beanB beanB) {
		beanB.B();
	}


	public beanC getBeanC() {
		return beanC;
	}

@Autowired
	public void setBeanC(beanC beanC) {
		beanC.C();
	}
	
	
	
}
