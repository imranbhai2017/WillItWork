package com.capg.basePack;

import org.springframework.stereotype.Component;

@Component
public class beanB {
public void B(){
	
	System.out.println("beanB");
}
}
