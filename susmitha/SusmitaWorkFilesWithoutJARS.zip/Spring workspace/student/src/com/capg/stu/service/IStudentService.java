package com.capg.stu.service;

import java.util.List;

import com.capg.stu.bean.Student;

public interface IStudentService {

	public List<Student> getAllStudent();

	public int deleteStudent(int studentId);
}
