package com.capg.stu.dao;

import java.util.List;

import com.capg.stu.bean.Student;

public interface IStudentDao {

	
	 public List<Student> getAllStudent();
	 
	public int deleteStudent(int studentId);
	
}
