package com.capg.stu.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;



import com.capg.stu.bean.Student;
import com.capg.stu.service.IStudentService;

@Controller
public class StudentController {

	@Autowired
	IStudentService ser;
	
	@RequestMapping("/home")
	public ModelAndView show() {
		List<Student> list = ser.getAllStudent();
		ModelAndView mv = new ModelAndView();
		mv.addObject("list", list);
		mv.setViewName("index");
		return mv;
	}

	@RequestMapping("/deleteStudent")
	public String delete(@RequestParam("studentId") int studentId) {
		int status = ser.deleteStudent(studentId);
		return "redirect:/home.obj";
	}
	
	@RequestMapping("/addNewProduct")
	public String addProduct(){
		
		return "new";
	}
}
