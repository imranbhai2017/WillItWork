package com.capg.epm;

public class Department  implements BeanPostProcessor{

}
