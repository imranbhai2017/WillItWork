package com.capg.lims.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.dao.ILimsDao;

@Service
public class LimsServiceImpli implements ILimsService {
	@Autowired
	ILimsDao iLimsDao;

	@Override
	public User checkUser(String userId) {

		return iLimsDao.checkUser(userId);
	}

	@Override
	public List<BooksRegistration> fetchBookRequestByUserId(String userId) {

		return iLimsDao.fetchBookRequestByUserId(userId);
	}

	@Override
	public BooksTransaction fetchBookTransactionByRegistrationId(
			String registrationId) {

		return iLimsDao.fetchBookTransactionByRegistrationId(registrationId);
	}

	@Override
	public void changePassword(User user) {

		iLimsDao.changePassword(user);

	}

	@Override
	public User addUser(User user) {

		return iLimsDao.addUser(user);
	}

	@Override
	public BooksRegistration issueBook(BooksRegistration booksRegistration) {

		return iLimsDao.issueBook(booksRegistration);
	}


	/************************************************************************************
	 * File:       ILimsService.java
	 * Package:     com.capg.lims.service
	 * Desc:        Service class for Library Management system
	 * Version:     1.0
	 * Modifications:
	  * Author:            Date:          Change Description:
	 * Susmita Saha     09-10-2017        Initial Version
	 ************************************************************************************/
	@Override
	public BooksInventory insertBook(BooksInventory bookInventory) {
		return iLimsDao.insertBook(bookInventory);
	}

	@Override
	public List<BooksInventory> fetchBooks() {

		return iLimsDao.fetchBooks();
	}

	@Override
	public int deleteBook(String bookId) {

		return iLimsDao.deleteBook(bookId);
	}

	@Override
	public int UpdateBook(BooksInventory booksInventory) {

		iLimsDao.UpdateBook(booksInventory);
		return 1;
	}

	@Override
	public BooksInventory fetchSingleBook(String bookId) {

		return iLimsDao.fetchSingleBook(bookId);
	}

	@Override
	public List<BooksRegistration> fetchBooksRequest() {

		return iLimsDao.fetchBooksRequest();
	}

	@Override
	public BooksTransaction addTransaction(BooksTransaction booksTransaction,
			String registrationId, String bookId) {

		return iLimsDao
				.addTransaction(booksTransaction, registrationId, bookId);
	}

	@Override
	public List<BooksTransaction> fetchBookTransaction() {

		return iLimsDao.fetchBookTransaction();
	}

	@Override
	public int UpdateTransaction(String transactionId, String registrationId) {

		return iLimsDao.UpdateTransaction(transactionId, registrationId);
	}

	@Override
	public List<BooksTransaction> fetchReturnTransaction() {
		
		return iLimsDao.fetchReturnTransaction();
	}

	@Override
	public List<BooksRegistration> fetchAllBooksRequest() {
		// TODO Auto-generated method stub
		return iLimsDao.fetchAllBooksRequest();
	}

}
