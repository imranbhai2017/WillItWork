package com.capg.lims.service;

import java.util.List;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsService {
	User checkUser(String userId);

	List<BooksRegistration> fetchBookRequestByUserId(String userId);

	BooksTransaction fetchBookTransactionByRegistrationId(String registrationId);

	public void changePassword(User user);

	public User addUser(User user);

	public BooksRegistration issueBook(BooksRegistration booksRegistration);

	/************************************************************************************
	 * File:       ILimsService.java
	 * Package:     com.capg.lims.service
	 * Desc:        Service class for Library Management system
	 * Version:     1.0
	 * Modifications:
	  * Author:            Date:          Change Description:
	 * Susmita Saha     09-10-2017        Initial Version
	 ************************************************************************************/
	public BooksInventory insertBook(BooksInventory bookInventory);

	List<BooksInventory> fetchBooks();

	public int deleteBook(String bookId);

	public int UpdateBook(BooksInventory booksInventory);

	public BooksInventory fetchSingleBook(String bookId);

	List<BooksRegistration> fetchBooksRequest();
	
	List<BooksRegistration> fetchAllBooksRequest();

	public BooksTransaction addTransaction(BooksTransaction booksTransaction,
			String registrationId, String bookId);

	List<BooksTransaction> fetchBookTransaction();

	public int UpdateTransaction(String transactionId, String registrationId);
	public List<BooksTransaction> fetchReturnTransaction();
}
