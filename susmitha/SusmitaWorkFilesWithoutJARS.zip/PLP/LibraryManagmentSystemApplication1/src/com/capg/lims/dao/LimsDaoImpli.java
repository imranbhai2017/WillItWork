package com.capg.lims.dao;

import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

@Repository
@Transactional
public class LimsDaoImpli implements ILimsDao {

	@PersistenceContext
	EntityManager entity;

	@Override
	public User checkUser(String userId) {
		User user = new User();
		try {
			user = entity.find(User.class, userId);
			System.out.println(user.getPassword());
			System.out.println(user.getUserName());
			System.out
					.println("********************************************************");
		} catch (Exception exception) {
			System.err.println("Null pointer exception"
					+ exception.getMessage());
		}
		return user;
	}

	@Override
	public List<BooksRegistration> fetchBookRequestByUserId(String userId) {
		String qStr = "SELECT r FROM BooksRegistration r WHERE r.userId LIKE :userId";
		TypedQuery<BooksRegistration> query = entity.createQuery(qStr,
				BooksRegistration.class);
		query.setParameter("userId", userId);
		return query.getResultList();
	}

	@Override
	public BooksTransaction fetchBookTransactionByRegistrationId(
			String registrationId) {
		String qStr = "SELECT t FROM BooksTransaction t WHERE t.registrationId LIKE :registrationId";
		TypedQuery<BooksTransaction> query = entity.createQuery(qStr,
				BooksTransaction.class);
		query.setParameter("registrationId", registrationId);
		return query.getSingleResult();
	}

	@Override
	public User addUser(User user) {

		Query query = entity
				.createNativeQuery("select user_seq.nextval from dual");
		BigDecimal id = (BigDecimal) query.getSingleResult();
		String userId = "U" + id;
		user.setUserId(userId);

		entity.persist(user);
		entity.flush();
		return user;
	}

	@Override
	public BooksRegistration issueBook(BooksRegistration booksRegistration) {

		try{Query query = entity
				.createNativeQuery("select regi_seq.nextval from dual");
		BigDecimal id = (BigDecimal) query.getSingleResult();
		String registrationId = "R" + id;
		booksRegistration.setRegistrationId(registrationId);
		entity.persist(booksRegistration);
		entity.flush();}
		catch(Exception exception){
			System.err.println("Null pointer exception"
					+ exception.getMessage());
		}
		return booksRegistration;

	}

	@Override
	public BooksInventory insertBook(BooksInventory bookInventory) {
		Query query = entity
				.createNativeQuery("select book_seq.nextval from dual");
		BigDecimal id = (BigDecimal) query.getSingleResult();
		String bookId = "B" + id;
		bookInventory.setBookId(bookId);
		entity.persist(bookInventory);
		entity.flush();

		return bookInventory;

	}

	@Override
	public List<BooksInventory> fetchBooks() {

		TypedQuery<BooksInventory> query = entity.createQuery(
				"select bi from BooksInventory bi", BooksInventory.class);
		return query.getResultList();
	}

	@Override
	public int deleteBook(String bookId) {
		BooksInventory booksInventory = entity.find(BooksInventory.class,
				bookId);
		entity.remove(booksInventory);

		return 1;
	}

	@Override
	public int UpdateBook(BooksInventory booksInventory) {
		entity.persist(booksInventory);
		return 1;
	}

	@Override
	public void changePassword(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public BooksInventory fetchSingleBook(String bookId) {
		BooksInventory booksInventory = entity.find(BooksInventory.class,
				bookId);
		return booksInventory;
	}

	@Override
	public List<BooksRegistration> fetchBooksRequest() {
		// TODO Auto-generated method stub
		TypedQuery<BooksRegistration> query = entity.createQuery(
				"select br from BooksRegistration br", BooksRegistration.class);
		return query.getResultList();
	}

	@Override
	public BooksTransaction addTransaction(BooksTransaction booksTransaction,
			String registrationId, String bookId) {
		Query query = entity
				.createNativeQuery("select tran_seq.nextval from dual");
		BigDecimal id = (BigDecimal) query.getSingleResult();
		String transactionId = "T" + id;

		booksTransaction.setTransactionId(transactionId);

		Date issueDate = java.sql.Date.valueOf(LocalDate.now());
		Date returnDate = java.sql.Date.valueOf(LocalDate.now().plusDays(14));
		booksTransaction.setIssueDate(issueDate);
		booksTransaction.setReturnDate(returnDate);
		booksTransaction.setActualReturnDate(returnDate);
		booksTransaction.setFine(0);
		booksTransaction.setStatus("N");
		entity.persist(booksTransaction);
		entity.flush();

		BooksRegistration booksRegistration = entity.find(
				BooksRegistration.class, registrationId);
		booksRegistration.setStatus("Y");
		entity.persist(booksRegistration);

		BooksInventory booksInventory = entity.find(BooksInventory.class,
				bookId);
		booksInventory.setAvailability("not available");
		entity.persist(booksInventory);

		return booksTransaction;
	}

	@Override
	public List<BooksTransaction> fetchBookTransaction() {
		TypedQuery<BooksTransaction> query = entity.createQuery(
				"select bt from BooksTransaction bt", BooksTransaction.class);
		return query.getResultList();
	}

	@Override
	public int UpdateTransaction(String transactionId,String registrationId) {
		BooksTransaction booksTransaction = entity.find(BooksTransaction.class,
				transactionId);
		booksTransaction.setStatus("Y");
		Date actualReturnDate = java.sql.Date.valueOf(LocalDate.now());
		booksTransaction.setActualReturnDate(actualReturnDate);

		Date expectedReturnDate = booksTransaction.getReturnDate();
		double fine = ChronoUnit.DAYS.between(expectedReturnDate.toLocalDate(),
				actualReturnDate.toLocalDate());
		if (fine <= 0) {
			// CHECK PLESE
			booksTransaction.setFine(0);
		} else {
			booksTransaction.setFine(fine);
		}
		entity.persist(booksTransaction);
		
		BooksRegistration booksRegistration = entity.find(BooksRegistration.class,
				registrationId);
		
		String bookId = booksRegistration.getBookId();
		
		BooksInventory booksInventory = entity.find(BooksInventory.class,
				bookId);
		booksInventory.setAvailability("available");
		entity.persist(booksInventory);
		
		
		return 1;
	}

}
