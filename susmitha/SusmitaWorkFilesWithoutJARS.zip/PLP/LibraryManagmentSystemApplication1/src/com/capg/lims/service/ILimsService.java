package com.capg.lims.service;

import java.util.List;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsService {
	User checkUser(String userId);
	
	List<BooksRegistration> fetchBookRequestByUserId(String userId);
	
	BooksTransaction fetchBookTransactionByRegistrationId(String registrationId);
	public void changePassword(User user);
	public User addUser(User user);
	public BooksRegistration issueBook(BooksRegistration booksRegistration);
	public BooksInventory insertBook(BooksInventory bookInventory);
	List<BooksInventory> fetchBooks();
	public int deleteBook(String bookId);
	public int UpdateBook(BooksInventory booksInventory);
	public BooksInventory fetchSingleBook(String bookId);
	List<BooksRegistration> fetchBooksRequest();
	public BooksTransaction addTransaction(BooksTransaction booksTransaction,String registrationId,String bookId);
	List<BooksTransaction> fetchBookTransaction();

	public int UpdateTransaction(String transactionId,String registrationId);
}
