package com.capg.lims.userInterface;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;

@Controller
public class UserController {

	@Autowired
	ILimsService iLimsService;

	@RequestMapping("/requestBook")
	public ModelAndView insertBookRequest(@RequestParam("userId") String userId,@RequestParam("userName") String userName,BooksRegistration booksRegistration) {
		booksRegistration.setStatus("N");
		ModelAndView modelAndView = new ModelAndView();
		try{iLimsService.issueBook(booksRegistration);
		
		modelAndView.addObject("userName", userName);
		modelAndView.addObject("userId", userId);
		modelAndView.setViewName("redirect:/UserHome.obj");
		}catch(Exception exception){
			exception.printStackTrace();
			modelAndView.addObject("userName", userName);
			modelAndView.addObject("userId", userId);
			modelAndView.addObject("error", "Book does not exist !!");
			modelAndView.setViewName("BookRequestError");
		}
		return modelAndView;
	}

	@RequestMapping("/checkRequest")
	public ModelAndView checkRequest(@RequestParam("userId") String userId,@RequestParam("userName") String userName) {
		System.out.println("********************" + userId);

		List<BooksRegistration> bookRequestList = iLimsService
				.fetchBookRequestByUserId(userId);
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("bookRequestList", bookRequestList);
		modelAndView.addObject("userName", userName);
		
		modelAndView.setViewName("userRequestDisplay");

		return modelAndView;

	}

	@RequestMapping("/checkTransaction")
	public ModelAndView checkTransactions(BooksTransaction booksTransaction,@RequestParam("uid") String uid,@RequestParam("userName") String userName) {
		System.out.println(uid);
		ModelAndView modelAndView = new ModelAndView();
		try{String registrationId = booksTransaction.getRegistrationId();
		BooksTransaction bookTransaction = iLimsService
				.fetchBookTransactionByRegistrationId(registrationId);
		
		
		modelAndView.addObject("bookTransaction", bookTransaction);
		modelAndView.addObject("uid",uid);
		modelAndView.addObject("userName",userName);
		modelAndView.setViewName("checkTransaction");
		}
		catch(Exception exception){
			exception.printStackTrace();
			modelAndView.addObject("uid",uid);
			modelAndView.addObject("userName",userName);
			modelAndView.addObject("error", "no record found");
			modelAndView.setViewName("transactionError");
		}
		return modelAndView;

	}

	@RequestMapping("/passwordChanged")
	public ModelAndView updatePassword(@RequestParam("userId") String userId,User user,HttpServletRequest request,@RequestParam("userName") String userName) {
		ModelAndView modelAndView = new ModelAndView();
		
		System.out.println("user name cp:"+userName);
		System.out.println("00000000000000000"+ "  "+user.getPassword());
		String pwd = user.getPassword();
		String pwd1= request.getParameter("password1");
		System.out.println("oooooooooooooooooooooooooooooo"+ pwd1);
		
		user = iLimsService.checkUser(userId);
		user.setPassword(pwd);
		
		iLimsService.changePassword(user);
		modelAndView.addObject("userId",userId);
		modelAndView.addObject("userName",userName);
		modelAndView.setViewName("redirect:/UserHome.obj");
		
		return modelAndView;

	}
	
	
	

}
