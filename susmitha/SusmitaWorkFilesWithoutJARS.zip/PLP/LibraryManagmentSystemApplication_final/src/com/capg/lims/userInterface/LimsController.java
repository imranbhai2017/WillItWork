package com.capg.lims.userInterface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;

@Controller
public class LimsController {

	@Autowired
	ILimsService iLimsService;

	@RequestMapping("/home")
	public String showIndex() {

		return "index";

	}

	@RequestMapping("/StartApplication")
	public String goToLoginPage() {

		return "login";
	}

	@RequestMapping("/openAccount")
	public ModelAndView loginToAccount(@RequestParam("userId") String userId,
			@RequestParam("password") String password) {

		ModelAndView modelAndView = new ModelAndView();
		User user = iLimsService.checkUser(userId);
		try {
			System.out.println(user.getUserId() + " " + user.getUserName()
					+ user.getPassword() + " " + password);

			if (user.getUserId().equals(userId)
					&& user.getPassword().equals(password)) {
				if (user.getLibrarian().equals("Y")) {
					modelAndView.addObject("userName", user.getUserName());
					modelAndView.addObject("userId", userId);
					modelAndView.setViewName("redirect:/successLibrarian.obj");
				} else {

					modelAndView.addObject("userName", user.getUserName());
					modelAndView.addObject("userId", userId);
					modelAndView.setViewName("redirect:/UserHome.obj");
				}
			} else {
				modelAndView.setViewName("login");
			}
		} catch (Exception exception) {
			exception.printStackTrace();
			modelAndView.addObject("error", "Invalid user credientials....!");
			modelAndView.setViewName("error");

		}
		return modelAndView;
	}

	@RequestMapping("/UserHome")
	public ModelAndView successUser(@RequestParam("userId") String userId,
			@RequestParam("userName") String userName) {
		List<BooksInventory> booksList = iLimsService.fetchBooks();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("userId", userId);
		modelAndView.addObject("userName", userName);
		modelAndView.addObject("booksList", booksList);
		modelAndView.setViewName("successUser");
		return modelAndView;
	}

	@RequestMapping("/successLibrarian")
	public ModelAndView successLibrarian(@RequestParam("userId") String userId,
			@RequestParam("userName") String userName) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("userId", userId);
		modelAndView.addObject("userName", userName);
		modelAndView.setViewName("successLibrarian");
		return modelAndView;

	}

	@RequestMapping("/requestForBook")
	public String requestForBook() {

		return "page";
	}

	@RequestMapping("/changePassword")
	public ModelAndView changePassword(@RequestParam("userId") String userId,
			@RequestParam("userName") String userName) {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("userId", userId);
		modelAndView.addObject("userName", userName);
		modelAndView.setViewName("InsertPassword");
		return modelAndView;
	}

	@RequestMapping("/addUser")
	public String addUser() {

		return "NewUser";

	}

	@RequestMapping("/addBook")
	public String addBook() {

		return "addBook";
	}

	@RequestMapping("/RequestBook")
	public ModelAndView addBookRequest(@RequestParam("userId") String userId,
			@RequestParam("userName") String userName) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("userId", userId);
		modelAndView.addObject("userName", userName);
		modelAndView.setViewName("IssueBook");
		return modelAndView;

	}

	@RequestMapping("/updateBook")
	public ModelAndView updateBook(@RequestParam("bookId") String bookId) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("bookId", bookId);
		modelAndView.setViewName("updateBook");
		return modelAndView;

	}

	@RequestMapping("/isshuBook")
	public ModelAndView checkBookRequest() {

		List<BooksRegistration> requestList = iLimsService.fetchBooksRequest();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("requestList", requestList);
		modelAndView.setViewName("CheckBooksRequest");
		return modelAndView;
	}

	
	@RequestMapping("/returnBook")
	public ModelAndView returnBook() {

		List<BooksTransaction> BooksTransactionList = iLimsService
				.fetchBookTransaction();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("BooksTransactionList", BooksTransactionList);
		modelAndView.setViewName("returnBook");
		return modelAndView;
	}

	
}
