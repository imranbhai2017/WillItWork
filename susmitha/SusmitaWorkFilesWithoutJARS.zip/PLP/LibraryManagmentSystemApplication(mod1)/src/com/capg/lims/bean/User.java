package com.capg.lims.bean;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

@Entity
@Table(name = "users")
public class User {
	@Id
	/*@SequenceGenerator(name="seq1",sequenceName="user_SEQ",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1") */
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "USER_NAME")
	private String userName;
	@Column(name = "PASSWORD")
	private String password;
	@Column(name = "EMAIL")
	@Pattern(regexp = "[A-Z a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}", message = "enter a valid email id")
	private String emailId;
	@Column(name = "LIBRARIAN")
	private String librarian;
	@Column(name = "CREATION_DATE")
	private LocalDate creationDate;
	@Column(name = "CREATED_BY")
	private String createdBy;

	public LocalDate getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(LocalDate creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getLibrarian() {
		return librarian;
	}

	public void setLibrarian(String librarian) {
		this.librarian = librarian;
	}

}
