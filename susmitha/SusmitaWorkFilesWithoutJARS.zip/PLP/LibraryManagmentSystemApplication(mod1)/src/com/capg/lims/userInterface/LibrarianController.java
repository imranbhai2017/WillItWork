package com.capg.lims.userInterface;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;


@Controller
public class LibrarianController {
	
	
	@Autowired
	ILimsService iLimsService;

	@RequestMapping("/saveUser")
	public String insertUser(User user) {

		iLimsService.addUser(user);
		return "page";
	}

	@RequestMapping("/BookUpdated")
	public String updateBook(@RequestParam("bookId") String bookId,
			@RequestParam("bookName") String bookName,
			@RequestParam("authorOne") String authorOne,
			@RequestParam("authorTwo") String authorTwo,
			@RequestParam("publisher") String publisher,
			@RequestParam("yearOfPublication") String yearOfPublication,
			BooksInventory booksInventory) {
		booksInventory = iLimsService.fetchSingleBook(bookId);
		booksInventory.setBookName(bookName);
		booksInventory.setAuthorOne(authorOne);
		booksInventory.setAuthorTwo(authorTwo);
		booksInventory.setPublisher(publisher);
		booksInventory.setYearOfPublication(yearOfPublication);
		iLimsService.UpdateBook(booksInventory);
		return "redirect:/booklist.obj";
	}

	
	
	@RequestMapping("/deleteBook")
	public String deleteBook(@RequestParam("bookId") String bookId) {
		iLimsService.deleteBook(bookId);
		return "redirect:/booklist.obj";
	}
	
	
	@RequestMapping("/booklist")
	public ModelAndView fetchBook() {

		List<BooksInventory> booksList = iLimsService.fetchBooks();
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("booksList", booksList);
		modelAndView.setViewName("DisplayBookList");
		return modelAndView;
	}
	

	@RequestMapping("/bookAdded")
	public String add(BooksInventory bookInventory) {
		iLimsService.insertBook(bookInventory);
		return "page";

	}

}
