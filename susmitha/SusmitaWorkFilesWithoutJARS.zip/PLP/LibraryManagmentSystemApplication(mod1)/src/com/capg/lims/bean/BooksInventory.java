package com.capg.lims.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name = "BOOKS_INVENTORY")
public class BooksInventory {

	@Id
	/*@SequenceGenerator(name="seq1",sequenceName="book_SEQ",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="seq1")*/
	@Column(name = "BOOK_ID")
	private String bookId;
	@Column(name = "BOOK_NAME")
	private String bookName;
	@Column(name = "AUTHOR1")
	private String authorOne;
	@Column(name = "AUTHOR2")
	private String authorTwo;
	@Column(name = "PUBLISHER")
	private String publisher;
	@Column(name = "YEAROFPUBLICATION")
	private String yearOfPublication;
	@Column(name = "AVAILABILITY")
	private String availability;
	public String getBookId() {
		return bookId;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorOne() {
		return authorOne;
	}
	public void setAuthorOne(String authorOne) {
		this.authorOne = authorOne;
	}
	public String getAuthorTwo() {
		return authorTwo;
	}
	public void setAuthorTwo(String authorTwo) {
		this.authorTwo = authorTwo;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getYearOfPublication() {
		return yearOfPublication;
	}
	public void setYearOfPublication(String yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}
	
	
}
