package com.capg.lims.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsDao {

	// for librarian
	ArrayList<BooksInventory> selectBook();

	int addBook(BooksInventory BooksInventory);

	int issueBook(BooksTransaction BooksTransaction) throws LibraryException;

	int updateBookDetails(BooksInventory booksInventory);

	void deleteBook(String bookId);

	int addUsers(User user) throws LibraryException;

	ResultSet checkUser(String userName);

	int updatetransactionDetails(BooksTransaction BooksTransaction);

	ResultSet selectTransactionDate(String regid) throws LibraryException;

	// for student

	ArrayList<BooksRegistration> selectBooks();

	int addRegistration(BooksRegistration BooksRegistration) throws LibraryException;

	ArrayList<BooksTransaction> selecttransac();

	int updatePassword(User User);

	ArrayList<BooksRegistration> selectRegistration(String uid);

	ArrayList<BooksTransaction> selectTransactionForStudent(String rid);
}
