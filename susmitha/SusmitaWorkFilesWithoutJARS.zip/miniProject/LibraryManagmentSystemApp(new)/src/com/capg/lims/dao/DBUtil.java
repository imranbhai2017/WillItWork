package com.capg.lims.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capg.lims.Exception.LibraryException;

public class DBUtil {
	static Logger log = Logger.getRootLogger();
	private static FileInputStream fis;
	private static Properties p;
	public static Connection c;

	public static Connection getConnection() throws LibraryException {
		try {
			log.info("Connecting to DB.......");
			fis = new FileInputStream("resource/jdbc.properties");

			p = new Properties();

			p.load(fis);

			String url = p.getProperty("url");
			String uname = p.getProperty("uname");
			String pass = p.getProperty("pwd");

			c = DriverManager.getConnection(url, uname, pass);
			log.info("Connected to Database");
		} catch (IOException e) {

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new LibraryException("connection not done" + e.getMessage());
			// e.printStackTrace();
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new LibraryException("connection not done"
						+ e.getMessage());
				// e.printStackTrace();
			}
		}
		return c;
	}
}
