package com.capg.lims.test;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Test;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.dao.LimsDaoImpl;
public class LimsDaoImplTest {
	LimsDaoImpl ldi = new LimsDaoImpl();

	@Test
	public void SelectBooktest(){
		
		//ldi.selectBook();
		ArrayList<BooksInventory> blist= ldi.selectBook();
		if(blist.isEmpty()){
			assertEquals(1,0);
		}
		else{
			assertEquals(1,1);
		}
	}
	
	
	
	@Test
	public void updateBookDetailsTest(){
		BooksInventory b = new BooksInventory();
		b.setBookName("java");
		b.setAuthorOne("roy");
		b.setAuthorTwo("das");
		b.setPublisher("jain");
		b.setYearOfPublication("31may,98");
		b.setBookId("B102");
		int n = ldi.updateBookDetails(b);
		assertEquals(1,n);
	
	}
	
	
	@Test
	public void checkUserTest(){
		
		String uname= "susmita";
		assertNotNull(ldi.checkUser(uname));
		
		
	}
	
	
	
	@Test
	public void updatetransactionDetails(){
		BooksTransaction b= new BooksTransaction();
		b.setRegistrationId("R141");
		b.setFine(10.0);
		int n = ldi.updatetransactionDetails(b);
		assertEquals(1,n);
	}
	
	
	
	@Test
	public void selectTransactionDate() throws SQLException, LibraryException{
		LimsDaoImpl i = new LimsDaoImpl();
		;
		String regid= "R141";
		ResultSet rs =i.selectTransactionDate(regid);
		try {
			assertTrue(rs.next());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	@Test
	public void selectBooksTest(){
		ArrayList<BooksRegistration> brlist = ldi.selectBooks();
		
		if(brlist.isEmpty()){
			assertEquals(1,0);
		}
		else{
			assertEquals(1,1);
		}
	
	}
	
	
	@Test
	public void selecttransacTest(){
		ArrayList<BooksTransaction> tlist =ldi.selecttransac();
		if(tlist.isEmpty()){
			assertEquals(1,0);
		}
		else{
			assertEquals(1,1);
		}
	}


	@Test
	public void updatePasswordTest(){
		User  u = new User();
	
		u.setUserId("U100");
		u.setPassword("234");
		int n = ldi.updatePassword(u);
		assertEquals(1,n);
		
		
		
	}


	@Test
	public void selectRegistrationTest(){
		
		
		ArrayList<BooksRegistration> blist = ldi.selectRegistration("U104");
		if(blist.isEmpty()){
			assertEquals(1,0);
		}
		else{
			assertEquals(1,1);
		}
	}

	
	

	@Test
	public void selectTransactionForStudent(){
		
		String rid = "R104";
		ArrayList<BooksTransaction> blist = ldi.selectTransactionForStudent(rid);
		if(blist.isEmpty()){
			assertEquals(1,0);
		}
		else{
			assertEquals(1,1);
		}
	}
	
	
	@Test
	public void addBook() {
		BooksInventory BooksInventory = new BooksInventory();
		
		BooksInventory.setBookName("Civics");
		BooksInventory.setAuthorOne("Mari");
		BooksInventory.setAuthorTwo("Don");
		BooksInventory.setPublisher("SImbu");
		BooksInventory.setYearOfPublication("2014");
		BooksInventory.setAvailability("Y");
		int n = ldi.addBook(BooksInventory);
		System.out.println(n+"Row inserted");
		assertEquals(1, n);
		
	}
	
	@Test
	public void addUsers() throws LibraryException 
	{
		User user = new User();
		user.setUserName("Deva");
		user.setPassword("123");
		user.setEmailId("deva@gmail.com");
		user.setLibrarian("Y");
		int i = ldi.addUsers(user);
		System.out.println(i+"user added");
		assertEquals(1, i);
	}

	
	@Test
	public void addRegistration() throws LibraryException
	{
		BooksRegistration br = new BooksRegistration();
		br.setRegistrationId("R109");
		br.setBookId("B102");
		br.setUserId("U102");
		br.setRegistrationDate("19-OCT-17");
		br.setStatus("N");
		int k = ldi.addRegistration(br);
		System.out.println(k+"book registered");
		assertEquals(1, k);
	}
}
