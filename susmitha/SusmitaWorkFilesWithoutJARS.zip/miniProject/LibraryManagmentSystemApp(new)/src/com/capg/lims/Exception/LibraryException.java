package com.capg.lims.Exception;

public class LibraryException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LibraryException(String message) 
	{
		super(message);
	}
}
