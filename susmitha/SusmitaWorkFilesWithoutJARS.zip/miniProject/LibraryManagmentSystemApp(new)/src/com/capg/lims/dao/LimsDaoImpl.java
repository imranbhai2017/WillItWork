package com.capg.lims.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InputMismatchException;

import org.apache.log4j.Logger;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public class LimsDaoImpl implements ILimsDao {
	private int n;
	private ResultSet rs;
	private Connection c;
	static Logger log = Logger.getRootLogger();
//FOR LIBRARIAN 
	@Override
	public ArrayList<BooksInventory> selectBook() {
		try {
			c = DBUtil.getConnection();
			log.info("Getting connection from database");
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			
			e1.printStackTrace();
		}
		ArrayList<BooksInventory> blist = new ArrayList<>();

		Statement st;
		try {
			st = c.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECTQ);
			while (rst.next()) {
				BooksInventory BooksInventory = new BooksInventory();
				BooksInventory.setBookId(rst.getString("book_id"));
				BooksInventory.setBookName(rst.getString("book_name"));
				BooksInventory.setAuthorOne(rst.getString("author1"));
				BooksInventory.setAuthorTwo(rst.getString("author2"));
				BooksInventory.setPublisher(rst.getString("publisher"));
				BooksInventory.setYearOfPublication(rst
						.getString("yearofpublication"));
				BooksInventory.setAvailability(rst.getString("AVAILABILITY"));
				blist.add(BooksInventory);
				log.info("Book Displayed on console");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error("Problem in querry(SELECTQ) please check the query");
			e.printStackTrace();
		}

		return blist;
	}

	@Override
	public int addBook(BooksInventory BooksInventory) {

		try {

			c = DBUtil.getConnection();
			log.info("Getting connection to add book to DataBase");
			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERTQBOOK);

			// ps.setString(1, BooksInventory.getBookId());
			ps.setString(1, BooksInventory.getBookName());
			ps.setString(2, BooksInventory.getAuthorOne());
			ps.setString(3, BooksInventory.getAuthorTwo());
			ps.setString(4, BooksInventory.getPublisher());
			ps.setString(5, BooksInventory.getYearOfPublication());
			ps.setString(6, BooksInventory.getAvailability());
			n = ps.executeUpdate();
			log.info("Book Details Added");
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLIntegrityConstraintViolationException se) {
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			log.error("Problem in querry(INSERTQBOOK) please check the query");
			e1.printStackTrace();
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;

	}

	@Override
	public int issueBook(BooksTransaction BooksTransaction) throws LibraryException {
		try {

			c = DBUtil.getConnection();
			log.info("Getting connection to request book");
			PreparedStatement ps = c
					.prepareStatement(QueryMapper.INSERTTRANSAC);

			// ps.setString(1,BooksTransaction.getTransactionId());
			ps.setString(1, BooksTransaction.getRegistrationId());

			ps.setDate(2, Date.valueOf(BooksTransaction.getReturnDate()));

			ps.setDouble(3, BooksTransaction.getFine());
			ps.setDate(4, Date.valueOf(BooksTransaction.getActualReturnDate()));
			ps.setString(5, BooksTransaction.getStatus());
			// System.out.println();
			n = ps.executeUpdate();

			PreparedStatement ps1 = c
					.prepareStatement(QueryMapper.UPDATEBOOKAV);
			String av = "notavaile";
			ps1.setString(1, av);
			ps1.setString(2, BooksTransaction.getBookId());
			ps1.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

			PreparedStatement ps2 = c
					.prepareStatement(QueryMapper.UPDATEREQUEST);
			String status = "Y";
			ps2.setString(1, status);
			ps2.setString(2, BooksTransaction.getRegistrationId());
			ps2.executeUpdate();
			log.info("Book requested by student");
		} catch (SQLIntegrityConstraintViolationException  se) {
			System.out.println("Duplicate Entry");
		
			throw new LibraryException("invalid input:Wrong regid/userid");
		} catch (SQLException e1) {
			log.error("Problem in querry(UPDATEREQUEST) please check the query");
			e1.printStackTrace();
		}
		catch (InputMismatchException e) {
			// TODO: handle exception
			
			throw new LibraryException("invalid input");
		}
		catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return n;
	}

	@Override
	public int updateBookDetails(BooksInventory BooksInventory) {
		try {

			c = DBUtil.getConnection();
			log.info("updating book Details");
			PreparedStatement ps1 = c.prepareStatement(QueryMapper.UPDATEQ);

			ps1.setString(1, BooksInventory.getBookName());
			ps1.setString(2, BooksInventory.getAuthorOne());
			ps1.setString(3, BooksInventory.getAuthorTwo());
			ps1.setString(4, BooksInventory.getPublisher());
			ps1.setString(5, BooksInventory.getYearOfPublication());
			ps1.setString(6, BooksInventory.getBookId());
			n = ps1.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit
			log.info("Book Details Updated");
		} catch (SQLException e1) {
			log.error("Problem in querry(UPDATEQ) please check the query");
			e1.printStackTrace();
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;
	}

	
	@Override
	public void deleteBook(String bookId) {
		try {
			c = DBUtil.getConnection();
			PreparedStatement ps = c.prepareStatement(QueryMapper.DELETEQ);
			ps.setString(1, bookId);
			n = ps.executeUpdate();
			if(n==0)
			{
				System.out.println("not deleted");
			}else{
				System.out.println("deleted");
			}
			//System.out.println("from dao");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("The book has been issued already .You can not delete till returned1 ");
			//throw new LimsException("wrong book id");
			//e.printStackTrace();
		
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public int addUsers(User user) throws LibraryException {
		try {
			c = DBUtil.getConnection();
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.INSERTUSER);
			// ps.setString(1, user.getUserId());
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmailId());
			ps.setString(4, user.getLibrarian());
			n = ps.executeUpdate();
			log.info("User Added into Database");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error("Problem in querry(INSERTUSER) please check the query");
			e.printStackTrace();
			throw new LibraryException("invalid user data");
		}

		return n;
	}

	@Override
	public ResultSet checkUser(String userName) {
		try {
			c = DBUtil.getConnection();
			log.info("check user");
		 
		PreparedStatement ps;
		 
			ps = c.prepareStatement(QueryMapper.SELECTUSERCHECK);
			ps.setString(1, userName);
			 rs = ps.executeQuery();
			log.info("User Checked");
		} catch (SQLException e1) {
			System.err.println("Invalid Username/ Password**");
			log.error("Problem in querry(SELECTUSERCHECK) please check the query");
			e1.printStackTrace();
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch(NullPointerException e2){
			System.err.println("Invalid username / password");
		}
		return rs;
	}

	@Override
	public int updatetransactionDetails(BooksTransaction BooksTransaction) {
		try {

			c = DBUtil.getConnection();

			PreparedStatement ps1 = c.prepareStatement(QueryMapper.UPDATETRANS);

			ps1.setDouble(1, BooksTransaction.getFine());
			ps1.setString(2, BooksTransaction.getRegistrationId());
			n = ps1.executeUpdate();
			PreparedStatement ps = c.prepareStatement(QueryMapper.UPDATTRANSACSTATUS);
			String status = "Y";
			ps.setString(1,status);
			ps.setString(2,BooksTransaction.getRegistrationId());
			System.out.println(BooksTransaction.getRegistrationId());
			rs = ps.executeQuery();
			log.info("Transation updated");
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException e1) {
			e1.printStackTrace();
			log.error("error in updation transaction");
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;
	}

	
	@Override
	public int addRegistration(BooksRegistration BooksRegistration) throws LibraryException {
		try {
			c = DBUtil.getConnection();
			log.info("Student  request book");
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			
		}

		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.INSERTREQUEST);
			// ps.setString(1, BooksRegistration.getRegistrationId());
			ps.setString(1, BooksRegistration.getBookId());
			ps.setString(2, BooksRegistration.getUserId());
			ps.setString(3, BooksRegistration.getStatus());
			n = ps.executeUpdate();
			log.error("book request placed");
		} catch (InputMismatchException | SQLException e) {
			// TODO Auto-generated catch block
			log.error("Problem in querry(INSERTREQUEST) please check the query");
			//System.err.println("Wrong Bookid/userid");
			throw new LibraryException("invalid input:Wrong Bookid/userid");
		
		}

		return n;
	}
	
	@Override
	public ResultSet selectTransactionDate(String regid) throws LibraryException {
		try {
			c = DBUtil.getConnection();
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			PreparedStatement ps = c.prepareStatement(QueryMapper.SELECTRETURN);
			ps.setString(1, regid);
			rs = ps.executeQuery();
		} catch (SQLException e) {
			log.error("Problem in querry(SELECTRETURN) please check the query");
			// TODO Auto-generated catch block
			System.err.println("Enter valid Registration Id");
			throw new LibraryException("invalid input");
			
		}

		return rs;
	}
	
	@Override
	public ArrayList<BooksRegistration> selectBooks() {

		try {
			c = DBUtil.getConnection();
			log.info("fetching registered book details");
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		ArrayList<BooksRegistration> brlist = new ArrayList<>();
		Statement st = null;

		try {
			st = c.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECTREQUEST);
			while (rst.next()) {

				BooksRegistration BookRegistration = new BooksRegistration();

				BookRegistration.setRegistrationId(rst
						.getString("registration_id"));
				BookRegistration.setBookId(rst.getString("book_id"));
				BookRegistration.setUserId(rst.getString("user_id"));
				BookRegistration.setRegistrationDate(rst
						.getString("registration_date"));
				brlist.add(BookRegistration);
				log.info("Book Regisytration Details viewed on console");
			}

		} catch (SQLException e) {
			e.printStackTrace();
			log.error("Problem in querry(SELECTREQUEST) please check the query");
			
		}
		return brlist;
	}


	
	

	@Override
	public ArrayList<BooksTransaction> selecttransac() {
		try {
			c = DBUtil.getConnection();
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		ArrayList<BooksTransaction> tlist = new ArrayList<>();
		Statement st = null;

		try {
			st = c.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECTTRANSACTION);
			while (rst.next()) {

				BooksTransaction BooksTransaction = new BooksTransaction();

				BooksTransaction.setTransactionId(rst
						.getString("TRANSACTION_ID"));
				BooksTransaction.setRegistrationId(rst
						.getString("registration_id"));
				BooksTransaction.setIssueDate(rst.getDate("ISSUE_DATE").toLocalDate());
				BooksTransaction.setReturnDate(rst.getDate("EXPECTED_RETURN_DATE").toLocalDate());
				BooksTransaction.setFine(rst.getDouble("FINE"));
				BooksTransaction.setActualReturnDate(rst.getDate("ACTUAL_RETURN_DATE").toLocalDate());
				BooksTransaction.setStatus(rst.getString("STATUS"));
				tlist.add(BooksTransaction);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return tlist;
	}

	@Override
	public int updatePassword(User User) {
		try {

			c = DBUtil.getConnection();
			log.info("Password update request of student");
			PreparedStatement ps1 = c.prepareStatement(QueryMapper.CHANGEPWD);
			ps1.setString(1,User.getPassword());
			ps1.setString(2, User.getUserId());
			n = ps1.executeUpdate();
			log.info("Password Successfully Changeds");
			if(n>0){
			System.out.println("ggggg");
			}
			else{
				System.err.println("enter correct user id.");
			}
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException e1) {
			log.error("Problem in querry(CHANGEPWD) please check the query");
			e1.printStackTrace();
		} catch (LibraryException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public ArrayList<BooksRegistration> selectRegistration(String uid) {
		try {
			c = DBUtil.getConnection();
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ArrayList<BooksRegistration> blist = new ArrayList<>();

		//Statement st;
		try {
			PreparedStatement ps = c.prepareStatement(QueryMapper.SELECTREGISFORDISPLAY);
			ps.setString(1, uid);
			//rs = ps.executeQuery();
			//st = c.createStatement();
			
			ResultSet rst =ps.executeQuery();
					//st.executeQuery(QueryMapper.SELECTREGISFORDISPLAY);
			while (rst.next()) {
				BooksRegistration BooksRegistration = new BooksRegistration();
				BooksRegistration.setRegistrationId(rst.getString("REGISTRATION_ID"));
				BooksRegistration.setBookId(rst.getString("BOOK_ID"));
				BooksRegistration.setUserId(rst.getString("USER_ID"));
				BooksRegistration.setRegistrationDate(rst.getString("REGISTRATION_DATE"));
				BooksRegistration.setStatus(rst.getString("STATUS"));
				blist.add(BooksRegistration);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return blist;
	}

	@Override
	public ArrayList<BooksTransaction> selectTransactionForStudent(String rid) {
		try {
			c = DBUtil.getConnection();
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		ArrayList<BooksTransaction> blist = new ArrayList<>();

		//Statement st;
		try {
			PreparedStatement ps = c.prepareStatement(QueryMapper.SELECTTRANSACFORDISPLAY);
			ps.setString(1, rid);
			//rs = ps.executeQuery();
			//st = c.createStatement();
			
			ResultSet rst =ps.executeQuery();
					//st.executeQuery(QueryMapper.SELECTREGISFORDISPLAY);
			while (rst.next()) {
				BooksTransaction BooksTransaction = new BooksTransaction();
				BooksTransaction.setTransactionId(rst.getString("TRANSACTION_ID"));
				BooksTransaction.setRegistrationId(rst.getString("REGISTRATION_ID"));
				BooksTransaction.setIssueDate(rst.getDate("ISSUE_DATE").toLocalDate());
				BooksTransaction.setReturnDate(rst.getDate("EXPECTED_RETURN_DATE").toLocalDate());
				BooksTransaction.setFine(rst.getDouble("FINE"));
				BooksTransaction.setActualReturnDate(rst.getDate("ACTUAL_RETURN_DATE").toLocalDate());
				BooksTransaction.setStatus(rst.getString("ACTUAL_RETURN_DATE"));
				blist.add(BooksTransaction);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return blist;
	}

}
