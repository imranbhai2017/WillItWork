package com.capg.lims.dao;

public interface QueryMapper {
	
	public static final String SELECTQ = "SELECT * FROM Books_Inventory ";
	
	public static final String INSERTQBOOK = "INSERT INTO Books_Inventory values('B' || to_char(book_seq.nextval),?,?,?,?,?,?)";
	
	public static final String INSERTTRANSAC = "INSERT INTO book_transaction values('T' || to_char(tran_seq.nextval),?,sysdate,?,?,?,?)";
	
	public static final String UPDATEQ = "update Books_Inventory set book_name =?,author1=?, author2=?, publisher=?,yearofpublication=? where book_id=?";
	
	public static final String SELECTREQUEST ="SELECT * FROM book_registration where status='N'";
	
	public static final String DELETEQ="DELETE FROM Books_Inventory WHERE book_id=?";
	
	public static final String INSERTUSER="INSERT INTO USERS VALUES('U' || to_char(user_seq.nextval),?,?,?,?)";
	
	public static final String SELECTUSERCHECK="select user_id,user_name,password,librarian from users where user_name=?";
	
	public static final String UPDATEBOOKAV ="update Books_Inventory set  AVAILABILITY=? where book_id=?";
	
	public static final String INSERTREQUEST="INSERT INTO book_registration values('R' || to_char(regi_seq.nextval),?,?,sysdate,?)";
	
	public static final String UPDATETRANS="update book_transaction set  FINE=?,ACTUAL_RETURN_DATE=SYSDATE WHERE REGISTRATION_ID=?";
	
	public static final String SELECTRETURN="SELECT EXPECTED_RETURN_DATE FROM book_transaction WHERE REGISTRATION_ID=?";
	
	
	public static final String UPDATEREQUEST = "update book_registration set status=? where REGISTRATION_ID=?";
	
	
	public static final String SELECTTRANSACTION="SELECT * FROM book_transaction WHERE status='N'";
	
	public static final String UPDATTRANSACSTATUS = "update book_transaction set status=? where REGISTRATION_ID=?";
	
	public static final String CHANGEPWD ="update users set PASSWORD=? where user_id=?";
	
	
	public static final String SELECTTRANSACFORDISPLAY="SELECT * FROM book_transaction WHERE REGISTRATION_ID=? ";
	public static final String SELECTREGISFORDISPLAY="SELECT * FROM book_registration WHERE user_id=?";
	
}
