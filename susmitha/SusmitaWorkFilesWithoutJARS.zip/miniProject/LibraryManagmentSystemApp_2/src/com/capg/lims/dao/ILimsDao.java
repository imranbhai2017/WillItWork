package com.capg.lims.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsDao {
	ArrayList<BooksInventory> selectBook();

	int addBook(BooksInventory BooksInventory);

	int issueBook(BooksTransaction BooksTransaction);

	int updateBookDetails(BooksInventory booksInventory);

	ArrayList<BooksRegistration> selectBooks();

	void deleteBook(String bookId);

	int addUsers(User user);

	ResultSet checkUser(String userName);

	int addRegistration(BooksRegistration BooksRegistration);
	int updatetransactionDetails(BooksTransaction BooksTransaction);
	
	ResultSet selectTransactionDate(String regid);
	
	ArrayList<BooksTransaction> selecttransac();
	
	int updatePassword(User User);
	
	ArrayList<BooksRegistration> selectRegistration(String uid);
	
	ArrayList<BooksTransaction> selectTransactionForStudent(String rid);
}
