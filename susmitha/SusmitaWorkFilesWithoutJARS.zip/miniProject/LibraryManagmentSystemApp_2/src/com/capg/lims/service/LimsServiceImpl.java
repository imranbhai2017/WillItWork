package com.capg.lims.service;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.dao.ILimsDao;
import com.capg.lims.dao.LimsDaoImpl;

public class LimsServiceImpl implements ILimsService {
 
	
	
	ILimsDao dao = new LimsDaoImpl();
	@Override
	public ArrayList<BooksInventory> selectBook() {
		// TODO Auto-generated method stub
		return dao.selectBook();
	}
	@Override
	public int addBook(BooksInventory BooksInventory) {
		// TODO Auto-generated method stub
		return dao.addBook(BooksInventory);
	}
	@Override
	public int issueBook(BooksTransaction BooksTransaction) {
		// TODO Auto-generated method stub
		return dao.issueBook(BooksTransaction);
	}
	@Override
	public int updateBookDetails(BooksInventory BooksInventory) {
		
		
		
		return dao.updateBookDetails(BooksInventory);
	}
	@Override
	public ArrayList<BooksRegistration> selectBooks() {
		
		return dao.selectBooks();
	}
	@Override
	public void deleteBook(String bookId) {
		// TODO Auto-generated method stub
		dao.deleteBook(bookId);
		
	}
	
	@Override
	public int addUsers(User user) {
		// TODO Auto-generated method stub
		return dao.addUsers(user);
	}
	@Override
	public ResultSet checkUser(String userName) {
		// TODO Auto-generated method stub
		return dao.checkUser(userName);
	}
	@Override
	public int addRegistration(BooksRegistration BooksRegistration) {
		// TODO Auto-generated method stub
		return dao.addRegistration(BooksRegistration);
	}
	@Override
	public int updatetransactionDetails(BooksTransaction BooksTransaction) {
		
		return dao.updatetransactionDetails(BooksTransaction);
	}
	@Override
	public ResultSet selectTransactionDate(String regid) {
		
		return dao.selectTransactionDate(regid);
	}
	@Override
	public ArrayList<BooksTransaction> selecttransac() {
		
		return dao.selecttransac();
	}
	@Override
	public int updatePassword(User User) {
		
		return dao.updatePassword(User);
	}
	@Override
	public ArrayList<BooksRegistration> selectRegistration(String uid) {
		// TODO Auto-generated method stub
		return dao.selectRegistration( uid);
	}
	@Override
	public ArrayList<BooksTransaction> selectTransactionForStudent(String rid) {
		
		return dao.selectTransactionForStudent(rid);
	}

}
