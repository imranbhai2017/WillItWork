package com.capg.lims.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public class LimsDaoImpl implements ILimsDao {
	private int n;
	private ResultSet rs;
	private Connection c;

	@Override
	public ArrayList<BooksInventory> selectBook() {
		c = DBUtil.getConnection();
		ArrayList<BooksInventory> blist = new ArrayList<>();

		Statement st;
		try {
			st = c.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECTQ);
			while (rst.next()) {
				BooksInventory BooksInventory = new BooksInventory();
				BooksInventory.setBookId(rst.getString("book_id"));
				BooksInventory.setBookName(rst.getString("book_name"));
				BooksInventory.setAuthorOne(rst.getString("author1"));
				BooksInventory.setAuthorTwo(rst.getString("author2"));
				BooksInventory.setPublisher(rst.getString("publisher"));
				BooksInventory.setYearOfPublication(rst
						.getString("yearofpublication"));
				BooksInventory.setAvailability(rst.getString("AVAILABILITY"));
				blist.add(BooksInventory);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return blist;
	}

	@Override
	public int addBook(BooksInventory BooksInventory) {

		try {

			c = DBUtil.getConnection();

			PreparedStatement ps = c.prepareStatement(QueryMapper.INSERTQBOOK);

			// ps.setString(1, BooksInventory.getBookId());
			ps.setString(1, BooksInventory.getBookName());
			ps.setString(2, BooksInventory.getAuthorOne());
			ps.setString(3, BooksInventory.getAuthorTwo());
			ps.setString(4, BooksInventory.getPublisher());
			ps.setString(5, BooksInventory.getYearOfPublication());
			ps.setString(6, BooksInventory.getAvailability());
			n = ps.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLIntegrityConstraintViolationException se) {
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;

	}

	@Override
	public int issueBook(BooksTransaction BooksTransaction) {
		try {

			c = DBUtil.getConnection();

			PreparedStatement ps = c
					.prepareStatement(QueryMapper.INSERTTRANSAC);

			// ps.setString(1,BooksTransaction.getTransactionId());
			ps.setString(1, BooksTransaction.getRegistrationId());

			ps.setDate(2, Date.valueOf(BooksTransaction.getReturnDate()));

			ps.setDouble(3, BooksTransaction.getFine());
			ps.setDate(4, Date.valueOf(BooksTransaction.getActualReturnDate()));
			ps.setString(5, BooksTransaction.getStatus());
			// System.out.println();
			n = ps.executeUpdate();

			PreparedStatement ps1 = c
					.prepareStatement(QueryMapper.UPDATEBOOKAV);
			String av = "notavaile";
			ps1.setString(1, av);
			ps1.setString(2, BooksTransaction.getBookId());
			ps1.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

			PreparedStatement ps2 = c
					.prepareStatement(QueryMapper.UPDATEREQUEST);
			String status = "Y";
			ps2.setString(1, status);
			ps2.setString(2, BooksTransaction.getRegistrationId());
			ps2.executeUpdate();

		} catch (SQLIntegrityConstraintViolationException se) {
			System.out.println("Duplicate Entry");
		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}

		return n;
	}

	@Override
	public int updateBookDetails(BooksInventory BooksInventory) {
		try {

			c = DBUtil.getConnection();

			PreparedStatement ps1 = c.prepareStatement(QueryMapper.UPDATEQ);

			ps1.setString(1, BooksInventory.getBookName());
			ps1.setString(2, BooksInventory.getAuthorOne());
			ps1.setString(3, BooksInventory.getAuthorTwo());
			ps1.setString(4, BooksInventory.getPublisher());
			ps1.setString(5, BooksInventory.getYearOfPublication());
			ps1.setString(6, BooksInventory.getBookId());
			n = ps1.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public ArrayList<BooksRegistration> selectBooks() {

		c = DBUtil.getConnection();

		ArrayList<BooksRegistration> brlist = new ArrayList<>();
		Statement st = null;

		try {
			st = c.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECTREQUEST);
			while (rst.next()) {

				BooksRegistration BookRegistration = new BooksRegistration();

				BookRegistration.setRegistrationId(rst
						.getString("registration_id"));
				BookRegistration.setBookId(rst.getString("book_id"));
				BookRegistration.setUserId(rst.getString("user_id"));
				BookRegistration.setRegistrationDate(rst
						.getString("registration_date"));
				brlist.add(BookRegistration);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return brlist;
	}

	@Override
	public void deleteBook(String bookId) {

		try {
			c = DBUtil.getConnection();
			PreparedStatement ps = c.prepareStatement(QueryMapper.DELETEQ);
			ps.setString(1, bookId);
			n = ps.executeUpdate();
			System.out.println("from dao");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				c.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	@Override
	public int addUsers(User user) {
		c = DBUtil.getConnection();

		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.INSERTUSER);
			// ps.setString(1, user.getUserId());
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getPassword());
			ps.setString(3, user.getEmailId());
			ps.setString(4, user.getLibrarian());
			n = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return n;
	}

	@Override
	public ResultSet checkUser(String userName) {
		c = DBUtil.getConnection();
		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.SELECTUSERCHECK);
			ps.setString(1, userName);
			rs = ps.executeQuery();

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return rs;
	}

	@Override
	public int addRegistration(BooksRegistration BooksRegistration) {
		c = DBUtil.getConnection();

		PreparedStatement ps;
		try {
			ps = c.prepareStatement(QueryMapper.INSERTREQUEST);
			// ps.setString(1, BooksRegistration.getRegistrationId());
			ps.setString(1, BooksRegistration.getBookId());
			ps.setString(2, BooksRegistration.getUserId());
			ps.setString(3, BooksRegistration.getStatus());
			n = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return n;
	}

	@Override
	public int updatetransactionDetails(BooksTransaction BooksTransaction) {
		try {

			c = DBUtil.getConnection();

			PreparedStatement ps1 = c.prepareStatement(QueryMapper.UPDATETRANS);

			ps1.setDouble(1, BooksTransaction.getFine());
			ps1.setString(2, BooksTransaction.getRegistrationId());
			n = ps1.executeUpdate();
			PreparedStatement ps = c.prepareStatement(QueryMapper.UPDATTRANSACSTATUS);
			String status = "Y";
			ps.setString(1,status);
			ps.setString(2,BooksTransaction.getRegistrationId());
			System.out.println(BooksTransaction.getRegistrationId());
			rs = ps.executeQuery();
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public ResultSet selectTransactionDate(String regid) {
		c = DBUtil.getConnection();

		try {
			PreparedStatement ps = c.prepareStatement(QueryMapper.SELECTRETURN);
			ps.setString(1, regid);
			rs = ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return rs;
	}

	@Override
	public ArrayList<BooksTransaction> selecttransac() {
		c = DBUtil.getConnection();

		ArrayList<BooksTransaction> tlist = new ArrayList<>();
		Statement st = null;

		try {
			st = c.createStatement();
			ResultSet rst = st.executeQuery(QueryMapper.SELECTTRANSACTION);
			while (rst.next()) {

				BooksTransaction BooksTransaction = new BooksTransaction();

				BooksTransaction.setTransactionId(rst
						.getString("TRANSACTION_ID"));
				BooksTransaction.setRegistrationId(rst
						.getString("registration_id"));
				BooksTransaction.setIssueDate(rst.getDate("ISSUE_DATE").toLocalDate());
				BooksTransaction.setReturnDate(rst.getDate("EXPECTED_RETURN_DATE").toLocalDate());
				BooksTransaction.setFine(rst.getDouble("FINE"));
				BooksTransaction.setActualReturnDate(rst.getDate("ACTUAL_RETURN_DATE").toLocalDate());
				BooksTransaction.setStatus(rst.getString("STATUS"));
				tlist.add(BooksTransaction);
			}

		} catch (SQLException e) {

			e.printStackTrace();
		}
		return tlist;
	}

	@Override
	public int updatePassword(User User) {
		try {

			c = DBUtil.getConnection();

			PreparedStatement ps1 = c.prepareStatement(QueryMapper.CHANGEPWD);
			ps1.setString(1,User.getPassword());
			ps1.setString(2, User.getUserId());
			n = ps1.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException e1) {
			e1.printStackTrace();
		} finally {

			try {
				c.close();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		return n;
	}

}
