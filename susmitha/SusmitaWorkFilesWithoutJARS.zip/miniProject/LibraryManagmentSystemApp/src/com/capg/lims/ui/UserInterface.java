package com.capg.lims.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Scanner;

import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;
import com.capg.lims.service.LimsServiceImpl;

public class UserInterface {

	static ILimsService service = new LimsServiceImpl();
	public static BooksInventory BooksInventory = new BooksInventory();
	public static BooksTransaction BooksTransaction = new BooksTransaction();
	public static BooksRegistration BookRegistration = new BooksRegistration();
	public static BooksRegistration BooksRegistration = new BooksRegistration();

	private static Scanner in;
	private static User user = new User();

	public static void main(String[] args) {

		in = new Scanner(System.in);

		System.out.println("***********************************");
		System.out.println("WELCOM TO LIBRARY MANAGMENT SYSTEM");
		System.out.println("***********************************");

		System.out.println("Enter The Choice");
		System.out.println("1 start the application");
		System.out.println("0 to Exit");

		int choice = in.nextInt();

		switch (choice) {
		case 1:
			System.out.println("LOGIN PAGE");
			System.out.println("Enter your Choice");
			System.out.println("1 to login.");
			System.out.println("0 to Exit");

			int choice1 = in.nextInt();

			switch (choice1) {

			case 1:
				System.out.println("____________________________________");
				System.out.println("welcome to login");
				System.out.println("____________________________________");

				System.out.println("enter user name:");
				String suname = in.next();
				System.out.println("enter passward:");
				String spwd = in.next();
				ResultSet rs = service.checkUser(suname);
				try {
					while (rs.next()) {

						String uid = rs.getString(1);
						String uname = rs.getString(2);
						String pwd = rs.getString(3);

						if (uname.equalsIgnoreCase(suname)
								&& (pwd.equalsIgnoreCase(spwd))) {
							String key = rs.getString(4);
							switch (key) {

							case "Y":
								System.out.println("user id: " + uid);
								System.out.println("user name: " + suname);

								librarian();
								break;
							case "N":
								System.out.println("user id: " + uid);
								System.out.println("user name: " + suname);
								student();
								break;
							default:
								break;
							}
						} else {
							System.out.println("invalid user name or password");
						}
					}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 0:
				System.exit(0);
				break;
			default:
				System.out.println("Not a Valid Input");
				break;

			}
			break;

		case 0:
			System.exit(0);
			break;
		default:
			System.out.println("Not a Valid Input");
			break;
		}

	}

	public static void librarian() {

		System.out.println("____________________________________");
		System.out.println("welcome to librarian");
		System.out.println("____________________________________");

		System.out.println("1 to add books");
		System.out.println("2 to delete books");
		System.out.println("3 to update books");
		System.out.println("4 to add user");
		System.out.println("5 to check and issue book request");
		System.out.println("6 to return book ");
		System.out.println("0 to Exit");
		System.out.println("Enter your Choice");
		int choice1 = in.nextInt();
		switch (choice1) {
		case 1:
			System.out.println("added book");
			getBookDetails(BooksInventory);
			break;
		case 2:
			deleteBook();
			System.out.println("deleted book");
			break;
		case 3:
			updateBookDetails(BooksInventory);
			System.out.println("updated book");
			break;
		case 4:
			addUsers(user);
			System.out.println("added user");
			break;
		case 5:
			getbookrequest(BookRegistration);
			System.out.println("request checked");
			getIssueDetails(BooksTransaction);
			break;
		case 6:
			
			ArrayList<BooksTransaction> bList = service.selecttransac();
			System.out.println("Transaction Id   " + "Registration ID  " + "Issue Date  "
					+ "Expected return Date   " + "Fine" + "Actual return Date   "
					+ "Status");
			for (int i = 0; i < bList.size(); i++) {
				System.out.println(bList.get(i).getTransactionId() + "         "
						+ bList.get(i).getRegistrationId() + "         "
						+ bList.get(i).getIssueDate() + "        "
						+ bList.get(i).getReturnDate() + "         "
						+ bList.get(i).getFine()+ "          "
						+ bList.get(i).getActualReturnDate() + "       "
						+ bList.get(i).getStatus());

			}
			updateTransactionDetails(BooksTransaction);
			System.out.println(" return");

			break;
		case 0:
			System.exit(0);
			break;

		default:
			System.out.println("invalid input.");
			break;
		}
		librarian();
	}

	public static void student() {

		ArrayList<BooksInventory> bList = service.selectBook();
		System.out.println("Book Id   " + "Book Name  " + "Author 1  "
				+ "Author 2   " + "Publisher  " + "Year of Publication    "
				+ "Avalability");
		for (int i = 0; i < bList.size(); i++) {
			System.out.println(bList.get(i).getBookId() + "         "
					+ bList.get(i).getBookName() + "         "
					+ bList.get(i).getAuthorOne() + "        "
					+ bList.get(i).getAuthorTwo() + "         "
					+ bList.get(i).getPublisher() + "          "
					+ bList.get(i).getYearOfPublication() + "       "
					+ bList.get(i).getAvailability());

		}

		System.out.println("____________________________________");
		System.out.println("welcome to student");
		System.out.println("____________________________________");

		System.out.println("1 to issue books");
		System.out.println("2.change password");
		System.out.println("0 to Exit");
		System.out.println("Enter your Choice");
		int choice1 = in.nextInt();
		switch (choice1) {
		case 1:

			System.out.println("book issued");
			getRequestDetails(BooksRegistration);
			break;
		case 2:
			System.out.println("change pwd");
			updatePassword(user);
			break;
		case 0:
			System.exit(0);
			break;

		default:
			System.out.println("invalid input.");
			break;
		}
		student();

	}

	private static void getBookDetails(BooksInventory BooksInventory) {
		/*
		 * 
		 * System.out.println("Enter Book ID:");
		 * BooksInventory.setBookId(in.next());
		 */

		System.out.println("Enter Book Name:");
		BooksInventory.setBookName(in.next());
		System.out.println("Enter Book Author 1:");
		BooksInventory.setAuthorOne(in.next());
		System.out.println("Enter Book Author 2:");
		BooksInventory.setAuthorTwo(in.next());
		System.out.println("Enter Book Publisher:");
		BooksInventory.setPublisher(in.next());
		System.out.println("Enter Book Year of Publication:");
		BooksInventory.setYearOfPublication(in.next());
		System.out
				.println("Enter Book Availability (can only be available or not available ) :");
		in.nextLine();
		BooksInventory.setAvailability(in.nextLine());
		in.nextLine();
		int add = service.addBook(BooksInventory);

		System.out.println(add + " Row Inserted");

	}

	private static void getIssueDetails(BooksTransaction BooksTransaction) {

		/*
		 * System.out.println("Enter transaction ID:");
		 * BooksTransaction.setTransactionId(in.next());
		 */

		System.out.println("Enter Registration ID:");
		BooksTransaction.setRegistrationId(in.next());
		System.out.println("Enter Book ID:");
		BooksTransaction.setBookId(in.next());

		// System.out.println("Enter retu date :");

		BooksTransaction.setReturnDate(LocalDate.now().plusDays(14));

		// System.out.println("Enter fine:");

		BooksTransaction.setFine(0);
		in.nextLine();
		BooksTransaction.setActualReturnDate(LocalDate.now().plusDays(14));
		BooksTransaction.setStatus("N");
		int add = service.issueBook(BooksTransaction);

		System.out.println(add + " Row Inserted");

	}

	private static void updateBookDetails(BooksInventory BooksInventory) {

		System.out.println("Enter Book ID to update:");
		BooksInventory.setBookId(in.next());

		System.out.println("Enter Book Name:");
		BooksInventory.setBookName(in.next());
		System.out.println("Enter Book Author 1:");
		BooksInventory.setAuthorOne(in.next());
		System.out.println("Enter Book Author 2:");
		BooksInventory.setAuthorTwo(in.next());
		System.out.println("Enter Book Publisher:");
		BooksInventory.setPublisher(in.next());
		System.out.println("Enter Book Year of Publication:");
		BooksInventory.setYearOfPublication(in.next());
		/*
		 * System.out.println(
		 * "Enter Book Availability (can only be available or not available ) :"
		 * ); BooksInventory.setAvailability(in.next());
		 */

		int add = service.updateBookDetails(BooksInventory);

		System.out.println(add + " Row Updated");

	}

	private static void getbookrequest(BooksRegistration BookRegistration) {

		ArrayList<BooksRegistration> brList = service.selectBooks();

		System.out.println("Registration Id   " + "Book Id  " + "User Id   "
				+ "Registration Date");
		for (int i = 0; i < brList.size(); i++) {
			System.out.println(brList.get(i).getRegistrationId()
					+ "             " + brList.get(i).getBookId() + "    "
					+ brList.get(i).getUserId() + "    "
					+ brList.get(i).getRegistrationDate());
		}
	}

	private static void deleteBook() {
		System.out.println("Enter Book ID:");
		String bookId = in.next();
		service.deleteBook(bookId);

	}

	private static void addUsers(User user) {

		/*
		 * System.out.println("Enter user id:"); user.setUserId(in.next());
		 */
		System.out.println("Enter Name:");
		user.setUserName(in.next());
		System.out.println("Enter password:");
		user.setPassword(in.next());
		System.out.println("Enter email id:");
		user.setEmailId(in.next());
		System.out.println("Enter librarian:(can only enter Y or N)");
		user.setLibrarian(in.next());
		int adduser = service.addUsers(user);
		System.out.println(adduser + "User inserted");
	}

	private static void getRequestDetails(BooksRegistration BooksRegistration) {
		/*
		 * System.out.println("Enter Registration ID:");
		 * BooksRegistration.setRegistrationId(in.next());
		 */

		System.out.println("Enter Book ID:");
		BooksRegistration.setBookId(in.next());
		System.out.println("Enter User ID:");
		BooksRegistration.setUserId(in.next());
		BooksRegistration.setStatus("N");

		int add = service.addRegistration(BooksRegistration);

		System.out.println(add + " Row Inserted");

	}

	private static void updateTransactionDetails(
			BooksTransaction BooksTransaction) {

		// System.out.println("Enter Book ID to update:");

		try {
			System.out.println("enter registration id: ");
			String regid = in.next();

			ResultSet rs = service.selectTransactionDate(regid);
			while (rs.next()) {
			LocalDate edate =rs.getDate(1).toLocalDate(); 
			System.out.println("expected return date:"+edate);
			System.out.println("today date:"+LocalDate.now());
			
			Period period = edate.until(LocalDate.now());
			double fine=(double)period.getDays();


			BooksTransaction.setFine(fine);
			BooksTransaction.setRegistrationId(regid);
			service.updatetransactionDetails(BooksTransaction);
			}
			// System.out.println(add + " Row Updated");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private static void updatePassword(
User user) {
		System.out.println("enter user ID:");
		user.setUserId(in.next());
		System.out.println("enter new password:");
		user.setPassword(in.next());
		service.updatePassword(user);
	}

}