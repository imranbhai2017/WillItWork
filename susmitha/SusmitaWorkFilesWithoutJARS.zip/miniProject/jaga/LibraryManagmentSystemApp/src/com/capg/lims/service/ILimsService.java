package com.capg.lims.service;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsService {

	ArrayList<BooksInventory> selectBook();

	int addBook(BooksInventory BooksInventory);

	int issueBook(BooksTransaction BooksTransaction) throws LibraryException;

	int updateBookDetails(BooksInventory booksInventory);

	ArrayList<BooksRegistration> selectBookRequest();

	void deleteBook(String bookId) throws LibraryException;

	int addUsers(User user) throws LibraryException;

	ResultSet checkUser(String userName);

	int addRegistration(BooksRegistration BooksRegistration)
			throws LibraryException;

	int updatetransactionDetails(BooksTransaction BooksTransaction);

	ResultSet selectTransactionDate(String registrationID) throws LibraryException;

	ArrayList<BooksTransaction> selecttransac();

	int updatePassword(User User);

	ArrayList<BooksRegistration> selectRegistration(String userId);

	ArrayList<BooksTransaction> selectTransactionForStudent(String registrationID);

	public boolean isValidUser(User user);

	public boolean isValidApplicant(User user);
}
