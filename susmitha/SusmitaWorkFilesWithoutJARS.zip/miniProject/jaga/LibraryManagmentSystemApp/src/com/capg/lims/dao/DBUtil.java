package com.capg.lims.dao;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.capg.lims.Exception.LibraryException;

public class DBUtil {
	static Logger log = Logger.getRootLogger();
	private static FileInputStream fileInputStream;
	private static Properties properties;
	public static Connection connection;

	public static Connection getConnection() throws LibraryException {
		try {
			log.info("Connecting to DB.......");
			fileInputStream = new FileInputStream("resource/jdbc.properties");

			properties = new Properties();

			properties.load(fileInputStream);

			String url = properties.getProperty("url");
			String uname = properties.getProperty("uname");
			String pass = properties.getProperty("pwd");

			connection = DriverManager.getConnection(url, uname, pass);
			log.info("Connected to Database");
		} catch (IOException e) {

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new LibraryException("connection not done" + e.getMessage());
			// e.printStackTrace();
		} finally {
			try {
				fileInputStream.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				throw new LibraryException("connection not done"
						+ e.getMessage());
				// e.printStackTrace();
			}
		}
		return connection;
	}
}
