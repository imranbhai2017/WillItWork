package com.capg.lims.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;
import com.capg.lims.service.LimsServiceImpl;

public class LibrarianController {

	
	static ILimsService limsService = new LimsServiceImpl();
	public static BooksInventory BooksInventory = new BooksInventory();
	public static BooksTransaction BooksTransaction = new BooksTransaction();
	public static BooksRegistration BookRegistration = new BooksRegistration();
	public static BooksRegistration BooksRegistration = new BooksRegistration();
	private static User user = new User();

	private static Scanner scanner= new Scanner(System.in);
	
	public static void librarian() throws LibraryException {

		System.out
				.println("_____________________________________________________");
		System.out.println("				welcome to librarian");
		System.out
				.println("_____________________________________________________");

		System.out.println("1 to add books");
		System.out.println("                            ");
		System.out.println("2 to delete books");
		System.out.println("                            ");
		System.out.println("3 to update books");
		System.out.println("                            ");
		System.out.println("4 to add user");
		System.out.println("                            ");
		System.out.println("5 to check and issue book request");
		System.out.println("                            ");
		System.out.println("6 to return book ");
		System.out.println("                            ");
		System.out.println("0 to Exit");
		System.out.println("                            ");
		System.out.println("Enter your Choice:");

		try {
			int choice1 = scanner.nextInt();
			switch (choice1) {
			case 1:
				// System.out.println("added book");
				getBookDetails(BooksInventory);
				break;
			case 2:
				UserController.displayBookList();
				deleteBook();
				// System.out.println("deleted book");
				break;
			case 3:

				UserController.displayBookList();
				updateBookDetails(BooksInventory);
				// System.out.println("updated book");
				break;
			case 4:
				addUsers(user);
				System.out.println("added user");
				break;
			case 5:
				
				System.out.println("Book Table");
				System.out.println("--------------");
				
				UserController.displayBookList();
				
				
				System.out.println("                                     ");
				System.out.println("                                     ");
				System.out.println("Book Request Table");
				System.out.println("---------------------");
				try {
					getbookrequest(BookRegistration);
					System.out
							.println("______________________________________________________");
					System.out.println("1 to issue book");
					System.out.println("                            ");
					System.out.println("2 to get back to main menu.");
					System.out.println("                            ");
					System.out.println("Enter choice:");
					int key1 = scanner.nextInt();
					switch (key1) {
					case 1:
						getIssueDetails(BooksTransaction);
						break;
					case 2:
						librarian();
						break;
					}

					// System.out.println(" return");

					// System.out.println("request checked");

					break;

				} catch (InputMismatchException e) {
					// TODO: handle exception
					throw new LibraryException("invalid input:Enter 1 or 2");
				}

			case 6:
				try {
					ArrayList<BooksTransaction> booksTransactionList = limsService.selecttransac();
					System.out.println("Transaction Id			"
							+ "Registration ID			" + "Issue Date			"
							+ "Expected return Date			" + "Fine			"
							+ "Actual return Date			" + "Status");
					System.out.println("                    ");
					for (int i = 0; i < booksTransactionList.size(); i++) {
						System.out.println(booksTransactionList.get(i).getTransactionId()
								+ "		   		"
								+ booksTransactionList.get(i).getRegistrationId()
								+ "				" + booksTransactionList.get(i).getIssueDate()
								+ "				" + booksTransactionList.get(i).getReturnDate()
								+ "         		" + booksTransactionList.get(i).getFine()
								+ "        		 "
								+ booksTransactionList.get(i).getActualReturnDate()
								+ "       			  " + booksTransactionList.get(i).getStatus());

					}
					System.out
							.println("______________________________________________________________");
					System.out.println("1 to place return");
					System.out.println("                    ");
					System.out.println("2 to get back to main menu.");
					System.out.println("                    ");
					System.out.println("Enter Choice:");
					int key = scanner.nextInt();
					switch (key) {
					case 1:
						updateTransactionDetails(BooksTransaction);
						break;
					case 2:
						librarian();
						break;
					}

					// System.out.println(" return");

					break;

				} catch (InputMismatchException inputMismatchException) {
					// TODO: handle exception

					throw new LibraryException("invalid input:Enter 1 or 2");
				}

			case 0:
				System.out.println("Thank You!");
				System.exit(0);
				break;

			default:
				System.out.println("invalid input.");
				break;
			}

		} catch (InputMismatchException inputMismatchException) {
			// TODO: handle exception

			throw new LibraryException(
					"invalid input:Enter the above options only");
		}

		librarian();
	}

	private static void getBookDetails(BooksInventory BooksInventory) {
		/*
		 * 
		 * System.out.println("Enter Book ID:");
		 * BooksInventory.setBookId(in.next());
		 */
		scanner.nextLine();
		System.out.println("Enter Book Name:");
		
		BooksInventory.setBookName(scanner.nextLine());
		
		System.out.println("Enter Book Author 1:");
		//scanner.nextLine();
		BooksInventory.setAuthorOne(scanner.nextLine());
		System.out.println("Enter Book Author 2:");
		//scanner.nextLine();
		BooksInventory.setAuthorTwo(scanner.nextLine());
		System.out.println("Enter Book Publisher:");
		//scanner.nextLine();
		BooksInventory.setPublisher(scanner.nextLine());
		System.out.println("Enter Book Year of Publication:");
		//scanner.nextLine();
		BooksInventory.setYearOfPublication(scanner.nextLine());
		System.out
				.println("Enter Book Availability (can only be available or not available ) :");
		//scanner.nextLine();
		BooksInventory.setAvailability(scanner.nextLine());
		//scanner.nextLine();
		int add = limsService.addBook(BooksInventory);

		System.out.println(add + " Row Inserted");

	}
	
	
	private static void updateBookDetails(BooksInventory BooksInventory) {

		System.out.println("Enter Book ID to update:");
		BooksInventory.setBookId(scanner.next());

		System.out.println("Enter Book Name:");
		scanner.nextLine();
		BooksInventory.setBookName(scanner.nextLine());
		System.out.println("Enter Book Author 1:");
		scanner.nextLine();
		BooksInventory.setAuthorOne(scanner.nextLine());
		scanner.nextLine();
		System.out.println("Enter Book Author 2:");
		BooksInventory.setAuthorTwo(scanner.nextLine());
		System.out.println("Enter Book Publisher:");
		scanner.nextLine();
		BooksInventory.setPublisher(scanner.nextLine());
		System.out.println("Enter Book Year of Publication:");
		
		scanner.nextLine();
		BooksInventory.setYearOfPublication(scanner.nextLine());
		/*
		 * System.out.println(
		 * "Enter Book Availability (can only be available or not available ) :"
		 * ); BooksInventory.setAvailability(in.next());
		 */

		int add = limsService.updateBookDetails(BooksInventory);

		System.out.println(add + " Row Updated");

	}

	private static void getbookrequest(BooksRegistration BookRegistration) {

		ArrayList<BooksRegistration> booksRegistrationList = limsService.selectBookRequest();

		System.out.println("Registration Id		" + "Book Id			" + "User Id			"
				+ "Registration Date");
		System.out.println("                                    ");
		for (int i = 0; i < booksRegistrationList.size(); i++) {
			System.out.println(booksRegistrationList.get(i).getRegistrationId()
					+ "			" + booksRegistrationList.get(i).getBookId() + "			"
					+ booksRegistrationList.get(i).getUserId() + "			"
					+ booksRegistrationList.get(i).getRegistrationDate());
		}
	}

	private static void deleteBook() {
		System.out.println("Enter Book ID:");
		String bookId = scanner.next();

		try {
			limsService.deleteBook(bookId);
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		}

	}

	private static void addUsers(User user) throws LibraryException {

		/*
		 * System.out.println("Enter user id:"); user.setUserId(in.next());
		 */
		System.out.println("Enter Name:");
		scanner.nextLine();
		user.setUserName(scanner.nextLine());
		System.out.println("Enter password:");
		user.setPassword(scanner.next());
		System.out.println("Enter email id:");
		user.setEmailId(scanner.next());
		System.out.println("Enter librarian:(can only enter Y or N)");
		user.setLibrarian(scanner.next());
		int adduser = limsService.addUsers(user);
		System.out.println(adduser + "User inserted");
	}

	
	private static void updateTransactionDetails(
			BooksTransaction BooksTransaction) throws LibraryException {

		// System.out.println("Enter Book ID to update:");

		try {
			System.out.println("Enter Registration Id: ");
			String registrationId = scanner.next();

			ResultSet resultSet = limsService.selectTransactionDate(registrationId);
			while (resultSet.next()) {
				LocalDate edate = resultSet.getDate(1).toLocalDate();
				System.out.println("Expected Return Date:" + edate);
				System.out.println("Today Date:" + LocalDate.now());

				Period period = edate.until(LocalDate.now());
				double fine = (double) period.getDays();
				
				
				if(fine<=0){
				//CHECK PLESE 
					BooksTransaction.setFine(0);
				}
				else{
					BooksTransaction.setFine(fine);
				}
				
				
				BooksTransaction.setRegistrationId(registrationId);
				limsService.updatetransactionDetails(BooksTransaction);
			}
			// System.out.println(add + " Row Updated");
		} catch (SQLException sqlException) {
			// TODO Auto-generated catch block
			sqlException.printStackTrace();
		}

	}
	public static void getIssueDetails(BooksTransaction BooksTransaction)
			throws LibraryException {
		try {
			/*
			 * System.out.println("Enter transaction ID:");
			 * BooksTransaction.setTransactionId(in.next());
			 */

			System.out.println("Enter Registration ID:");
			BooksTransaction.setRegistrationId(scanner.next());
			System.out.println("                        ");
			System.out.println("Enter Book ID:");
			BooksTransaction.setBookId(scanner.next());

			// System.out.println("Enter retu date :");

			BooksTransaction.setReturnDate(LocalDate.now().plusDays(14));

			// System.out.println("Enter fine:");

			BooksTransaction.setFine(0);
			scanner.nextLine();
			BooksTransaction.setActualReturnDate(LocalDate.now().plusDays(14));
			BooksTransaction.setStatus("N");
			int add = limsService.issueBook(BooksTransaction);

			System.out.println(add + " Row Inserted");

		} catch (InputMismatchException inputMismatchException) {
			// TODO: handle exception
			System.err.println("wrong registrationid/bookid");
			throw new LibraryException("invalid input");
		}

	}


}
