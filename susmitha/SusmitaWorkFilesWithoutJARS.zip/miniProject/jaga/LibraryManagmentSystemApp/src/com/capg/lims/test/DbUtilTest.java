package com.capg.lims.test;

import static junit.framework.Assert.assertNotNull;

import java.sql.Connection;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.Test;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.dao.DBUtil;

public class DbUtilTest {

	

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}
	@Test
	public void test() throws LibraryException {
		Connection dbCon = DBUtil.getConnection();
		assertNotNull(dbCon);
	}
	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
}
}
