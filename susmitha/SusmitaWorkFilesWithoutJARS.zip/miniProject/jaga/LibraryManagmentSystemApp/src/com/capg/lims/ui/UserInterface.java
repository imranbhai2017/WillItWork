package com.capg.lims.ui;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.service.ILimsService;
import com.capg.lims.service.LimsServiceImpl;

public class UserInterface {

	static ILimsService limsService = new LimsServiceImpl();

	private static Scanner scanner;

	public static void main(String[] args) throws LibraryException {

		scanner = new Scanner(System.in);

		System.out.println("***********************************");
		System.out.println("WELCOM TO LIBRARY MANAGMENT SYSTEM");
		System.out.println("***********************************");

		
		int n;
		do {

			try {
				System.out.println("Enter The Choice");
				System.out.println("1 to start the application");
				System.out.println("0 to Exit");
				int choice = scanner.nextInt();

				switch (choice) {
				case 1:
					System.out.println("============");
					System.out.println("LOGIN PAGE");
					System.out.println("============");
					System.out.println("                            ");

					System.out.println("1 to login.");
					System.out.println("                            ");
					System.out.println("0 to Exit");
					System.out.println("                            ");
					System.out.println("Enter your Choice");

					int choice1 = scanner.nextInt();

					switch (choice1) {

					case 1:
						System.out
								.println("___________________________________________");
						System.out.println("			welcome to login");
						System.out
								.println("___________________________________________");

						System.out.println("enter user name:");
						String suname = scanner.next();
						System.out.println("enter passward:");
						String spwd = scanner.next();
						try {
							ResultSet rs = limsService.checkUser(suname);

							while (rs.next()) {
								System.out
										.println("_____________________________________________");
								String uid = rs.getString(1);
								String uname = rs.getString(2);
								String pwd = rs.getString(3);
								if ((uname.equalsIgnoreCase(suname))
										&& (pwd.equalsIgnoreCase(spwd))) {

									String key = rs.getString(4);
									switch (key) {

									case "Y":
										System.out.println("USER ID: " + uid);
										System.out.println("USER NAME: "
												+ suname);

										LibrarianController.librarian();
										break;
									case "N":
										System.out
												.println("____________________________________________");
										System.out.println("USER ID: " + uid);
										System.out.println("USER NAME: "
												+ suname);
										UserController.user();
										break;
									default:
										break;
									}
								} else {
									System.out
											.println("invalid user name or password");

								}
							}

						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (NullPointerException e2) {
							e2.printStackTrace();
							System.err.println("Invalid Username/ Password");
						}
					}

					break;
				case 0:
					System.exit(0);
					break;
				default:
					System.out.println("Not a Valid Input");
					break;

				}

			} catch (InputMismatchException e) {
				// TODO: handle exception
				// System.err.println("Enter 1 or 0 only");
				throw new LibraryException("invalid input:Enter 1 or 0 only");
			}

			System.out.println("Do you want to continue 1.yes 0.no");
			n = scanner.nextInt();
		} while (n != 0);

	}
}