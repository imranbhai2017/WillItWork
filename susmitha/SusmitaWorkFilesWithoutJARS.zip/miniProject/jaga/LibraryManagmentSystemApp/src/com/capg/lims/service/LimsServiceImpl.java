package com.capg.lims.service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.dao.ILimsDao;
import com.capg.lims.dao.LimsDaoImpl;

public class LimsServiceImpl implements ILimsService {
	Scanner in = new Scanner(System.in);
	User user = new User();
	
	ILimsDao dao = new LimsDaoImpl();
	@Override
	public ArrayList<BooksInventory> selectBook() {
		// TODO Auto-generated method stub
		return dao.selectBook();
	}
	@Override
	public int addBook(BooksInventory BooksInventory) {
		// TODO Auto-generated method stub
		return dao.addBook(BooksInventory);
	}
	@Override
	public int issueBook(BooksTransaction BooksTransaction) throws LibraryException {
		// TODO Auto-generated method stub
		return dao.issueBook(BooksTransaction);
	}
	@Override
	public int updateBookDetails(BooksInventory BooksInventory) {
		
		
		
		return dao.updateBookDetails(BooksInventory);
	}
	@Override
	public ArrayList<BooksRegistration> selectBookRequest() {
		
		return dao.selectBookRequest();
	}
	@Override
	public void deleteBook(String bookId){
		// TODO Auto-generated method stub
	 dao.deleteBook(bookId);
		
	}
	
	@Override
	public int addUsers(User user) throws LibraryException {
		if(isValidApplicant(user)){
		return dao.addUsers(user);
		}
		return 0;
	}
	@Override
	public ResultSet checkUser(String userName) {
		// TODO Auto-generated method stub
		return dao.checkUser(userName);
	}
	@Override
	public int addRegistration(BooksRegistration BooksRegistration) throws LibraryException {
		// TODO Auto-generated method stub
		return dao.addRegistration(BooksRegistration);
	}
	@Override
	public int updatetransactionDetails(BooksTransaction BooksTransaction) {
		
		return dao.updatetransactionDetails(BooksTransaction);
	}
	@Override
	public ResultSet selectTransactionDate(String registrationID) throws LibraryException {
		
		return dao.selectTransactionDate(registrationID);
	}
	@Override
	public ArrayList<BooksTransaction> selecttransac() {
		
		return dao.selecttransac();
	}
	@Override
	public int updatePassword(User User) {
		if (isValidUser(User)) {
		return dao.updatePassword(User);
		}
		return 0;
	}
	@Override
	public ArrayList<BooksRegistration> selectRegistration(String userId) {
		// TODO Auto-generated method stub
		return dao.selectRegistration( userId);
	}
	@Override
	public ArrayList<BooksTransaction> selectTransactionForStudent(String registrationID) {
		
		return dao.selectTransactionForStudent(registrationID);
	}
	@Override
	public boolean isValidUser(User user) {
		if (validatePassword(user.getPassword())) {

			return true;

		}
		return false;
	}
	

	

public boolean validatePassword(String password) {

	if (password.length()<9) {
		System.out.println("Valid password");

	} else {
		System.out.println("Not a Valid password");
		System.out.println("Enter a Valid password:");
		password = in.next();
		user.setPassword(password);
		// Client.apply.(name);
		validatePassword(password);
	}
	return true;

}
@Override
public boolean isValidApplicant(User user) {
	if (validateEmail(user.getEmailId()))
	{
return true;
	}
return false;
}


private boolean validateEmail(String email) {
	Pattern pattern = Pattern.compile("[A-Z a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}");
	Matcher matcher = pattern.matcher(email);
	if (matcher.matches()) {
	
	
	} else {
		System.out.println("Not a Valid email");
		System.out.print("Enter a Valid email:");
		email = in.next();
		user.setEmailId(email);
		validateEmail(email);
	}
	return true;
}
}
