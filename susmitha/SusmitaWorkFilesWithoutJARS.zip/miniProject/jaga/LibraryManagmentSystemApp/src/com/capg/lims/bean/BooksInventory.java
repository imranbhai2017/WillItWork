package com.capg.lims.bean;

public class BooksInventory {

	
	private String bookId;
	private String bookName;
	private String authorOne;
	private String authorTwo;
	private String publisher;
	private String yearOfPublication;
	private String availability;
	public String getBookId() {
		return bookId;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorOne() {
		return authorOne;
	}
	public void setAuthorOne(String authorOne) {
		this.authorOne = authorOne;
	}
	public String getAuthorTwo() {
		return authorTwo;
	}
	public void setAuthorTwo(String authorTwo) {
		this.authorTwo = authorTwo;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getYearOfPublication() {
		return yearOfPublication;
	}
	public void setYearOfPublication(String yearOfPublication) {
		this.yearOfPublication = yearOfPublication;
	}
	
	
}
