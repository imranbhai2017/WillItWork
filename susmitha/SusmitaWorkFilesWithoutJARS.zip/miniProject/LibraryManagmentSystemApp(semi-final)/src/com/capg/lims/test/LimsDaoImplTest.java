package com.capg.lims.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.Test;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.dao.LimsDaoImpl;

public class LimsDaoImplTest {
	LimsDaoImpl limsDaoImpl = new LimsDaoImpl();

	@Test
	public void SelectBooktest() {

	
		ArrayList<BooksInventory> booksInventoryList = limsDaoImpl.selectBook();
		if (booksInventoryList.isEmpty()) {
			assertEquals(1, 0);
		} else {
			assertEquals(1, 1);
		}
	}

	@Test
	public void updateBookDetailsTest() {
		BooksInventory booksInventory = new BooksInventory();
		booksInventory.setBookName("java");
		booksInventory.setAuthorOne("roy");
		booksInventory.setAuthorTwo("das");
		booksInventory.setPublisher("jain");
		booksInventory.setYearOfPublication("31may,98");
		booksInventory.setBookId("B104");
		int n = limsDaoImpl.updateBookDetails(booksInventory);
		assertEquals(1, n);

	}

	@Test
	public void checkUserTest() {

		String uname = "susmita";
		assertNotNull(limsDaoImpl.checkUser(uname));

	}

	@Test
	public void updatetransactionDetails() {
		BooksTransaction booksTransaction = new BooksTransaction();
		booksTransaction.setRegistrationId("R183");
		booksTransaction.setFine(10.0);
		int n = limsDaoImpl.updatetransactionDetails(booksTransaction);
		assertEquals(1, n);
	}

	@Test
	public void selectTransactionDate() throws SQLException, LibraryException {
		LimsDaoImpl limsDaoImpl = new LimsDaoImpl();
		;
		String registrationId = "R161";
		ResultSet rs = limsDaoImpl.selectTransactionDate(registrationId);
		try {
			assertTrue(rs.next());
		} catch (SQLException sqlException) {
			// TODO Auto-generated catch block
			sqlException.printStackTrace();
		}
	}

	@Test
	public void selectBooksTest() {
		ArrayList<BooksRegistration> booksRegistrationList = limsDaoImpl.selectBookRequest();

		if (booksRegistrationList.isEmpty()) {
			assertEquals(1, 0);
		} else {
			assertEquals(1, 1);
		}

	}

	@Test
	public void selecttransacTest() {
		ArrayList<BooksTransaction> booksTransactionList = limsDaoImpl.selecttransac();
		if (booksTransactionList.isEmpty()) {
			assertEquals(1, 0);
		} else {
			assertEquals(1, 1);
		}
	}

	@Test
	public void updatePasswordTest() {
		User user = new User();

		user.setUserId("U100");
		user.setPassword("234");
		int n = limsDaoImpl.updatePassword(user);
		assertEquals(1, n);

	}

	@Test
	public void selectRegistrationTest() {

		ArrayList<BooksRegistration> booksRegistrationList = limsDaoImpl
				.selectRegistration("U102");
		if (booksRegistrationList.isEmpty()) {
			assertEquals(1, 0);
		} else {
			assertEquals(1, 1);
		}
	}

	@Test
	public void selectTransactionForStudent() {

		String registrationId = "R104";
		ArrayList<BooksTransaction> booksTransactionList = limsDaoImpl
				.selectTransactionForStudent(registrationId);
		if (booksTransactionList.isEmpty()) {
			assertEquals(1, 0);
		} else {
			assertEquals(1, 1);
		}
	}

	@Test
	public void addBook() {
		BooksInventory BooksInventory = new BooksInventory();

		BooksInventory.setBookName("Civ");
		BooksInventory.setAuthorOne("Mari");
		BooksInventory.setAuthorTwo("Don");
		BooksInventory.setPublisher("SImbu");
		BooksInventory.setYearOfPublication("2014");
		BooksInventory.setAvailability("Y");
		int n = limsDaoImpl.addBook(BooksInventory);
		System.out.println(n + "Row inserted");
		assertEquals(1, n);

	}

	@Test
	public void addUsers() throws LibraryException {
		User user = new User();
		user.setUserName("Dev");
		user.setPassword("123");
		user.setEmailId("deva@gmail.com");
		user.setLibrarian("N");
		int i = limsDaoImpl.addUsers(user);
		System.out.println(i + "user added");
		assertEquals(1, i);
	}

	@Test
	public void addRegistration() throws LibraryException {
		BooksRegistration booksRegistration = new BooksRegistration();
		booksRegistration.setRegistrationId("R185");
		booksRegistration.setBookId("B104");
		booksRegistration.setUserId("U102");
		booksRegistration.setRegistrationDate("19-OCT-17");
		booksRegistration.setStatus("N");
		int k = limsDaoImpl.addRegistration(booksRegistration);
		System.out.println(k + "book registered");
		assertEquals(1, k);
	}
}
