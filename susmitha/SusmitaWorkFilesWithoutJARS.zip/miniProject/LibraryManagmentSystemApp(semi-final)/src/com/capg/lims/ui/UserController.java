package com.capg.lims.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.service.ILimsService;
import com.capg.lims.service.LimsServiceImpl;

public class UserController {

	static ILimsService service = new LimsServiceImpl();
	public static BooksInventory BooksInventory = new BooksInventory();
	public static BooksTransaction BooksTransaction = new BooksTransaction();
	public static BooksRegistration BooksRegistration = new BooksRegistration();

	private static Scanner scanner = new Scanner(System.in);
	private static User user;// = new User();
	
	public static void user() throws LibraryException {
		user = new User();
		displayBookList();

		System.out
				.println("____________________________________________________________");
		System.out.println("					welcome to student");
		System.out
				.println("______________________________________________________________");

		System.out.println("1 to request books");
		System.out.println("               ");
		System.out.println("2.change password");
		System.out.println("                 ");
		System.out.println("3 check request and issue details");
		System.out.println("                    ");
		System.out.println("0 to Exit");
		System.out.println("                    ");
		System.out.println("Enter your Choice");
		
		try {
			int choice1 = scanner.nextInt();
			switch (choice1) {
			case 1:

				
				getRequestDetails(BooksRegistration);
				break;
			case 2:
				System.out.println("change pwd");
				updatePassword(user);
				break;
			case 3:
				getUserIdForBookRegistration();

				System.out
						.println("_______________________________________________________________");

				break;
			case 0:
				System.out.println("Thank You!");
				System.exit(0);
				break;

			default:
				System.out.println("invalid input.");
				break;
			}
			user();

		} catch (InputMismatchException e) {
			// TODO: handle exception
			// System.err.println("Student Exception");
			throw new LibraryException("invalid input:Enter above options only");
		}

	}
	
	
	
	public static void displayBookList(){
		ArrayList<BooksInventory> booksInventoryList = service.selectBook();
		System.out.println("Book Id			" + "Book Name		" + "Author 1		"
				+ "Author 2	" + "Publisher	" + "Year of Publication	"
				+ "Avalability");
		System.out.println("                        ");
		for (int i = 0; i < booksInventoryList.size(); i++) {
			System.out.println(booksInventoryList.get(i).getBookId() + "			"
					+ booksInventoryList.get(i).getBookName() + "			"
					+ booksInventoryList.get(i).getAuthorOne() + "			"
					+ booksInventoryList.get(i).getAuthorTwo() + "         	"
					+ booksInventoryList.get(i).getPublisher() + "          	"
					+ booksInventoryList.get(i).getYearOfPublication() + "			"
					+ booksInventoryList.get(i).getAvailability());

		}
	}

	private static void getRequestDetails(BooksRegistration BooksRegistration)
			throws LibraryException {
		/*
		 * System.out.println("Enter Registration ID:");
		 * BooksRegistration.setRegistrationId(in.next());
		 */

		System.out.println("Enter Book ID:");
		BooksRegistration.setBookId(scanner.next());
		System.out.println("Enter User ID:");
		BooksRegistration.setUserId(scanner.next());
		BooksRegistration.setStatus("N");

		service.addRegistration(BooksRegistration);

		System.out.println("Registration Successful ");

	}
	
	private static void updatePassword(User user) {
		System.out.println("enter user ID:");
		user.setUserId(scanner.next());
		System.out.println("enter new password:");
		user.setPassword(scanner.next());
		service.updatePassword(user);
	}
	
	private static void getUserIdForBookRegistration() throws LibraryException {

		System.out.println("Insert User Id:");
		String userId = scanner.next();
		ArrayList<BooksRegistration> booksRegistrationList = service.selectRegistration(userId);

		System.out.println("Registration Id			" + "Book Id			" + "User Id			"
				+ "Registration Date			" + "Status");
		for (int i = 0; i < booksRegistrationList.size(); i++) {
			System.out.println(booksRegistrationList.get(i).getRegistrationId()
					+ "			" + booksRegistrationList.get(i).getBookId() + "			"
					+ booksRegistrationList.get(i).getUserId() + "			"
					+ booksRegistrationList.get(i).getRegistrationDate() + "			"
					+ booksRegistrationList.get(i).getStatus());
		}

		System.out
				.println("________________________________________________________________");
		System.out.println("1 to see transaction");
		System.out.println("           ");
		System.out.println("2 to go back to main menu");
		System.out.println("           ");
		System.out.println("Enter your Choice");
		int key = scanner.nextInt();
		switch (key) {
		case 1:

			getRegIdForBookTransaction();
			break;
		case 2:
			UserController.user();

			break;
		default:
			break;
		}
	}

	private static void getRegIdForBookTransaction() {

		System.out.println("insert registration id:");
		String registrationId = scanner.next();
		ArrayList<BooksTransaction> booksTransactionList = service
				.selectTransactionForStudent(registrationId);

		System.out.println("Transaction Id	" + "Registration Id	"
				+ "Issue Date		" + "Expected return date		" + "Fine		"
				+ "Actual return Date	" + "Status");
		System.out.println("                                   ");
		for (int i = 0; i < booksTransactionList.size(); i++) {
			System.out.println(booksTransactionList.get(i).getTransactionId()
					+ "			" + booksTransactionList.get(i).getRegistrationId()
					+ "			" + booksTransactionList.get(i).getIssueDate() + "			"
					+ booksTransactionList.get(i).getReturnDate() + "			"
					+ booksTransactionList.get(i).getFine() + "			"
					+ booksTransactionList.get(i).getActualReturnDate() + "			"
					+ booksTransactionList.get(i).getStatus());
		}
	}

}
