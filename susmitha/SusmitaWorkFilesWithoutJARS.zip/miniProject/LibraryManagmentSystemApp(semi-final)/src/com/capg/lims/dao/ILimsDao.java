package com.capg.lims.dao;

import java.sql.ResultSet;
import java.util.ArrayList;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;

public interface ILimsDao {

	// for librarian
	ArrayList<BooksInventory> selectBook();// mah

	int addBook(BooksInventory BooksInventory);// sus

	int issueBook(BooksTransaction BooksTransaction) throws LibraryException;// par

	int updateBookDetails(BooksInventory booksInventory);// jag

	void deleteBook(String bookId);// jagd

	int addUsers(User user) throws LibraryException;// shr

	ResultSet checkUser(String userName);// sus

	int updatetransactionDetails(BooksTransaction BooksTransaction);// jaga

	ResultSet selectTransactionDate(String regid) throws LibraryException;// parv

	// for student

	ArrayList<BooksRegistration> selectBookRequest();// shru

	int addRegistration(BooksRegistration BooksRegistration)
			throws LibraryException;// jagd

	ArrayList<BooksTransaction> selecttransac();// jagad

	int updatePassword(User User);// mahi

	ArrayList<BooksRegistration> selectRegistration(String userId);// sus

	ArrayList<BooksTransaction> selectTransactionForStudent(String registrationID);// sus
}
