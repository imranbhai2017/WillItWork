package com.capg.lims.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InputMismatchException;

import org.apache.log4j.Logger;

import com.capg.lims.Exception.LibraryException;
import com.capg.lims.bean.BooksInventory;
import com.capg.lims.bean.BooksRegistration;
import com.capg.lims.bean.BooksTransaction;
import com.capg.lims.bean.User;
import com.capg.lims.ui.LibrarianController;

public class LimsDaoImpl implements ILimsDao {
	private int n;
	private ResultSet resultSet;
	private Connection connection;
	static Logger log = Logger.getRootLogger();
	static String bookid;

	// FOR LIBRARIAN
	@Override
	public ArrayList<BooksInventory> selectBook() {
		try {
			connection = DBUtil.getConnection();
			log.info("Getting connection from database");
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block

			e1.printStackTrace();
		}
		ArrayList<BooksInventory> booksInventoryList = new ArrayList<>();

		Statement statement;
		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement
					.executeQuery(QueryMapper.SELECTBOOK);
			while (resultSet.next()) {
				BooksInventory BooksInventory = new BooksInventory();
				BooksInventory.setBookId(resultSet.getString("book_id"));
				BooksInventory.setBookName(resultSet.getString("book_name"));
				BooksInventory.setAuthorOne(resultSet.getString("author1"));
				BooksInventory.setAuthorTwo(resultSet.getString("author2"));
				BooksInventory.setPublisher(resultSet.getString("publisher"));
				BooksInventory.setYearOfPublication(resultSet
						.getString("yearofpublication"));
				BooksInventory.setAvailability(resultSet
						.getString("AVAILABILITY"));
				booksInventoryList.add(BooksInventory);
				log.info("Book Displayed on console");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			log.error("Problem in querry(SELECTQ) please check the query");
			e.printStackTrace();
		}

		return booksInventoryList;
	}

	@Override
	public int addBook(BooksInventory BooksInventory) {

		try {

			connection = DBUtil.getConnection();
			log.info("Getting connection to add book to DataBase");
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTQBOOK);

			// ps.setString(1, BooksInventory.getBookId());
			preparedStatement.setString(1, BooksInventory.getBookName());
			preparedStatement.setString(2, BooksInventory.getAuthorOne());
			preparedStatement.setString(3, BooksInventory.getAuthorTwo());
			preparedStatement.setString(4, BooksInventory.getPublisher());
			preparedStatement.setString(5,
					BooksInventory.getYearOfPublication());
			preparedStatement.setString(6, BooksInventory.getAvailability());
			n = preparedStatement.executeUpdate();
			log.info("Book Details Added");
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLIntegrityConstraintViolationException exception) {
			System.out.println("Duplicate Entry");
		} catch (SQLException exception1) {
			log.error("Problem in querry(INSERTQBOOK) please check the query");
			exception1.printStackTrace();
		} catch (LibraryException exception2) {
			// TODO Auto-generated catch block
			exception2.printStackTrace();
		} finally {

			try {
				connection.close();
			} catch (SQLException exception) {
				// TODO Auto-generated catch block
				exception.printStackTrace();
			}
		}
		return n;

	}

	@Override
	public int issueBook(BooksTransaction BooksTransaction)
			throws LibraryException {
		try {

			connection = DBUtil.getConnection();
			log.info("Getting connection to request book");
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTTRANSAC);

			// ps.setString(1,BooksTransaction.getTransactionId());
			preparedStatement
					.setString(1, BooksTransaction.getRegistrationId());

			preparedStatement.setDate(2,
					Date.valueOf(BooksTransaction.getReturnDate()));

			preparedStatement.setDouble(3, BooksTransaction.getFine());
			preparedStatement.setDate(4,
					Date.valueOf(BooksTransaction.getActualReturnDate()));
			preparedStatement.setString(5, BooksTransaction.getStatus());
			// System.out.println();
			n = preparedStatement.executeUpdate();

			PreparedStatement preparedStatement2 = connection
					.prepareStatement(QueryMapper.UPDATEBOOKAV);
			String av = "notavailable";
			preparedStatement2.setString(1, av);
			preparedStatement2.setString(2, BooksTransaction.getBookId());
			preparedStatement2.executeUpdate();
			// c.setAutoCommit(false); Disabling the Auto Commit

			PreparedStatement preparedStatement3 = connection
					.prepareStatement(QueryMapper.UPDATEREQUEST);
			String status = "Y";
			preparedStatement3.setString(1, status);
			preparedStatement3.setString(2,
					BooksTransaction.getRegistrationId());
			n = preparedStatement3.executeUpdate();
			if (n == 0) {
				System.err.println("Not valid registration or book id");
				LibrarianController.getIssueDetails(BooksTransaction);
			}

			log.info("Book requested by student");
		} catch (SQLIntegrityConstraintViolationException exception) {
			System.err.println("invalid book ig or registration id");

			// throw new LibraryException("invalid input:Wrong regid/userid");
		} catch (SQLException sqlException) {
			log.error("Problem in querry(UPDATEREQUEST) please check the query");
			sqlException.printStackTrace();
		} catch (InputMismatchException inputMismatchException) {
			// TODO: handle exception

			throw new LibraryException("invalid input");
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		} finally {

			try {
				connection.close();
			} catch (SQLException sqlException) {
				// TODO Auto-generated catch block
				sqlException.printStackTrace();
			}
		}

		return n;
	}

	@Override
	public int updateBookDetails(BooksInventory BooksInventory) {
		try {

			connection = DBUtil.getConnection();
			log.info("updating book Details");
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.UPDATEQBOOK);

			preparedStatement.setString(1, BooksInventory.getBookName());
			preparedStatement.setString(2, BooksInventory.getAuthorOne());
			preparedStatement.setString(3, BooksInventory.getAuthorTwo());
			preparedStatement.setString(4, BooksInventory.getPublisher());
			preparedStatement.setString(5,
					BooksInventory.getYearOfPublication());
			preparedStatement.setString(6, BooksInventory.getBookId());
			n = preparedStatement.executeUpdate();
			if (n == 0) {
				System.err.println("Wrong book id");
			}
			// c.setAutoCommit(false); Disabling the Auto Commit
			log.info("Book Details Updated");
		} catch (SQLException sqlException) {
			log.error("Problem in querry(UPDATEQ) please check the query");
			sqlException.printStackTrace();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		} finally {

			try {
				connection.close();
			} catch (SQLException sqlException) {
				// TODO Auto-generated catch block
				sqlException.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public void deleteBook(String bookId) {
		try {
			connection = DBUtil.getConnection();
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.DELETEBOOK);
			preparedStatement.setString(1, bookId);
			n = preparedStatement.executeUpdate();
			if (n == 0) {
				System.err.println("Wrong Book Id: not deleted");
			} else {
				System.out.println("deleted");
			}
			// System.out.println("from dao");

		} catch (SQLException sqlException) {
			// TODO Auto-generated catch block
			System.err
					.println("The book has been issued already .You can not delete till returned1 ");
			// throw new LimsException("wrong book id");
			// e.printStackTrace();

		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException sqlException) {
				// TODO Auto-generated catch block
				sqlException.printStackTrace();
			}
		}

	}

	@Override
	public int addUsers(User user) throws LibraryException {
		try {
			connection = DBUtil.getConnection();
		} catch (LibraryException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTUSER);
			// ps.setString(1, user.getUserId());
			preparedStatement.setString(1, user.getUserName());
			preparedStatement.setString(2, user.getPassword());
			preparedStatement.setString(3, user.getEmailId());
			preparedStatement.setString(4, user.getLibrarian());
			n = preparedStatement.executeUpdate();
			log.info("User Added into Database");
		} catch (SQLException sqlException) {
			// TODO Auto-generated catch block
			log.error("Problem in querry(INSERTUSER) please check the query");
			sqlException.printStackTrace();
			throw new LibraryException("invalid user data");
		}

		return n;
	}

	@Override
	public ResultSet checkUser(String userName) {
		try {
			connection = DBUtil.getConnection();
			log.info("check user");

			PreparedStatement preparedStatement;

			preparedStatement = connection
					.prepareStatement(QueryMapper.SELECTUSERCHECK);
			preparedStatement.setString(1, userName);
			resultSet = preparedStatement.executeQuery();
			log.info("User Checked");
		} catch (SQLException sqlException) {
			System.err.println("Invalid Username/ Password**");
			log.error("Problem in querry(SELECTUSERCHECK) please check the query");
			sqlException.printStackTrace();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		} catch (NullPointerException nullPointerException) {
			System.err.println("Invalid username / password");
		}
		return resultSet;
	}

	@Override
	public int updatetransactionDetails(BooksTransaction BooksTransaction) {
		try {

			connection = DBUtil.getConnection();

			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.UPDATETRANSACTION);

			preparedStatement.setDouble(1, BooksTransaction.getFine());
			preparedStatement
					.setString(2, BooksTransaction.getRegistrationId());
			n = preparedStatement.executeUpdate();
			if (n == 0) {
				System.err.println("invalid registration id");
			}
			PreparedStatement preparedStatement2 = connection
					.prepareStatement(QueryMapper.UPDATTRANSACSTATUS);
			String status = "Y";
			preparedStatement2.setString(1, status);
			preparedStatement2.setString(2,
					BooksTransaction.getRegistrationId());
			System.out.println(BooksTransaction.getRegistrationId());
			resultSet = preparedStatement2.executeQuery();

			ResultSet resultSet;
			PreparedStatement preparedStatement3 = connection
					.prepareStatement(QueryMapper.SELECTBOOKID);
			preparedStatement3.setString(1,
					BooksTransaction.getRegistrationId());

			resultSet = preparedStatement3.executeQuery();

			if (resultSet.next()) {
				bookid = resultSet.getString("book_id");
			}

			PreparedStatement preparedStatement4 = connection
					.prepareStatement(QueryMapper.UPDATEBOOKAVRETURN);
			String av = "available";
			preparedStatement4.setString(1, av);
			preparedStatement4.setString(2, bookid);
			preparedStatement4.executeUpdate();

			log.info("Transation updated");
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			log.error("error in updation transaction");
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		} finally {

			try {
				connection.close();
			} catch (SQLException sqlException) {
				// TODO Auto-generated catch block
				sqlException.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public int addRegistration(BooksRegistration BooksRegistration)
			throws LibraryException {
		try {
			connection = DBUtil.getConnection();
			log.info("Student  request book");
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();

		}

		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection
					.prepareStatement(QueryMapper.INSERTREQUEST);
			// ps.setString(1, BooksRegistration.getRegistrationId());
			preparedStatement.setString(1, BooksRegistration.getBookId());
			preparedStatement.setString(2, BooksRegistration.getUserId());
			preparedStatement.setString(3, BooksRegistration.getStatus());
			n = preparedStatement.executeUpdate();
			log.error("book request placed");
		} catch (InputMismatchException | SQLException exception) {
			// TODO Auto-generated catch block
			log.error("Problem in querry(INSERTREQUEST) please check the query");
			// System.err.println("Wrong Bookid/userid");
			throw new LibraryException("invalid input:Wrong Bookid/userid");

		}

		return n;
	}

	@Override
	public ResultSet selectTransactionDate(String registrationID)
			throws LibraryException {
		try {
			connection = DBUtil.getConnection();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		}

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.SELECTRETURNDATE);
			preparedStatement.setString(1, registrationID);
			resultSet = preparedStatement.executeQuery();
		} catch (SQLException sqlException) {
			log.error("Problem in querry(SELECTRETURN) please check the query");
			// TODO Auto-generated catch block
			System.err.println("Enter valid Registration Id");
			throw new LibraryException("invalid input");

		}

		return resultSet;
	}

	@Override
	public ArrayList<BooksRegistration> selectBookRequest() {

		try {
			connection = DBUtil.getConnection();
			log.info("fetching registered book details");
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		}

		ArrayList<BooksRegistration> bookRegistrationList = new ArrayList<>();
		Statement statement = null;

		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement
					.executeQuery(QueryMapper.SELECTREQUEST);
			while (resultSet.next()) {

				BooksRegistration BookRegistration = new BooksRegistration();

				BookRegistration.setRegistrationId(resultSet
						.getString("registration_id"));
				BookRegistration.setBookId(resultSet.getString("book_id"));
				BookRegistration.setUserId(resultSet.getString("user_id"));
				BookRegistration.setRegistrationDate(resultSet
						.getString("registration_date"));
				bookRegistrationList.add(BookRegistration);
				log.info("Book Regisytration Details viewed on console");
			}

		} catch (SQLException sqlException) {
			sqlException.printStackTrace();
			log.error("Problem in querry(SELECTREQUEST) please check the query");

		}
		return bookRegistrationList;
	}

	@Override
	public ArrayList<BooksTransaction> selecttransac() {
		try {
			connection = DBUtil.getConnection();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		}

		ArrayList<BooksTransaction> booksTransactionList = new ArrayList<>();
		Statement statement = null;

		try {
			statement = connection.createStatement();
			ResultSet resultSet = statement
					.executeQuery(QueryMapper.SELECTTRANSACTION);
			while (resultSet.next()) {

				BooksTransaction BooksTransaction = new BooksTransaction();

				BooksTransaction.setTransactionId(resultSet
						.getString("TRANSACTION_ID"));
				BooksTransaction.setRegistrationId(resultSet
						.getString("registration_id"));
				BooksTransaction.setIssueDate(resultSet.getDate("ISSUE_DATE")
						.toLocalDate());
				BooksTransaction.setReturnDate(resultSet.getDate(
						"EXPECTED_RETURN_DATE").toLocalDate());
				BooksTransaction.setFine(resultSet.getDouble("FINE"));
				BooksTransaction.setActualReturnDate(resultSet.getDate(
						"ACTUAL_RETURN_DATE").toLocalDate());
				BooksTransaction.setStatus(resultSet.getString("STATUS"));
				booksTransactionList.add(BooksTransaction);
			}

		} catch (SQLException sqlException) {

			sqlException.printStackTrace();
		}
		return booksTransactionList;
	}

	@Override
	public int updatePassword(User User) {
		try {

			connection = DBUtil.getConnection();
			log.info("Password update request of student");
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.CHANGEPWD);
			preparedStatement.setString(1, User.getPassword());
			preparedStatement.setString(2, User.getUserId());
			n = preparedStatement.executeUpdate();
			log.info("Password Successfully Changeds");
			if (n > 0) {
				System.out.println("succesfully updated password");
			} else {
				System.err.println("enter correct user id.");
			}
			// c.setAutoCommit(false); Disabling the Auto Commit

		} catch (SQLException sqlException) {
			log.error("Problem in querry(CHANGEPWD) please check the query");
			sqlException.printStackTrace();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		} finally {

			try {
				connection.close();
			} catch (SQLException sqlException) {
				// TODO Auto-generated catch block
				sqlException.printStackTrace();
			}
		}
		return n;
	}

	@Override
	public ArrayList<BooksRegistration> selectRegistration(String userId) {
		try {
			connection = DBUtil.getConnection();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		}
		ArrayList<BooksRegistration> booksRegistrationList = new ArrayList<>();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.SELECTREGISFORDISPLAY);
			preparedStatement.setString(1, userId);
			// rs = ps.executeQuery();
			// st = c.createStatement();

			ResultSet resultSet = preparedStatement.executeQuery();
			// st.executeQuery(QueryMapper.SELECTREGISFORDISPLAY);
			while (resultSet.next()) {
				BooksRegistration BooksRegistration = new BooksRegistration();
				BooksRegistration.setRegistrationId(resultSet
						.getString("REGISTRATION_ID"));
				BooksRegistration.setBookId(resultSet.getString("BOOK_ID"));
				BooksRegistration.setUserId(resultSet.getString("USER_ID"));
				BooksRegistration.setRegistrationDate(resultSet
						.getString("REGISTRATION_DATE"));
				BooksRegistration.setStatus(resultSet.getString("STATUS"));
				booksRegistrationList.add(BooksRegistration);
			}
		} catch (SQLException sqlException) {
			// TODO Auto-generated catch block
			sqlException.printStackTrace();
		}

		return booksRegistrationList;
	}

	@Override
	public ArrayList<BooksTransaction> selectTransactionForStudent(String registrationID) {
		try {
			connection = DBUtil.getConnection();
		} catch (LibraryException libraryException) {
			// TODO Auto-generated catch block
			libraryException.printStackTrace();
		}
		ArrayList<BooksTransaction> booksTransactionList = new ArrayList<>();

		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement(QueryMapper.SELECTTRANSACFORDISPLAY);
			preparedStatement.setString(1, registrationID);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				BooksTransaction BooksTransaction = new BooksTransaction();
				BooksTransaction.setTransactionId(resultSet
						.getString("TRANSACTION_ID"));
				BooksTransaction.setRegistrationId(resultSet
						.getString("REGISTRATION_ID"));
				BooksTransaction.setIssueDate(resultSet.getDate("ISSUE_DATE")
						.toLocalDate());
				BooksTransaction.setReturnDate(resultSet.getDate(
						"EXPECTED_RETURN_DATE").toLocalDate());
				BooksTransaction.setFine(resultSet.getDouble("FINE"));
				BooksTransaction.setActualReturnDate(resultSet.getDate(
						"ACTUAL_RETURN_DATE").toLocalDate());
				BooksTransaction.setStatus(resultSet
						.getString("ACTUAL_RETURN_DATE"));
				booksTransactionList.add(BooksTransaction);
			}
		} catch (SQLException sqlException) {
			// TODO Auto-generated catch block
			sqlException.printStackTrace();
		}

		return booksTransactionList;
	}

}
